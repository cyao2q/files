.class public Lcom/github/catvod/spider/SP360;
.super Lcom/github/catvod/crawler/Spider;
.source "SourceFile"


# instance fields
.field private final a:Ljava/lang/String;

.field private b:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .registers 3

    invoke-direct {p0}, Lcom/github/catvod/crawler/Spider;-><init>()V

    const/16 v0, 0x6c

    new-array v0, v0, [B

    fill-array-data v0, :array_1c

    const/16 v1, 0x8

    new-array v1, v1, [B

    fill-array-data v1, :array_56

    invoke-static {v0, v1}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/github/catvod/spider/SP360;->a:Ljava/lang/String;

    const-string v0, ""

    iput-object v0, p0, Lcom/github/catvod/spider/SP360;->b:Ljava/lang/String;

    return-void

    :array_1c
    .array-data 1
        0x1t
        -0x4dt
        0x1t
        0x28t
        0x2at
        -0x7ct
        -0x43t
        0x49t
        0x79t
        -0xet
        0x4bt
        0x61t
        0x6et
        -0x41t
        -0x4bt
        0x8t
        0x28t
        -0x4dt
        0xct
        0x32t
        0x66t
        -0x5at
        -0x78t
        0x46t
        0x7at
        -0xet
        0x4at
        0x7at
        0x66t
        -0x41t
        -0x6dt
        0x31t
        0x7at
        -0x18t
        0x52t
        0x61t
        0x7t
        -0x68t
        -0x54t
        0xat
        0x29t
        -0x75t
        0x1et
        0x23t
        0xdt
        -0x7ft
        -0x58t
        0x49t
        0x79t
        -0x11t
        0x4ct
        0x6ft
        0x75t
        -0x22t
        -0x4t
        0x4et
        0x7t
        -0x6ct
        0x2ft
        0xct
        0xat
        -0x3ct
        -0x4t
        0xat
        0x25t
        -0x49t
        0x1et
        0x61t
        0x1t
        -0x73t
        -0x41t
        0xdt
        0x23t
        -0xbt
        0x5bt
        0x2t
        0x2et
        -0x66t
        -0x4dt
        0xbt
        0x29t
        -0xdt
        0x48t
        0x78t
        0x68t
        -0x28t
        -0xet
        0x54t
        0x7dt
        -0x15t
        0x4at
        0x6ft
        0x71t
        -0x27t
        -0x4t
        0x35t
        0x2dt
        -0x46t
        0x1at
        0x33t
        0x2ft
        -0x39t
        -0x17t
        0x55t
        0x7bt
        -0xet
        0x48t
        0x77t
    .end array-data

    :array_56
    .array-data 1
        0x4ct
        -0x24t
        0x7bt
        0x41t
        0x46t
        -0x18t
        -0x24t
        0x66t
    .end array-data
.end method

.method private a(Lorg/json/JSONArray;)Ljava/lang/String;
    .registers 8

    const-string v0, ""

    if-nez p1, :cond_5

    return-object v0

    :cond_5
    invoke-virtual {p1}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x1

    new-array v2, v1, [B

    const/16 v3, -0x18

    const/4 v4, 0x0

    aput-byte v3, v2, v4

    const/16 v3, 0x8

    new-array v5, v3, [B

    fill-array-data v5, :array_48

    invoke-static {v2, v5}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1, v2, v0}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    new-array v2, v1, [B

    const/16 v5, 0x13

    aput-byte v5, v2, v4

    new-array v5, v3, [B

    fill-array-data v5, :array_50

    invoke-static {v2, v5}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1, v2, v0}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    new-array v1, v1, [B

    const/16 v2, 0x43

    aput-byte v2, v1, v4

    new-array v2, v3, [B

    fill-array-data v2, :array_58

    invoke-static {v1, v2}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1, v0}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    return-object p1

    nop

    :array_48
    .array-data 1
        -0x36t
        0x3ct
        0x72t
        -0x38t
        -0x1bt
        0x77t
        -0x7bt
        0x33t
    .end array-data

    :array_50
    .array-data 1
        0x48t
        0x13t
        -0x7bt
        0x63t
        0x29t
        -0x4at
        0x4dt
        -0x72t
    .end array-data

    :array_58
    .array-data 1
        0x1et
        0x3dt
        -0x18t
        -0xft
        0x61t
        -0x8t
        -0x1et
        0x28t
    .end array-data
.end method

.method private b(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 6

    new-instance v0, Lokhttp3/Request$Builder;

    invoke-direct {v0}, Lokhttp3/Request$Builder;-><init>()V

    invoke-virtual {v0, p1}, Lokhttp3/Request$Builder;->url(Ljava/lang/String;)Lokhttp3/Request$Builder;

    move-result-object p1

    invoke-virtual {p1}, Lokhttp3/Request$Builder;->get()Lokhttp3/Request$Builder;

    move-result-object p1

    const/16 v0, 0xa

    new-array v0, v0, [B

    fill-array-data v0, :array_5e

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_68

    invoke-static {v0, v2}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    iget-object v2, p0, Lcom/github/catvod/spider/SP360;->a:Ljava/lang/String;

    invoke-virtual {p1, v0, v2}, Lokhttp3/Request$Builder;->addHeader(Ljava/lang/String;Ljava/lang/String;)Lokhttp3/Request$Builder;

    move-result-object p1

    const/4 v0, 0x7

    new-array v0, v0, [B

    fill-array-data v0, :array_70

    new-array v1, v1, [B

    fill-array-data v1, :array_78

    invoke-static {v0, v1}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0, p2}, Lokhttp3/Request$Builder;->addHeader(Ljava/lang/String;Ljava/lang/String;)Lokhttp3/Request$Builder;

    move-result-object p1

    invoke-virtual {p1}, Lokhttp3/Request$Builder;->build()Lokhttp3/Request;

    move-result-object p1

    invoke-static {}, Lcom/github/catvod/spider/merge/q/f;->b()Lokhttp3/OkHttpClient;

    move-result-object p2

    invoke-virtual {p2, p1}, Lokhttp3/OkHttpClient;->newCall(Lokhttp3/Request;)Lokhttp3/Call;

    move-result-object p1

    invoke-interface {p1}, Lokhttp3/Call;->execute()Lokhttp3/Response;

    move-result-object p1

    invoke-virtual {p1}, Lokhttp3/Response;->body()Lokhttp3/ResponseBody;

    move-result-object p2

    if-nez p2, :cond_51

    const-string p1, ""

    return-object p1

    :cond_51
    invoke-virtual {p1}, Lokhttp3/Response;->body()Lokhttp3/ResponseBody;

    move-result-object p2

    invoke-virtual {p2}, Lokhttp3/ResponseBody;->string()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1}, Lokhttp3/Response;->close()V

    return-object p2

    nop

    :array_5e
    .array-data 1
        0x74t
        0x37t
        0x75t
        -0x66t
        -0x80t
        0x24t
        0x36t
        0x11t
        0x4ft
        0x30t
    .end array-data

    nop

    :array_68
    .array-data 1
        0x21t
        0x44t
        0x10t
        -0x18t
        -0x53t
        0x65t
        0x51t
        0x74t
    .end array-data

    :array_70
    .array-data 1
        -0x6dt
        0x17t
        -0x2bt
        0x4dt
        0x1et
        0x4bt
        -0x7dt
    .end array-data

    :array_78
    .array-data 1
        -0x3ft
        0x72t
        -0x4dt
        0x28t
        0x6ct
        0x2et
        -0xft
        0x19t
    .end array-data
.end method

.method private c(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 7

    const-string v0, ""

    const/4 v1, 0x0

    :goto_3
    const/16 v2, 0x8

    if-ge v1, v2, :cond_2a

    const/16 v0, 0x1a

    new-array v0, v0, [B

    fill-array-data v0, :array_2c

    new-array v2, v2, [B

    fill-array-data v2, :array_3e

    invoke-static {v0, v2}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, p1, v0}, Lcom/github/catvod/spider/SP360;->b(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0, p2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_22

    goto :goto_2a

    :cond_22
    const-wide/16 v2, 0x1f4

    invoke-static {v2, v3}, Ljava/lang/Thread;->sleep(J)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_3

    :cond_2a
    :goto_2a
    return-object v0

    nop

    :array_2c
    .array-data 1
        -0x33t
        -0x6et
        0x7ft
        0x17t
        -0x21t
        -0x6ct
        -0xft
        0x46t
        -0x3ct
        -0x6at
        0x62t
        0x49t
        -0x25t
        -0x35t
        -0x44t
        0x47t
        -0x6at
        -0x30t
        0x3bt
        0xct
        -0x33t
        -0x40t
        -0x10t
        0xat
        -0x36t
        -0x75t
    .end array-data

    nop

    :array_3e
    .array-data 1
        -0x5bt
        -0x1at
        0xbt
        0x67t
        -0x54t
        -0x52t
        -0x22t
        0x69t
    .end array-data
.end method


# virtual methods
.method public categoryContent(Ljava/lang/String;Ljava/lang/String;ZLjava/util/HashMap;)Ljava/lang/String;
    .registers 21
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Z",
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    move-object/from16 v0, p1

    move-object/from16 v1, p2

    move-object/from16 v2, p4

    new-instance v3, Ljava/util/HashMap;

    invoke-direct {v3}, Ljava/util/HashMap;-><init>()V

    if-eqz v2, :cond_16

    invoke-virtual/range {p4 .. p4}, Ljava/util/HashMap;->size()I

    move-result v4

    if-lez v4, :cond_16

    invoke-virtual {v3, v2}, Ljava/util/HashMap;->putAll(Ljava/util/Map;)V

    :cond_16
    const/4 v2, 0x2

    new-array v4, v2, [B

    fill-array-data v4, :array_5fe

    const/16 v5, 0x8

    new-array v6, v5, [B

    fill-array-data v6, :array_604

    invoke-static {v4, v6}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    const/16 v6, 0xa

    if-nez v4, :cond_3e

    new-array v4, v6, [B

    fill-array-data v4, :array_60c

    new-array v7, v5, [B

    fill-array-data v7, :array_616

    invoke-static {v4, v7}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    goto :goto_52

    :cond_3e
    new-array v4, v2, [B

    fill-array-data v4, :array_61e

    new-array v7, v5, [B

    fill-array-data v7, :array_624

    invoke-static {v4, v7}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    :goto_52
    const/4 v7, 0x5

    new-array v8, v7, [B

    fill-array-data v8, :array_62c

    new-array v9, v5, [B

    fill-array-data v9, :array_634

    invoke-static {v8, v9}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v3, v8}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    const-string v9, ""

    if-nez v8, :cond_6b

    move-object v8, v9

    goto :goto_7f

    :cond_6b
    new-array v8, v7, [B

    fill-array-data v8, :array_63c

    new-array v10, v5, [B

    fill-array-data v10, :array_644

    invoke-static {v8, v10}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v3, v8}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/String;

    :goto_7f
    const/4 v10, 0x4

    new-array v11, v10, [B

    fill-array-data v11, :array_64c

    new-array v12, v5, [B

    fill-array-data v12, :array_652

    invoke-static {v11, v12}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v3, v11}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v11

    if-nez v11, :cond_96

    move-object v11, v9

    goto :goto_aa

    :cond_96
    new-array v11, v10, [B

    fill-array-data v11, :array_65a

    new-array v12, v5, [B

    fill-array-data v12, :array_660

    invoke-static {v11, v12}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v3, v11}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/String;

    :goto_aa
    new-array v12, v10, [B

    fill-array-data v12, :array_668

    new-array v13, v5, [B

    fill-array-data v13, :array_66e

    invoke-static {v12, v13}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v3, v12}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v12

    if-nez v12, :cond_c0

    move-object v10, v9

    goto :goto_d4

    :cond_c0
    new-array v10, v10, [B

    fill-array-data v10, :array_676

    new-array v12, v5, [B

    fill-array-data v12, :array_67c

    invoke-static {v10, v12}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v3, v10}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/String;

    :goto_d4
    new-array v12, v7, [B

    fill-array-data v12, :array_684

    new-array v13, v5, [B

    fill-array-data v13, :array_68c

    invoke-static {v12, v13}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v3, v12}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v12

    if-nez v12, :cond_ea

    move-object v3, v9

    goto :goto_fe

    :cond_ea
    new-array v12, v7, [B

    fill-array-data v12, :array_694

    new-array v13, v5, [B

    fill-array-data v13, :array_69c

    invoke-static {v12, v13}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v3, v12}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    :goto_fe
    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    new-array v13, v7, [B

    fill-array-data v13, :array_6a4

    new-array v14, v5, [B

    fill-array-data v14, :array_6ac

    .line 1
    invoke-static {v13, v14, v12, v4}, Lcom/github/catvod/spider/merge/b/v;->a([B[BLjava/lang/StringBuilder;Ljava/lang/String;)V

    new-array v4, v7, [B

    .line 2
    fill-array-data v4, :array_6b4

    new-array v13, v5, [B

    fill-array-data v13, :array_6bc

    invoke-static {v4, v13}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v12, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v8}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v12, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    new-array v8, v4, [B

    fill-array-data v8, :array_6c4

    new-array v13, v5, [B

    fill-array-data v13, :array_6cc

    .line 3
    invoke-static {v8, v13, v12, v11}, Lcom/github/catvod/spider/merge/b/v;->a([B[BLjava/lang/StringBuilder;Ljava/lang/String;)V

    new-array v8, v4, [B

    .line 4
    fill-array-data v8, :array_6d4

    new-array v11, v5, [B

    fill-array-data v11, :array_6dc

    invoke-static {v8, v11}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v12, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v10}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v12, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v7, v7, [B

    fill-array-data v7, :array_6e4

    new-array v8, v5, [B

    fill-array-data v8, :array_6ec

    invoke-static {v7, v8}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v12, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v3}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v12, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual/range {p1 .. p1}, Ljava/lang/String;->hashCode()I

    move-result v3

    const/4 v7, -0x1

    const/4 v8, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x1

    packed-switch v3, :pswitch_data_5f2

    goto :goto_1cd

    :pswitch_172  #0x34
    new-array v3, v11, [B

    const/16 v13, -0x2f

    aput-byte v13, v3, v10

    new-array v13, v5, [B

    fill-array-data v13, :array_6f4

    invoke-static {v3, v13}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1cd

    const/4 v3, 0x3

    goto :goto_1ce

    :pswitch_189  #0x33
    new-array v3, v11, [B

    const/16 v13, -0x27

    aput-byte v13, v3, v10

    new-array v13, v5, [B

    fill-array-data v13, :array_6fc

    invoke-static {v3, v13}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1cd

    const/4 v3, 0x2

    goto :goto_1ce

    :pswitch_1a0  #0x32
    new-array v3, v11, [B

    const/16 v13, -0x5a

    aput-byte v13, v3, v10

    new-array v13, v5, [B

    fill-array-data v13, :array_704

    invoke-static {v3, v13}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1cd

    const/4 v3, 0x1

    goto :goto_1ce

    :pswitch_1b7  #0x31
    new-array v3, v11, [B

    const/4 v13, -0x2

    aput-byte v13, v3, v10

    new-array v13, v5, [B

    fill-array-data v13, :array_70c

    invoke-static {v3, v13}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1cd

    const/4 v3, 0x0

    goto :goto_1ce

    :cond_1cd
    :goto_1cd
    const/4 v3, -0x1

    :goto_1ce
    const/4 v13, 0x7

    if-eqz v3, :cond_22d

    if-eq v3, v11, :cond_211

    if-eq v3, v2, :cond_1f5

    if-eq v3, v8, :cond_1d9

    move-object v2, v9

    goto :goto_249

    :cond_1d9
    new-array v3, v13, [B

    fill-array-data v3, :array_714

    new-array v8, v5, [B

    fill-array-data v8, :array_71c

    invoke-static {v3, v8}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    new-array v2, v2, [B

    fill-array-data v2, :array_724

    new-array v3, v5, [B

    fill-array-data v3, :array_72a

    invoke-static {v2, v3}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    goto :goto_249

    :cond_1f5
    new-array v3, v4, [B

    fill-array-data v3, :array_732

    new-array v8, v5, [B

    fill-array-data v8, :array_73a

    invoke-static {v3, v8}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    new-array v2, v2, [B

    fill-array-data v2, :array_742

    new-array v3, v5, [B

    fill-array-data v3, :array_748

    invoke-static {v2, v3}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    goto :goto_249

    :cond_211
    new-array v3, v13, [B

    fill-array-data v3, :array_750

    new-array v8, v5, [B

    fill-array-data v8, :array_758

    invoke-static {v3, v8}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    new-array v2, v2, [B

    fill-array-data v2, :array_760

    new-array v3, v5, [B

    fill-array-data v3, :array_766

    invoke-static {v2, v3}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    goto :goto_249

    :cond_22d
    new-array v2, v5, [B

    fill-array-data v2, :array_76e

    new-array v3, v5, [B

    fill-array-data v3, :array_776

    invoke-static {v2, v3}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    new-array v2, v11, [B

    const/16 v3, 0x3c

    aput-byte v3, v2, v10

    new-array v3, v5, [B

    fill-array-data v3, :array_77e

    invoke-static {v2, v3}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    :goto_249
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v8, 0x30

    new-array v13, v8, [B

    fill-array-data v13, :array_786

    new-array v14, v5, [B

    fill-array-data v14, :array_7a2

    .line 5
    invoke-static {v13, v14, v3, v0}, Lcom/github/catvod/spider/merge/b/v;->a([B[BLjava/lang/StringBuilder;Ljava/lang/String;)V

    new-array v13, v11, [B

    const/16 v14, -0x66

    aput-byte v14, v13, v10

    new-array v14, v5, [B

    .line 6
    fill-array-data v14, :array_7aa

    invoke-static {v13, v14}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v3, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 v13, 0x12

    new-array v13, v13, [B

    fill-array-data v13, :array_7b2

    new-array v14, v5, [B

    fill-array-data v14, :array_7c0

    .line 7
    invoke-static {v13, v14, v3}, Lcom/github/catvod/spider/merge/b/t;->b([B[BLjava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v3

    const/16 v13, 0x17

    new-array v14, v13, [B

    .line 8
    fill-array-data v14, :array_7c8

    new-array v15, v5, [B

    fill-array-data v15, :array_7d8

    invoke-static {v14, v15}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    new-array v14, v4, [B

    fill-array-data v14, :array_7e0

    new-array v15, v5, [B

    fill-array-data v15, :array_7e8

    invoke-static {v14, v15}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    new-array v14, v11, [B

    const/16 v15, 0x32

    aput-byte v15, v14, v10

    new-array v15, v5, [B

    fill-array-data v15, :array_7f0

    invoke-static {v14, v15}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v1, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v14

    if-nez v14, :cond_31c

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    new-array v8, v8, [B

    fill-array-data v8, :array_7f8

    new-array v14, v5, [B

    fill-array-data v14, :array_814

    .line 9
    invoke-static {v8, v14, v3, v0}, Lcom/github/catvod/spider/merge/b/v;->a([B[BLjava/lang/StringBuilder;Ljava/lang/String;)V

    new-array v8, v11, [B

    aput-byte v7, v8, v10

    new-array v7, v5, [B

    .line 10
    fill-array-data v7, :array_81c

    invoke-static {v8, v7}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v3, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 v7, 0x10

    new-array v7, v7, [B

    fill-array-data v7, :array_824

    new-array v8, v5, [B

    fill-array-data v8, :array_830

    .line 11
    invoke-static {v7, v8, v3, v1}, Lcom/github/catvod/spider/merge/b/v;->a([B[BLjava/lang/StringBuilder;Ljava/lang/String;)V

    new-array v1, v6, [B

    .line 12
    fill-array-data v1, :array_838

    new-array v7, v5, [B

    fill-array-data v7, :array_842

    .line 13
    invoke-static {v1, v7, v3}, Lcom/github/catvod/spider/merge/b/t;->b([B[BLjava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v3

    new-array v1, v13, [B

    .line 14
    fill-array-data v1, :array_84a

    new-array v7, v5, [B

    fill-array-data v7, :array_85a

    invoke-static {v1, v7}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    new-array v1, v4, [B

    fill-array-data v1, :array_862

    new-array v7, v5, [B

    fill-array-data v7, :array_86a

    invoke-static {v1, v7}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    new-array v1, v5, [B

    fill-array-data v1, :array_872

    new-array v7, v5, [B

    fill-array-data v7, :array_87a

    invoke-static {v1, v7}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    :cond_31c
    new-instance v1, Lorg/json/JSONArray;

    invoke-direct {v1}, Lorg/json/JSONArray;-><init>()V

    new-instance v7, Lorg/json/JSONObject;

    new-array v8, v6, [B

    fill-array-data v8, :array_882

    new-array v10, v5, [B

    fill-array-data v10, :array_88c

    invoke-static {v8, v10}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    move-object/from16 v10, p0

    invoke-direct {v10, v3, v8}, Lcom/github/catvod/spider/SP360;->c(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v7, v3}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    new-array v3, v3, [B

    fill-array-data v3, :array_894

    new-array v8, v5, [B

    fill-array-data v8, :array_89a

    invoke-static {v3, v8}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v7, v3}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v3

    new-array v4, v4, [B

    fill-array-data v4, :array_8a2

    new-array v7, v5, [B

    fill-array-data v7, :array_8aa

    invoke-static {v4, v7}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v3

    const/4 v4, 0x0

    :goto_360
    invoke-virtual {v3}, Lorg/json/JSONArray;->length()I

    move-result v7

    if-ge v4, v7, :cond_5c1

    invoke-virtual {v3, v4}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v7

    const/4 v8, 0x2

    new-array v8, v8, [B

    fill-array-data v8, :array_8b2

    new-array v12, v5, [B

    fill-array-data v12, :array_8b8

    invoke-static {v8, v12}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v14, 0x29

    new-array v14, v14, [B

    fill-array-data v14, :array_8c0

    new-array v15, v5, [B

    fill-array-data v15, :array_8da

    .line 15
    invoke-static {v14, v15, v12, v0}, Lcom/github/catvod/spider/merge/b/v;->a([B[BLjava/lang/StringBuilder;Ljava/lang/String;)V

    const/4 v14, 0x4

    new-array v14, v14, [B

    .line 16
    fill-array-data v14, :array_8e2

    new-array v15, v5, [B

    fill-array-data v15, :array_8e8

    .line 17
    invoke-static {v14, v15, v12, v8}, Lcom/github/catvod/spider/merge/b/v;->a([B[BLjava/lang/StringBuilder;Ljava/lang/String;)V

    .line 18
    new-array v6, v6, [B

    fill-array-data v6, :array_8f0

    new-array v14, v5, [B

    fill-array-data v14, :array_8fa

    .line 19
    invoke-static {v6, v14, v12}, Lcom/github/catvod/spider/merge/b/t;->b([B[BLjava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v6

    .line 20
    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    new-array v13, v13, [B

    fill-array-data v13, :array_902

    new-array v14, v5, [B

    fill-array-data v14, :array_912

    .line 21
    invoke-static {v13, v14, v12, v2}, Lcom/github/catvod/spider/merge/b/v;->a([B[BLjava/lang/StringBuilder;Ljava/lang/String;)V

    .line 22
    new-array v13, v11, [B

    const/4 v14, 0x0

    aput-byte v5, v13, v14

    new-array v14, v5, [B

    fill-array-data v14, :array_91a

    .line 23
    invoke-static {v13, v14, v12, v8}, Lcom/github/catvod/spider/merge/b/v;->a([B[BLjava/lang/StringBuilder;Ljava/lang/String;)V

    const/4 v8, 0x5

    new-array v8, v8, [B

    .line 24
    fill-array-data v8, :array_922

    new-array v13, v5, [B

    fill-array-data v13, :array_92a

    .line 25
    invoke-static {v8, v13, v12}, Lcom/github/catvod/spider/merge/b/t;->b([B[BLjava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v8

    .line 26
    new-instance v12, Lorg/json/JSONObject;

    invoke-direct {v12}, Lorg/json/JSONObject;-><init>()V

    const/16 v13, 0x9

    new-array v13, v13, [B

    fill-array-data v13, :array_932

    new-array v14, v5, [B

    fill-array-data v14, :array_93c

    invoke-static {v13, v14}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v6

    const/16 v12, 0xd

    new-array v12, v12, [B

    fill-array-data v12, :array_944

    new-array v13, v5, [B

    fill-array-data v13, :array_950

    invoke-static {v12, v13}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v6, v12, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v6

    const/4 v8, 0x5

    new-array v8, v8, [B

    fill-array-data v8, :array_958

    new-array v12, v5, [B

    fill-array-data v12, :array_960

    invoke-static {v8, v12}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    const/16 v12, 0xc

    new-array v12, v12, [B

    fill-array-data v12, :array_968

    new-array v13, v5, [B

    fill-array-data v13, :array_972

    invoke-static {v12, v13}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v8, v12}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v12

    if-nez v12, :cond_5b8

    const/16 v12, 0x9

    new-array v12, v12, [B

    fill-array-data v12, :array_97a

    new-array v13, v5, [B

    fill-array-data v13, :array_984

    invoke-static {v12, v13}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v8, v12}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v12

    if-nez v12, :cond_5b8

    const/4 v12, 0x6

    new-array v13, v12, [B

    fill-array-data v13, :array_98c

    new-array v14, v5, [B

    fill-array-data v14, :array_994

    invoke-static {v13, v14}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v8, v13}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v13

    if-eqz v13, :cond_45e

    goto/16 :goto_5b8

    :cond_45e
    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    new-array v12, v12, [B

    fill-array-data v12, :array_99c

    new-array v14, v5, [B

    fill-array-data v14, :array_9a4

    invoke-static {v12, v14}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v13, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array v12, v5, [B

    fill-array-data v12, :array_9ac

    new-array v14, v5, [B

    fill-array-data v14, :array_9b4

    invoke-static {v12, v14}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v7, v12}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v13, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    new-array v13, v11, [B

    const/16 v14, -0x6c

    const/4 v15, 0x0

    aput-byte v14, v13, v15

    new-array v14, v5, [B

    fill-array-data v14, :array_9bc

    invoke-static {v13, v14}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v0, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_4bb

    new-array v11, v11, [B

    const/16 v13, -0x4d

    aput-byte v13, v11, v15

    new-array v13, v5, [B

    fill-array-data v13, :array_9c4

    invoke-static {v11, v13}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v0, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_4b9

    goto :goto_4bb

    :cond_4b9
    move-object v11, v9

    goto :goto_51b

    :cond_4bb
    :goto_4bb
    const/4 v11, 0x6

    new-array v11, v11, [B

    fill-array-data v11, :array_9cc

    new-array v13, v5, [B

    fill-array-data v13, :array_9d4

    invoke-static {v11, v13}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v7, v11}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    const/4 v13, 0x5

    new-array v13, v13, [B

    fill-array-data v13, :array_9dc

    new-array v14, v5, [B

    fill-array-data v14, :array_9e4

    invoke-static {v13, v14}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v7, v13}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v11, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_4f8

    const/16 v11, 0x9

    new-array v11, v11, [B

    fill-array-data v11, :array_9ec

    new-array v13, v5, [B

    fill-array-data v13, :array_9f6

    invoke-static {v11, v13}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v11

    goto :goto_51b

    :cond_4f8
    const/16 v13, 0x9

    new-instance v14, Ljava/lang/StringBuilder;

    invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V

    new-array v13, v13, [B

    fill-array-data v13, :array_9fe

    new-array v15, v5, [B

    fill-array-data v15, :array_a08

    .line 27
    invoke-static {v13, v15, v14, v11}, Lcom/github/catvod/spider/merge/b/v;->a([B[BLjava/lang/StringBuilder;Ljava/lang/String;)V

    const/4 v11, 0x3

    new-array v11, v11, [B

    .line 28
    fill-array-data v11, :array_a10

    new-array v13, v5, [B

    fill-array-data v13, :array_a16

    .line 29
    invoke-static {v11, v13, v14}, Lcom/github/catvod/spider/merge/b/t;->b([B[BLjava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v11

    :goto_51b
    const/4 v13, 0x1

    new-array v13, v13, [B

    const/16 v14, 0x79

    const/4 v15, 0x0

    aput-byte v14, v13, v15

    new-array v14, v5, [B

    .line 30
    fill-array-data v14, :array_a1e

    invoke-static {v13, v14}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v0, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_564

    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v13, 0x9

    new-array v13, v13, [B

    fill-array-data v13, :array_a26

    new-array v14, v5, [B

    fill-array-data v14, :array_a30

    invoke-static {v13, v14}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v11, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x3

    new-array v13, v13, [B

    fill-array-data v13, :array_a38

    new-array v14, v5, [B

    fill-array-data v14, :array_a3e

    invoke-static {v13, v14}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v7, v13}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v11, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    :cond_564
    invoke-virtual {v6}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v6

    new-instance v7, Lorg/json/JSONObject;

    invoke-direct {v7}, Lorg/json/JSONObject;-><init>()V

    const/4 v13, 0x6

    new-array v13, v13, [B

    fill-array-data v13, :array_a46

    new-array v14, v5, [B

    fill-array-data v14, :array_a4e

    invoke-static {v13, v14}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v7, v13, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v6, v5, [B

    fill-array-data v6, :array_a56

    new-array v13, v5, [B

    fill-array-data v13, :array_a5e

    invoke-static {v6, v13}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v7, v6, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v6, 0x7

    new-array v6, v6, [B

    fill-array-data v6, :array_a66

    new-array v8, v5, [B

    fill-array-data v8, :array_a6e

    invoke-static {v6, v8}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v7, v6, v12}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/16 v6, 0xb

    new-array v6, v6, [B

    fill-array-data v6, :array_a76

    new-array v8, v5, [B

    fill-array-data v8, :array_a80

    invoke-static {v6, v8}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v7, v6, v11}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {v1, v7}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    :cond_5b8
    :goto_5b8
    add-int/lit8 v4, v4, 0x1

    const/16 v6, 0xa

    const/16 v13, 0x17

    const/4 v11, 0x1

    goto/16 :goto_360

    :cond_5c1
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const/16 v2, 0x9

    new-array v2, v2, [B

    fill-array-data v2, :array_a88

    new-array v3, v5, [B

    fill-array-data v3, :array_a92

    invoke-static {v2, v3}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    const/16 v3, 0x3e7

    invoke-virtual {v0, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v2, 0x4

    new-array v2, v2, [B

    fill-array-data v2, :array_a9a

    new-array v3, v5, [B

    fill-array-data v3, :array_aa0

    invoke-static {v2, v3}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :pswitch_data_5f2
    .packed-switch 0x31
        :pswitch_1b7  #00000031
        :pswitch_1a0  #00000032
        :pswitch_189  #00000033
        :pswitch_172  #00000034
    .end packed-switch

    :array_5fe
    .array-data 1
        0x5dt
        0x9t
    .end array-data

    nop

    :array_604
    .array-data 1
        0x3ft
        0x70t
        -0x42t
        0x6dt
        -0x48t
        0x5bt
        0x9t
        -0x17t
    .end array-data

    :array_60c
    .array-data 1
        0xct
        -0x16t
        0xdt
        -0x19t
        0x59t
        -0x8t
        -0x5at
        0x4ct
        0xdt
        -0x1t
    .end array-data

    nop

    :array_616
    .array-data 1
        0x7et
        -0x75t
        0x63t
        -0x74t
        0x35t
        -0x67t
        -0x2et
        0x29t
    .end array-data

    :array_61e
    .array-data 1
        -0x9t
        0x1dt
    .end array-data

    nop

    :array_624
    .array-data 1
        -0x6bt
        0x64t
        -0x6ct
        0x11t
        0x32t
        -0x5t
        -0x35t
        0x20t
    .end array-data

    :array_62c
    .array-data 1
        -0x64t
        0x6ft
        0x21t
        -0x3at
        0x63t
    .end array-data

    nop

    :array_634
    .array-data 1
        -0x1t
        0x3t
        0x40t
        -0x4bt
        0x10t
        -0x41t
        0x1at
        -0x3bt
    .end array-data

    :array_63c
    .array-data 1
        0x1t
        0x31t
        -0x6et
        -0x36t
        -0x64t
    .end array-data

    nop

    :array_644
    .array-data 1
        0x62t
        0x5dt
        -0xdt
        -0x47t
        -0x11t
        -0x6at
        0x5ft
        -0x4t
    .end array-data

    :array_64c
    .array-data 1
        -0xdt
        -0x22t
        -0x2bt
        0x61t
    .end array-data

    :array_652
    .array-data 1
        -0x76t
        -0x45t
        -0x4ct
        0x13t
        -0x61t
        -0xct
        0x76t
        0x4t
    .end array-data

    :array_65a
    .array-data 1
        -0x60t
        0x3at
        -0x7dt
        -0x6dt
    .end array-data

    :array_660
    .array-data 1
        -0x27t
        0x5ft
        -0x1et
        -0x1ft
        0x44t
        0x5t
        0x3et
        -0x4bt
    .end array-data

    :array_668
    .array-data 1
        -0x38t
        0x6dt
        -0x5at
        0x5dt
    .end array-data

    :array_66e
    .array-data 1
        -0x57t
        0x1ft
        -0x3dt
        0x3ct
        0x53t
        0x5at
        0x10t
        0x72t
    .end array-data

    :array_676
    .array-data 1
        0x71t
        -0x34t
        0x41t
        0x8t
    .end array-data

    :array_67c
    .array-data 1
        0x10t
        -0x42t
        0x24t
        0x69t
        0x24t
        0x1dt
        0x76t
        0x43t
    .end array-data

    :array_684
    .array-data 1
        0x77t
        0x2ct
        -0x31t
        0x34t
        0x57t
    .end array-data

    nop

    :array_68c
    .array-data 1
        0x16t
        0x4ft
        -0x45t
        0x5bt
        0x25t
        0x76t
        -0x7bt
        0x2at
    .end array-data

    :array_694
    .array-data 1
        -0x67t
        0x72t
        0x65t
        -0x2et
        -0x1t
    .end array-data

    nop

    :array_69c
    .array-data 1
        -0x8t
        0x11t
        0x11t
        -0x43t
        -0x73t
        -0x1bt
        0x71t
        0x73t
    .end array-data

    :array_6a4
    .array-data 1
        -0x35t
        -0x10t
        0x24t
        0x70t
        -0x3ft
    .end array-data

    nop

    :array_6ac
    .array-data 1
        -0x47t
        -0x6ft
        0x4at
        0x1bt
        -0x4t
        0xat
        -0x21t
        -0x57t
    .end array-data

    :array_6b4
    .array-data 1
        -0x7t
        0x54t
        0x6at
        -0x73t
        -0x64t
    .end array-data

    nop

    :array_6bc
    .array-data 1
        -0x21t
        0x37t
        0xbt
        -0x7t
        -0x5ft
        -0x32t
        0x37t
        0x8t
    .end array-data

    :array_6c4
    .array-data 1
        0x7ct
        0x59t
        -0x1et
        0x55t
        0x1at
        -0x2bt
    .end array-data

    nop

    :array_6cc
    .array-data 1
        0x5at
        0x20t
        -0x79t
        0x34t
        0x68t
        -0x18t
        0x55t
        0x56t
    .end array-data

    :array_6d4
    .array-data 1
        0x2at
        -0x3at
        0x17t
        0xdt
        0x5ft
        -0x79t
    .end array-data

    nop

    :array_6dc
    .array-data 1
        0xct
        -0x59t
        0x65t
        0x68t
        0x3et
        -0x46t
        0x2dt
        0x7ft
    .end array-data

    :array_6e4
    .array-data 1
        0x27t
        -0x7ft
        -0x7ft
        0x4at
        -0x4et
    .end array-data

    nop

    :array_6ec
    .array-data 1
        0x1t
        -0x20t
        -0x1et
        0x3et
        -0x71t
        0x7ft
        -0x4dt
        0x31t
    .end array-data

    :array_6f4
    .array-data 1
        -0x1bt
        0x60t
        -0x57t
        0x75t
        -0x3ft
        0x11t
        0x41t
        -0x1ft
    .end array-data

    :array_6fc
    .array-data 1
        -0x16t
        -0x80t
        0x23t
        -0x24t
        0x19t
        0x65t
        0x5et
        -0x7dt
    .end array-data

    :array_704
    .array-data 1
        -0x6ct
        0x10t
        0x12t
        -0x16t
        -0x25t
        -0x1at
        0x4bt
        -0x3et
    .end array-data

    :array_70c
    .array-data 1
        -0x31t
        -0x80t
        0x5et
        0x3t
        0x2et
        -0x59t
        -0x66t
        0x3bt
    .end array-data

    :array_714
    .array-data 1
        0x6bt
        0x5ft
        0x32t
        0x51t
        -0x80t
        0x3t
        0x1at
    .end array-data

    :array_71c
    .array-data 1
        0xft
        0x30t
        0x5ct
        0x36t
        -0x13t
        0x62t
        0x74t
        0x55t
    .end array-data

    :array_724
    .array-data 1
        0x64t
        -0x80t
    .end array-data

    nop

    :array_72a
    .array-data 1
        0x7t
        -0xct
        -0x15t
        0x19t
        0x38t
        -0x63t
        -0x6bt
        -0x57t
    .end array-data

    :array_732
    .array-data 1
        0x69t
        -0x41t
        0x4t
        -0x3ct
        -0x4ct
        -0x9t
    .end array-data

    nop

    :array_73a
    .array-data 1
        0x13t
        -0x30t
        0x6at
        -0x5dt
        -0x33t
        -0x62t
        -0x18t
        -0xct
    .end array-data

    :array_742
    .array-data 1
        0x6ct
        -0x1bt
    .end array-data

    nop

    :array_748
    .array-data 1
        0x1at
        -0x7ct
        0x25t
        0x5ct
        0x37t
        0x62t
        -0x35t
        0x6at
    .end array-data

    :array_750
    .array-data 1
        0x62t
        -0x65t
        -0x2bt
        0x68t
        -0x15t
        0x3t
        0x79t
    .end array-data

    :array_758
    .array-data 1
        0x6t
        -0xet
        -0x4ct
        0x6t
        -0x68t
        0x6bt
        0x10t
        0x70t
    .end array-data

    :array_760
    .array-data 1
        0x31t
        -0xat
    .end array-data

    nop

    :array_766
    .array-data 1
        0x45t
        -0x80t
        0x43t
        -0x13t
        -0x5ft
        0x72t
        -0x19t
        0x50t
    .end array-data

    :array_76e
    .array-data 1
        0x56t
        -0xdt
        -0x30t
        -0x26t
        0x3t
        0x4dt
        0x7ct
        0x70t
    .end array-data

    :array_776
    .array-data 1
        0x32t
        -0x66t
        -0x4ft
        -0x4ct
        0x7at
        0x24t
        0x12t
        0x17t
    .end array-data

    :array_77e
    .array-data 1
        0x51t
        0x19t
        -0x2bt
        0x5et
        0x1dt
        -0x18t
        0x36t
        0x49t
    .end array-data

    :array_786
    .array-data 1
        -0x1ft
        -0x11t
        0x7at
        -0x7ft
        -0x76t
        -0x49t
        -0x29t
        -0x54t
        -0x18t
        -0x15t
        0x67t
        -0x21t
        -0x72t
        -0x18t
        -0x66t
        -0x53t
        -0x46t
        -0x53t
        0x3et
        -0x66t
        -0x68t
        -0x1dt
        -0x2at
        -0x20t
        -0x1at
        -0xat
        0x21t
        -0x79t
        -0x38t
        -0x5et
        -0x62t
        -0x16t
        -0x1bt
        -0x11t
        0x6bt
        -0x7dt
        -0x2at
        -0x1ft
        -0x6ft
        -0x10t
        -0x3t
        -0x5ct
        0x6dt
        -0x70t
        -0x73t
        -0x1ct
        -0x64t
        -0x42t
    .end array-data

    :array_7a2
    .array-data 1
        -0x77t
        -0x65t
        0xet
        -0xft
        -0x7t
        -0x73t
        -0x8t
        -0x7dt
    .end array-data

    :array_7aa
    .array-data 1
        -0x44t
        0x4ct
        0x2at
        -0x65t
        -0x49t
        -0x11t
        -0x2et
        0x19t
    .end array-data

    :array_7b2
    .array-data 1
        -0x53t
        0x45t
        -0x46t
        0x34t
        0x59t
        0x25t
        0x62t
        0x4bt
        -0x53t
        0x55t
        -0x4et
        0x22t
        0x50t
        0x7at
        0x30t
        0x1dt
        -0x20t
        0xbt
    .end array-data

    nop

    :array_7c0
    .array-data 1
        -0x75t
        0x36t
        -0x2dt
        0x4et
        0x3ct
        0x18t
        0x51t
        0x7et
    .end array-data

    :array_7c8
    .array-data 1
        -0x63t
        -0x65t
        -0x11t
        0x7et
        -0x30t
        0x3ct
        0x73t
        0x55t
        -0x7et
        -0x68t
        -0x14t
        0x20t
        -0x70t
        0x30t
        0x6ct
        0x11t
        -0x6ct
        -0x7ft
        -0x4bt
        0x6dt
        -0x34t
        0x6bt
        0x73t
    .end array-data

    :array_7d8
    .array-data 1
        -0xbt
        -0x11t
        -0x65t
        0xet
        -0x5dt
        0x6t
        0x5ct
        0x7at
    .end array-data

    :array_7e0
    .array-data 1
        -0x49t
        -0x48t
        -0x48t
        0x77t
        0x8t
        0x44t
    .end array-data

    nop

    :array_7e8
    .array-data 1
        -0x68t
        -0x2ct
        -0x2ft
        0x4t
        0x7ct
        0x7bt
        0x56t
        0x59t
    .end array-data

    :array_7f0
    .array-data 1
        0x3t
        0x2ct
        0x2ct
        0x3bt
        0x29t
        0x3ft
        0x69t
        -0x2ct
    .end array-data

    :array_7f8
    .array-data 1
        -0xat
        0xct
        -0x10t
        -0x2at
        -0xat
        -0x21t
        0x3bt
        -0x64t
        -0x1t
        0x8t
        -0x13t
        -0x78t
        -0xet
        -0x80t
        0x76t
        -0x63t
        -0x53t
        0x4et
        -0x4ct
        -0x33t
        -0x1ct
        -0x75t
        0x3at
        -0x30t
        -0xft
        0x15t
        -0x55t
        -0x30t
        -0x4ct
        -0x36t
        0x72t
        -0x26t
        -0xet
        0xct
        -0x1ft
        -0x2ct
        -0x56t
        -0x77t
        0x7dt
        -0x40t
        -0x16t
        0x47t
        -0x19t
        -0x39t
        -0xft
        -0x74t
        0x70t
        -0x72t
    .end array-data

    :array_814
    .array-data 1
        -0x62t
        0x78t
        -0x7ct
        -0x5at
        -0x7bt
        -0x1bt
        0x14t
        -0x4dt
    .end array-data

    :array_81c
    .array-data 1
        -0x27t
        -0x6t
        -0x6t
        0x44t
        -0x5et
        -0x70t
        -0x7ct
        -0x5bt
    .end array-data

    :array_824
    .array-data 1
        0x6dt
        -0x5ft
        -0x80t
        -0x20t
        0x43t
        -0x48t
        0x29t
        -0x18t
        0x6dt
        -0x5et
        -0x78t
        -0x3t
        0x43t
        -0x15t
        0x75t
        -0x20t
    .end array-data

    :array_830
    .array-data 1
        0x4bt
        -0x2et
        -0x17t
        -0x66t
        0x26t
        -0x7bt
        0x1at
        -0x23t
    .end array-data

    :array_838
    .array-data 1
        0x6bt
        -0x51t
        0xbt
        -0x7bt
        0x6at
        -0x67t
        0x54t
        -0x50t
        0x26t
        -0xft
    .end array-data

    nop

    :array_842
    .array-data 1
        0x4dt
        -0x34t
        0x6at
        -0x17t
        0x6t
        -0x5t
        0x35t
        -0x2dt
    .end array-data

    :array_84a
    .array-data 1
        -0x20t
        -0x43t
        -0x7at
        -0x76t
        -0x1dt
        0x7dt
        -0x62t
        0x7ft
        -0x1t
        -0x42t
        -0x7bt
        -0x2ct
        -0x5dt
        0x71t
        -0x7ft
        0x3bt
        -0x17t
        -0x59t
        -0x24t
        -0x67t
        -0x1t
        0x2at
        -0x62t
    .end array-data

    :array_85a
    .array-data 1
        -0x78t
        -0x37t
        -0xet
        -0x6t
        -0x70t
        0x47t
        -0x4ft
        0x50t
    .end array-data

    :array_862
    .array-data 1
        -0x74t
        0x23t
        0x7t
        -0xet
        0xet
        0x57t
    .end array-data

    nop

    :array_86a
    .array-data 1
        -0x5dt
        0x4ft
        0x6et
        -0x7ft
        0x7at
        0x68t
        0x38t
        0x69t
    .end array-data

    :array_872
    .array-data 1
        -0x40t
        -0x47t
        0x74t
        -0x23t
        -0x22t
        0x34t
        -0x42t
        -0x55t
    .end array-data

    :array_87a
    .array-data 1
        -0x1at
        -0x37t
        0x15t
        -0x46t
        -0x45t
        0x5at
        -0x2ft
        -0x6at
    .end array-data

    :array_882
    .array-data 1
        -0xft
        -0x1t
        0x2dt
        -0x6t
        -0x4dt
        -0x18t
        -0x28t
        0x2t
        -0x48t
        -0x50t
    .end array-data

    nop

    :array_88c
    .array-data 1
        -0x2dt
        -0x6et
        0x5et
        -0x63t
        -0x6ft
        -0x2et
        -0x6t
        0x6dt
    .end array-data

    :array_894
    .array-data 1
        0xat
        -0x31t
        0x7t
        0x1ct
    .end array-data

    :array_89a
    .array-data 1
        0x6et
        -0x52t
        0x73t
        0x7dt
        -0x1dt
        -0x23t
        -0x8t
        -0x2ct
    .end array-data

    :array_8a2
    .array-data 1
        0x71t
        0x6at
        -0x40t
        -0x24t
        -0x53t
        -0x5et
    .end array-data

    nop

    :array_8aa
    .array-data 1
        0x1ct
        0x5t
        -0x4at
        -0x4bt
        -0x38t
        -0x2ft
        0x7et
        0x4bt
    .end array-data

    :array_8b2
    .array-data 1
        0x51t
        -0x8t
    .end array-data

    nop

    :array_8b8
    .array-data 1
        0x38t
        -0x64t
        -0xet
        0x79t
        -0x2ft
        0x5ft
        0xft
        -0x6bt
    .end array-data

    :array_8c0
    .array-data 1
        0x10t
        -0x76t
        -0x6ft
        0x6dt
        0x11t
        0x7ct
        -0x43t
        -0x9t
        0x19t
        -0x72t
        -0x74t
        0x33t
        0x15t
        0x23t
        -0x10t
        -0xat
        0x4bt
        -0x38t
        -0x2bt
        0x76t
        0x3t
        0x28t
        -0x44t
        -0x45t
        0x17t
        -0x6dt
        -0x36t
        0x6bt
        0x53t
        0x69t
        -0xat
        -0x43t
        0xct
        -0x61t
        -0x74t
        0x71t
        0x5dt
        0x25t
        -0xdt
        -0x54t
        0x45t
    .end array-data

    nop

    :array_8da
    .array-data 1
        0x78t
        -0x2t
        -0x1bt
        0x1dt
        0x62t
        0x46t
        -0x6et
        -0x28t
    .end array-data

    :array_8e2
    .array-data 1
        -0x40t
        -0x61t
        0x46t
        -0x69t
    .end array-data

    :array_8e8
    .array-data 1
        -0x1at
        -0xat
        0x22t
        -0x56t
        -0x21t
        0x5et
        -0x2ft
        -0x13t
    .end array-data

    :array_8f0
    .array-data 1
        0x1at
        -0x12t
        -0x5bt
        -0x3t
        0x76t
        -0x22t
        0x31t
        -0xbt
        0x57t
        -0x50t
    .end array-data

    nop

    :array_8fa
    .array-data 1
        0x3ct
        -0x73t
        -0x3ct
        -0x6ft
        0x1at
        -0x44t
        0x50t
        -0x6at
    .end array-data

    :array_902
    .array-data 1
        0x6dt
        0x50t
        -0x55t
        0x4ft
        -0x3dt
        0x67t
        0x67t
        -0x3bt
        0x72t
        0x53t
        -0x58t
        0x11t
        -0x7dt
        0x6bt
        0x78t
        -0x7ft
        0x64t
        0x4at
        -0xft
        0x5ct
        -0x21t
        0x30t
        0x67t
    .end array-data

    :array_912
    .array-data 1
        0x5t
        0x24t
        -0x21t
        0x3ft
        -0x50t
        0x5dt
        0x48t
        -0x16t
    .end array-data

    :array_91a
    .array-data 1
        0x27t
        -0x58t
        0x56t
        -0x19t
        0x39t
        -0x65t
        -0x55t
        0x29t
    .end array-data

    :array_922
    .array-data 1
        -0x58t
        -0x10t
        0x4ft
        0x40t
        -0x51t
    .end array-data

    nop

    :array_92a
    .array-data 1
        -0x7at
        -0x68t
        0x3bt
        0x2dt
        -0x3dt
        0x56t
        0x10t
        -0x1bt
    .end array-data

    :array_932
    .array-data 1
        0x16t
        0x7bt
        -0x28t
        -0x31t
        -0x61t
        -0x45t
        -0xet
        -0x3ct
        0x1et
    .end array-data

    nop

    :array_93c
    .array-data 1
        0x72t
        0x1et
        -0x54t
        -0x52t
        -0xat
        -0x29t
        -0x59t
        -0x4at
    .end array-data

    :array_944
    .array-data 1
        0x45t
        -0x46t
        0x59t
        -0x5at
        0x68t
        -0x2t
        -0x7ft
        0x48t
        0x47t
        -0x46t
        0x5ft
        -0x5et
        0x73t
    .end array-data

    nop

    :array_950
    .array-data 1
        0x21t
        -0x21t
        0x2dt
        -0x39t
        0x1t
        -0x6et
        -0x2dt
        0x2dt
    .end array-data

    :array_958
    .array-data 1
        0x6t
        -0x7ct
        -0x2t
        0x12t
        -0x47t
    .end array-data

    nop

    :array_960
    .array-data 1
        0x72t
        -0x13t
        -0x76t
        0x7et
        -0x24t
        0x54t
        0x20t
        0x58t
    .end array-data

    :array_968
    .array-data 1
        -0x6et
        0x7bt
        0x4ct
        -0x7ft
        0x7bt
        0x50t
        -0x4ct
        -0x35t
        -0x39t
        0x27t
        0x64t
        -0xft
    .end array-data

    :array_972
    .array-data 1
        0x77t
        -0x3et
        -0x27t
        0x64t
        -0x15t
        -0x22t
        0x5ct
        0x65t
    .end array-data

    :array_97a
    .array-data 1
        -0x5dt
        -0x60t
        -0x76t
        -0x41t
        0x4ft
        -0x71t
        0x5ct
        0x6t
        -0x3bt
    .end array-data

    nop

    :array_984
    .array-data 1
        0x4at
        0x37t
        0x27t
        0x5at
        -0xat
        0x1at
        -0x47t
        -0x46t
    .end array-data

    :array_98c
    .array-data 1
        0x6at
        0x41t
        0x35t
        0x66t
        0x21t
        0x4dt
    .end array-data

    nop

    :array_994
    .array-data 1
        -0x7et
        -0xct
        -0x46t
        -0x80t
        -0x41t
        -0x23t
        -0x14t
        0xft
    .end array-data

    :array_99c
    .array-data 1
        0x42t
        0x1ct
        0x66t
        -0x3ft
        0x4t
        -0x8t
    .end array-data

    nop

    :array_9a4
    .array-data 1
        0x2at
        0x68t
        0x12t
        -0x4ft
        0x77t
        -0x3et
        0x9t
        -0x6t
    .end array-data

    :array_9ac
    .array-data 1
        -0x42t
        0x0t
        -0xat
        -0x5dt
        -0x50t
        -0x73t
        0x6bt
        -0x49t
    .end array-data

    :array_9b4
    .array-data 1
        -0x23t
        0x64t
        -0x68t
        -0x40t
        -0x21t
        -0x5t
        0xet
        -0x3bt
    .end array-data

    :array_9bc
    .array-data 1
        -0x5at
        -0x4ct
        -0x6at
        0x2t
        0x4dt
        0x33t
        0x9t
        0x7ct
    .end array-data

    :array_9c4
    .array-data 1
        -0x79t
        -0xat
        -0x6t
        0x7at
        -0x21t
        0x11t
        -0x79t
        -0x5t
    .end array-data

    :array_9cc
    .array-data 1
        -0x7dt
        -0x3ft
        -0x36t
        -0x16t
        0x4at
        0x77t
    .end array-data

    nop

    :array_9d4
    .array-data 1
        -0xat
        -0x4ft
        -0x5dt
        -0x7ct
        0x2ct
        0x18t
        0x29t
        -0x4dt
    .end array-data

    :array_9dc
    .array-data 1
        -0x6bt
        -0x3dt
        0x3t
        -0x5at
        -0x75t
    .end array-data

    nop

    :array_9e4
    .array-data 1
        -0x1ft
        -0x54t
        0x77t
        -0x39t
        -0x19t
        -0xat
        -0x67t
        0x34t
    .end array-data

    :array_9ec
    .array-data 1
        0x11t
        0x9t
        0xat
        0x6dt
        -0x48t
        0x7t
        -0x24t
        -0x71t
        0x67t
    .end array-data

    nop

    :array_9f6
    .array-data 1
        -0xct
        -0x42t
        -0x48t
        -0x78t
        0x16t
        -0x75t
        0x3bt
        0x34t
    .end array-data

    :array_9fe
    .array-data 1
        -0x56t
        0x65t
        -0x1ct
        0x58t
        0x4dt
        -0x10t
        0x7bt
        0x79t
        -0x1t
    .end array-data

    nop

    :array_a08
    .array-data 1
        0x4ct
        -0x2t
        0x50t
        -0x42t
        -0x25t
        0x40t
        -0x6dt
        -0x2t
    .end array-data

    :array_a10
    .array-data 1
        0x3ct
        -0x80t
        -0x77t
    .end array-data

    :array_a16
    .array-data 1
        -0x2bt
        0x1bt
        0xft
        0x2et
        0x3et
        -0x55t
        -0x5ft
        -0x3bt
    .end array-data

    :array_a1e
    .array-data 1
        0x4at
        -0x21t
        0xct
        0x44t
        -0x37t
        0x2t
        -0x61t
        -0x4ct
    .end array-data

    :array_a26
    .array-data 1
        -0x49t
        -0x3ct
        -0x18t
        0x2ct
        0x5ft
        0x27t
        0x24t
        -0x7ct
        -0x1et
    .end array-data

    nop

    :array_a30
    .array-data 1
        0x51t
        0x5ft
        0x5ct
        -0x36t
        -0x37t
        -0x69t
        -0x34t
        0x3t
    .end array-data

    :array_a38
    .array-data 1
        -0x5ct
        -0x59t
        -0x3dt
    .end array-data

    :array_a3e
    .array-data 1
        -0x30t
        -0x3at
        -0x5ct
        0x78t
        0x40t
        -0x60t
        0x14t
        -0x51t
    .end array-data

    :array_a46
    .array-data 1
        0x7bt
        -0x7bt
        0x5t
        -0x80t
        0x6ft
        0x7ft
    .end array-data

    nop

    :array_a4e
    .array-data 1
        0xdt
        -0x16t
        0x61t
        -0x21t
        0x6t
        0x1bt
        -0x46t
        0x3ft
    .end array-data

    :array_a56
    .array-data 1
        0x49t
        -0x60t
        0x3dt
        0x7ft
        -0x74t
        -0x5et
        0x7et
        0x0t
    .end array-data

    :array_a5e
    .array-data 1
        0x3ft
        -0x31t
        0x59t
        0x20t
        -0x1et
        -0x3dt
        0x13t
        0x65t
    .end array-data

    :array_a66
    .array-data 1
        -0x22t
        0x45t
        0x7ct
        0x2ft
        -0x9t
        -0x7t
        -0x2et
    .end array-data

    :array_a6e
    .array-data 1
        -0x58t
        0x2at
        0x18t
        0x70t
        -0x79t
        -0x70t
        -0x4ft
        -0x2ct
    .end array-data

    :array_a76
    .array-data 1
        -0x71t
        -0x25t
        0x68t
        -0x15t
        0x39t
        -0xct
        0x1ft
        -0x16t
        -0x75t
        -0x21t
        0x7ft
    .end array-data

    :array_a80
    .array-data 1
        -0x7t
        -0x4ct
        0xct
        -0x4ct
        0x4bt
        -0x6ft
        0x72t
        -0x75t
    .end array-data

    :array_a88
    .array-data 1
        -0x33t
        -0x6et
        -0x69t
        -0x45t
        -0x9t
        0x5et
        0x2t
        -0x75t
        -0x37t
    .end array-data

    nop

    :array_a92
    .array-data 1
        -0x43t
        -0xdt
        -0x10t
        -0x22t
        -0x6ct
        0x31t
        0x77t
        -0x1bt
    .end array-data

    :array_a9a
    .array-data 1
        -0x4t
        0x4at
        0x63t
        0x6ft
    .end array-data

    :array_aa0
    .array-data 1
        -0x70t
        0x23t
        0x10t
        0x1bt
        -0x20t
        -0x36t
        -0x3et
        0x4bt
    .end array-data
.end method

.method public detailContent(Ljava/util/List;)Ljava/lang/String;
    .registers 22
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    new-instance v2, Lorg/json/JSONObject;

    const/4 v3, 0x0

    invoke-interface {v1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-direct {v2, v4}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/16 v4, 0x9

    new-array v4, v4, [B

    fill-array-data v4, :array_6a8

    const/16 v5, 0x8

    new-array v6, v5, [B

    fill-array-data v6, :array_6b2

    invoke-static {v4, v6}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/16 v6, 0xd

    new-array v6, v6, [B

    fill-array-data v6, :array_6ba

    new-array v7, v5, [B

    fill-array-data v7, :array_6c6

    invoke-static {v6, v7}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    const/16 v2, 0xf

    new-array v6, v2, [B

    fill-array-data v6, :array_6ce

    new-array v7, v5, [B

    fill-array-data v7, :array_6da

    invoke-static {v6, v7}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-direct {v0, v4, v6}, Lcom/github/catvod/spider/SP360;->c(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    new-instance v7, Lorg/json/JSONObject;

    invoke-direct {v7, v6}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x4

    new-array v6, v6, [B

    fill-array-data v6, :array_6e2

    new-array v8, v5, [B

    fill-array-data v8, :array_6e8

    invoke-static {v6, v8}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v7, v6}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v6

    const/4 v7, 0x5

    new-array v7, v7, [B

    fill-array-data v7, :array_6f0

    new-array v8, v5, [B

    fill-array-data v8, :array_6f8

    invoke-static {v7, v8}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const/16 v8, 0xc

    new-array v8, v8, [B

    fill-array-data v8, :array_700

    new-array v9, v5, [B

    fill-array-data v9, :array_70a

    invoke-static {v8, v9}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v6, v8}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v8

    const/16 v9, 0xe

    new-array v10, v9, [B

    fill-array-data v10, :array_712

    new-array v11, v5, [B

    fill-array-data v11, :array_71e

    invoke-static {v10, v11}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v6, v10}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v10

    new-instance v11, Ljava/util/LinkedHashMap;

    invoke-direct {v11}, Ljava/util/LinkedHashMap;-><init>()V

    new-array v12, v2, [B

    fill-array-data v12, :array_726

    new-array v13, v5, [B

    fill-array-data v13, :array_732

    invoke-static {v12, v13}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v6, v12}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v12

    new-array v9, v9, [B

    fill-array-data v9, :array_73a

    new-array v13, v5, [B

    fill-array-data v13, :array_746

    invoke-static {v9, v13}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v6, v9}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v9

    const/16 v13, 0xa

    new-array v14, v13, [B

    fill-array-data v14, :array_74e

    new-array v15, v5, [B

    fill-array-data v15, :array_758

    invoke-static {v14, v15}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v4, v14}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v14

    invoke-virtual {v4, v3, v14}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x7

    const/4 v14, 0x6

    if-eqz v8, :cond_2d4

    const/4 v8, 0x0

    :goto_e6
    invoke-virtual {v9}, Lorg/json/JSONArray;->length()I

    move-result v10

    if-ge v8, v10, :cond_4cd

    invoke-virtual {v9, v8}, Lorg/json/JSONArray;->get(I)Ljava/lang/Object;

    move-result-object v10

    invoke-static {v10}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v10

    iget-object v12, v0, Lcom/github/catvod/spider/SP360;->b:Ljava/lang/String;

    invoke-virtual {v12, v10}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v12

    if-eqz v12, :cond_fe

    goto/16 :goto_2c8

    .line 1
    :cond_fe
    invoke-static {v3}, Lcom/github/catvod/spider/merge/b/t;->c(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    .line 2
    new-array v14, v14, [B

    fill-array-data v14, :array_760

    new-array v15, v5, [B

    fill-array-data v15, :array_768

    .line 3
    invoke-static {v14, v15, v12, v10}, Lcom/github/catvod/spider/merge/b/v;->a([B[BLjava/lang/StringBuilder;Ljava/lang/String;)V

    .line 4
    new-array v13, v13, [B

    fill-array-data v13, :array_770

    new-array v14, v5, [B

    fill-array-data v14, :array_77a

    .line 5
    invoke-static {v13, v14, v12}, Lcom/github/catvod/spider/merge/b/t;->b([B[BLjava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v12

    .line 6
    new-array v2, v2, [B

    fill-array-data v2, :array_782

    new-array v13, v5, [B

    fill-array-data v13, :array_78e

    invoke-static {v2, v13}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v12, v2}, Lcom/github/catvod/spider/SP360;->c(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    new-instance v12, Lorg/json/JSONObject;

    invoke-direct {v12, v2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x4

    new-array v2, v2, [B

    fill-array-data v2, :array_796

    new-array v13, v5, [B

    fill-array-data v13, :array_79c

    invoke-static {v2, v13}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v12, v2}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    const/16 v12, 0x9

    new-array v12, v12, [B

    fill-array-data v12, :array_7a4

    new-array v5, v5, [B

    fill-array-data v5, :array_7ae

    invoke-static {v12, v5}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    invoke-virtual {v2, v10}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_16e

    invoke-virtual {v2, v10}, Lorg/json/JSONObject;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v2

    goto :goto_16f

    :cond_16e
    const/4 v2, 0x0

    :goto_16f
    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    const/4 v12, 0x0

    :goto_175
    if-ge v12, v2, :cond_2a8

    add-int/lit16 v13, v12, 0xc8

    if-le v13, v2, :cond_17d

    move v14, v2

    goto :goto_17e

    :cond_17d
    move v14, v13

    :goto_17e
    add-int/lit8 v12, v12, 0x1

    .line 7
    invoke-static {v3}, Lcom/github/catvod/spider/merge/b/t;->c(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v15

    .line 8
    new-array v4, v4, [B

    fill-array-data v4, :array_7b6

    move/from16 v16, v2

    const/16 v2, 0x8

    move/from16 v17, v13

    new-array v13, v2, [B

    fill-array-data v13, :array_7be

    invoke-static {v4, v13}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v15, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v15, v12}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    new-array v4, v4, [B

    fill-array-data v4, :array_7c6

    new-array v12, v2, [B

    fill-array-data v12, :array_7ce

    invoke-static {v4, v12}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v15, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v15, v14}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    new-array v4, v4, [B

    fill-array-data v4, :array_7d6

    new-array v12, v2, [B

    fill-array-data v12, :array_7de

    .line 9
    invoke-static {v4, v12, v15, v10}, Lcom/github/catvod/spider/merge/b/v;->a([B[BLjava/lang/StringBuilder;Ljava/lang/String;)V

    const/16 v4, 0xa

    new-array v4, v4, [B

    .line 10
    fill-array-data v4, :array_7e6

    new-array v12, v2, [B

    fill-array-data v12, :array_7f0

    .line 11
    invoke-static {v4, v12, v15}, Lcom/github/catvod/spider/merge/b/t;->b([B[BLjava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v4

    const/16 v12, 0xf

    new-array v12, v12, [B

    .line 12
    fill-array-data v12, :array_7f8

    new-array v13, v2, [B

    fill-array-data v13, :array_804

    invoke-static {v12, v13}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-direct {v0, v4, v12}, Lcom/github/catvod/spider/SP360;->c(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    new-instance v12, Lorg/json/JSONObject;

    invoke-direct {v12, v4}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x4

    new-array v4, v4, [B

    fill-array-data v4, :array_80c

    new-array v13, v2, [B

    fill-array-data v13, :array_812

    invoke-static {v4, v13}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v12, v4}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v4

    const/16 v12, 0xc

    new-array v12, v12, [B

    fill-array-data v12, :array_81a

    new-array v2, v2, [B

    fill-array-data v2, :array_824

    invoke-static {v12, v2}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v4, v2}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    invoke-virtual {v2, v10}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v2

    if-nez v2, :cond_219

    goto/16 :goto_2a1

    :cond_219
    const/4 v4, 0x0

    :goto_21a
    invoke-virtual {v2}, Lorg/json/JSONArray;->length()I

    move-result v12

    if-ge v4, v12, :cond_2a1

    invoke-virtual {v2, v4}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v12

    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v14, 0x3

    new-array v14, v14, [B

    fill-array-data v14, :array_82c

    const/16 v15, 0x8

    move-object/from16 v18, v2

    new-array v2, v15, [B

    fill-array-data v2, :array_832

    invoke-static {v14, v2}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v13, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v2, 0xc

    new-array v2, v2, [B

    fill-array-data v2, :array_83a

    new-array v14, v15, [B

    fill-array-data v14, :array_844

    invoke-static {v2, v14}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v12, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v13, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    new-array v2, v2, [B

    fill-array-data v2, :array_84c

    new-array v14, v15, [B

    fill-array-data v14, :array_852

    .line 13
    invoke-static {v2, v14, v13}, Lcom/github/catvod/spider/merge/b/t;->b([B[BLjava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v2

    const/4 v13, 0x3

    new-array v13, v13, [B

    .line 14
    fill-array-data v13, :array_85a

    new-array v14, v15, [B

    fill-array-data v14, :array_860

    invoke-static {v13, v14}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    .line 15
    invoke-static {v2}, Lcom/github/catvod/spider/merge/b/t;->c(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const/4 v13, 0x1

    new-array v13, v13, [B

    const/16 v14, 0x2e

    const/16 v19, 0x0

    aput-byte v14, v13, v19

    new-array v14, v15, [B

    .line 16
    fill-array-data v14, :array_868

    invoke-static {v13, v14}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v2, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v4, v4, 0x1

    move-object/from16 v2, v18

    goto/16 :goto_21a

    :cond_2a1
    :goto_2a1
    const/4 v4, 0x7

    move/from16 v2, v16

    move/from16 v12, v17

    goto/16 :goto_175

    :cond_2a8
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-lez v2, :cond_2c8

    const/4 v2, 0x1

    new-array v2, v2, [B

    const/16 v4, -0xf

    const/4 v12, 0x0

    aput-byte v4, v2, v12

    const/16 v4, 0x8

    new-array v4, v4, [B

    fill-array-data v4, :array_870

    invoke-static {v2, v4}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2, v5}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v2

    invoke-interface {v11, v10, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_2c8
    :goto_2c8
    add-int/lit8 v8, v8, 0x1

    const/16 v2, 0xf

    const/4 v14, 0x6

    const/16 v5, 0x8

    const/4 v4, 0x7

    const/16 v13, 0xa

    goto/16 :goto_e6

    :cond_2d4
    const/4 v2, 0x0

    if-eqz v10, :cond_45b

    :goto_2d7
    invoke-virtual {v9}, Lorg/json/JSONArray;->length()I

    move-result v4

    if-ge v2, v4, :cond_4cd

    invoke-virtual {v9, v2}, Lorg/json/JSONArray;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    iget-object v5, v0, Lcom/github/catvod/spider/SP360;->b:Ljava/lang/String;

    invoke-virtual {v5, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_2ef

    goto/16 :goto_453

    :cond_2ef
    const/4 v5, 0x3

    new-array v8, v5, [B

    fill-array-data v8, :array_878

    const/16 v10, 0x8

    new-array v12, v10, [B

    fill-array-data v12, :array_87e

    invoke-static {v8, v12}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v6, v8}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v8

    if-eqz v8, :cond_453

    new-array v5, v5, [B

    fill-array-data v5, :array_886

    new-array v8, v10, [B

    fill-array-data v8, :array_88c

    invoke-static {v5, v8}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v6, v5}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v5

    invoke-virtual {v5}, Lorg/json/JSONObject;->keys()Ljava/util/Iterator;

    move-result-object v5

    new-instance v8, Ljava/util/ArrayList;

    invoke-direct {v8}, Ljava/util/ArrayList;-><init>()V

    :cond_321
    :goto_321
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_430

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/String;

    .line 17
    invoke-static {v3}, Lcom/github/catvod/spider/merge/b/t;->c(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    const/4 v13, 0x6

    new-array v13, v13, [B

    .line 18
    fill-array-data v13, :array_894

    const/16 v14, 0x8

    new-array v15, v14, [B

    fill-array-data v15, :array_89c

    .line 19
    invoke-static {v13, v15, v12, v4}, Lcom/github/catvod/spider/merge/b/v;->a([B[BLjava/lang/StringBuilder;Ljava/lang/String;)V

    const/4 v13, 0x6

    new-array v13, v13, [B

    .line 20
    fill-array-data v13, :array_8a4

    new-array v15, v14, [B

    fill-array-data v15, :array_8ac

    .line 21
    invoke-static {v13, v15, v12, v10}, Lcom/github/catvod/spider/merge/b/v;->a([B[BLjava/lang/StringBuilder;Ljava/lang/String;)V

    const/16 v10, 0xa

    new-array v10, v10, [B

    .line 22
    fill-array-data v10, :array_8b4

    new-array v13, v14, [B

    fill-array-data v13, :array_8be

    .line 23
    invoke-static {v10, v13, v12}, Lcom/github/catvod/spider/merge/b/t;->b([B[BLjava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v10

    const/16 v12, 0xf

    new-array v12, v12, [B

    .line 24
    fill-array-data v12, :array_8c6

    new-array v13, v14, [B

    fill-array-data v13, :array_8d2

    invoke-static {v12, v13}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-direct {v0, v10, v12}, Lcom/github/catvod/spider/SP360;->c(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    new-instance v12, Lorg/json/JSONObject;

    invoke-direct {v12, v10}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x4

    new-array v10, v10, [B

    fill-array-data v10, :array_8da

    new-array v13, v14, [B

    fill-array-data v13, :array_8e0

    invoke-static {v10, v13}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v12, v10}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v10

    const/16 v12, 0xe

    new-array v12, v12, [B

    fill-array-data v12, :array_8e8

    new-array v13, v14, [B

    fill-array-data v13, :array_8f4

    invoke-static {v12, v13}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v10, v12}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v10

    if-nez v10, :cond_3a3

    goto/16 :goto_321

    :cond_3a3
    const/4 v12, 0x0

    :goto_3a4
    invoke-virtual {v10}, Lorg/json/JSONArray;->length()I

    move-result v13

    if-ge v12, v13, :cond_321

    invoke-virtual {v10, v12}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v13

    new-instance v14, Ljava/lang/StringBuilder;

    invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v15, 0x6

    new-array v15, v15, [B

    fill-array-data v15, :array_8fc

    move-object/from16 v16, v3

    const/16 v3, 0x8

    move-object/from16 v17, v5

    new-array v5, v3, [B

    fill-array-data v5, :array_904

    invoke-static {v15, v5}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v13, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v14, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, "6A"

    invoke-static {v5}, Lcom/github/catvod/spider/merge/mdw;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v14, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    new-array v5, v5, [B

    fill-array-data v5, :array_90c

    new-array v15, v3, [B

    fill-array-data v15, :array_912

    invoke-static {v5, v15}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v13, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v14, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v14, 0x3

    new-array v14, v14, [B

    fill-array-data v14, :array_91a

    new-array v15, v3, [B

    fill-array-data v15, :array_920

    invoke-static {v14, v15}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v13, v14}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    .line 25
    invoke-static {v5}, Lcom/github/catvod/spider/merge/b/t;->c(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const/4 v14, 0x1

    new-array v14, v14, [B

    const/16 v15, -0x65

    const/16 v18, 0x0

    aput-byte v15, v14, v18

    new-array v3, v3, [B

    .line 26
    fill-array-data v3, :array_928

    invoke-static {v14, v3}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v8, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v12, v12, 0x1

    move-object/from16 v3, v16

    move-object/from16 v5, v17

    goto/16 :goto_3a4

    :cond_430
    move-object/from16 v16, v3

    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-lez v3, :cond_455

    const/4 v3, 0x1

    new-array v3, v3, [B

    const/16 v5, 0x4d

    const/4 v10, 0x0

    aput-byte v5, v3, v10

    const/16 v5, 0x8

    new-array v5, v5, [B

    fill-array-data v5, :array_930

    invoke-static {v3, v5}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3, v8}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v11, v4, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_455

    :cond_453
    :goto_453
    move-object/from16 v16, v3

    :cond_455
    :goto_455
    add-int/lit8 v2, v2, 0x1

    move-object/from16 v3, v16

    goto/16 :goto_2d7

    :cond_45b
    :goto_45b
    invoke-virtual {v9}, Lorg/json/JSONArray;->length()I

    move-result v3

    if-ge v2, v3, :cond_4cd

    invoke-virtual {v9, v2}, Lorg/json/JSONArray;->get(I)Ljava/lang/Object;

    move-result-object v3

    invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    iget-object v4, v0, Lcom/github/catvod/spider/SP360;->b:Ljava/lang/String;

    invoke-virtual {v4, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_472

    goto :goto_4ca

    :cond_472
    invoke-virtual {v12, v3}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v4

    const/16 v5, 0xb

    new-array v5, v5, [B

    fill-array-data v5, :array_938

    const/16 v8, 0x8

    new-array v10, v8, [B

    fill-array-data v10, :array_942

    invoke-static {v5, v10}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v13, 0x7

    new-array v13, v13, [B

    fill-array-data v13, :array_94a

    new-array v14, v8, [B

    fill-array-data v14, :array_952

    invoke-static {v13, v14}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v10, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x1

    new-array v4, v4, [B

    const/16 v10, 0x16

    const/4 v13, 0x0

    aput-byte v10, v4, v13

    new-array v8, v8, [B

    fill-array-data v8, :array_95a

    invoke-static {v4, v8}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4, v5}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v4

    invoke-interface {v11, v3, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :goto_4ca
    add-int/lit8 v2, v2, 0x1

    goto :goto_45b

    :cond_4cd
    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_962

    new-array v4, v2, [B

    fill-array-data v4, :array_96a

    invoke-static {v3, v4}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v6, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/16 v4, 0xd

    new-array v4, v4, [B

    fill-array-data v4, :array_972

    new-array v5, v2, [B

    fill-array-data v5, :array_97e

    invoke-static {v4, v5}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v6, v4}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v4

    invoke-direct {v0, v4}, Lcom/github/catvod/spider/SP360;->a(Lorg/json/JSONArray;)Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x7

    new-array v5, v5, [B

    fill-array-data v5, :array_986

    new-array v8, v2, [B

    fill-array-data v8, :array_98e

    invoke-static {v5, v8}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v6, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const/4 v8, 0x4

    new-array v8, v8, [B

    fill-array-data v8, :array_996

    new-array v9, v2, [B

    fill-array-data v9, :array_99c

    invoke-static {v8, v9}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v6, v8}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v8

    invoke-direct {v0, v8}, Lcom/github/catvod/spider/SP360;->a(Lorg/json/JSONArray;)Ljava/lang/String;

    move-result-object v8

    const/4 v9, 0x5

    new-array v9, v9, [B

    fill-array-data v9, :array_9a4

    new-array v10, v2, [B

    fill-array-data v10, :array_9ac

    invoke-static {v9, v10}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v6, v9}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v9

    invoke-direct {v0, v9}, Lcom/github/catvod/spider/SP360;->a(Lorg/json/JSONArray;)Ljava/lang/String;

    move-result-object v9

    new-array v10, v2, [B

    fill-array-data v10, :array_9b4

    new-array v12, v2, [B

    fill-array-data v12, :array_9bc

    invoke-static {v10, v12}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v6, v10}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v10

    invoke-direct {v0, v10}, Lcom/github/catvod/spider/SP360;->a(Lorg/json/JSONArray;)Ljava/lang/String;

    move-result-object v10

    const/16 v12, 0xb

    new-array v12, v12, [B

    fill-array-data v12, :array_9c4

    new-array v13, v2, [B

    fill-array-data v13, :array_9ce

    invoke-static {v12, v13}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v6, v12}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    new-instance v12, Lorg/json/JSONObject;

    invoke-direct {v12}, Lorg/json/JSONObject;-><init>()V

    const/4 v13, 0x6

    new-array v13, v13, [B

    fill-array-data v13, :array_9d6

    new-array v14, v2, [B

    fill-array-data v14, :array_9de

    invoke-static {v13, v14}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v13

    const/4 v14, 0x0

    invoke-interface {v1, v14}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {v12, v13, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v1, v2, [B

    fill-array-data v1, :array_9e6

    new-array v13, v2, [B

    fill-array-data v13, :array_9ee

    invoke-static {v1, v13}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v12, v1, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v1, 0x7

    new-array v1, v1, [B

    fill-array-data v1, :array_9f6

    new-array v7, v2, [B

    fill-array-data v7, :array_9fe

    invoke-static {v1, v7}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v12, v1, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/16 v1, 0x9

    new-array v1, v1, [B

    fill-array-data v1, :array_a06

    new-array v3, v2, [B

    fill-array-data v3, :array_a10

    invoke-static {v1, v3}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v12, v1, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v1, v2, [B

    fill-array-data v1, :array_a18

    new-array v3, v2, [B

    fill-array-data v3, :array_a20

    invoke-static {v1, v3}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v12, v1, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v1, v2, [B

    fill-array-data v1, :array_a28

    new-array v3, v2, [B

    fill-array-data v3, :array_a30

    invoke-static {v1, v3}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v12, v1, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/16 v1, 0xb

    new-array v1, v1, [B

    fill-array-data v1, :array_a38

    new-array v3, v2, [B

    fill-array-data v3, :array_a42

    invoke-static {v1, v3}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    const-string v3, ""

    invoke-virtual {v12, v1, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/16 v1, 0x9

    new-array v1, v1, [B

    fill-array-data v1, :array_a4a

    new-array v3, v2, [B

    fill-array-data v3, :array_a54

    invoke-static {v1, v3}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v12, v1, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/16 v1, 0xc

    new-array v1, v1, [B

    fill-array-data v1, :array_a5c

    new-array v3, v2, [B

    fill-array-data v3, :array_a66

    invoke-static {v1, v3}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v12, v1, v10}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/16 v1, 0xb

    new-array v1, v1, [B

    fill-array-data v1, :array_a6e

    new-array v3, v2, [B

    fill-array-data v3, :array_a78

    invoke-static {v1, v3}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v12, v1, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-interface {v11}, Ljava/util/Map;->size()I

    move-result v1

    if-lez v1, :cond_680

    const/16 v1, 0xd

    new-array v1, v1, [B

    fill-array-data v1, :array_a80

    new-array v3, v2, [B

    fill-array-data v3, :array_a8c

    invoke-static {v1, v3}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x3

    new-array v3, v3, [B

    fill-array-data v3, :array_a94

    new-array v4, v2, [B

    fill-array-data v4, :array_a9a

    invoke-static {v3, v4}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v11}, Ljava/util/LinkedHashMap;->keySet()Ljava/util/Set;

    move-result-object v4

    invoke-static {v3, v4}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v12, v1, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/16 v1, 0xc

    new-array v1, v1, [B

    fill-array-data v1, :array_aa2

    new-array v3, v2, [B

    fill-array-data v3, :array_aac

    invoke-static {v1, v3}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x3

    new-array v3, v3, [B

    fill-array-data v3, :array_ab4

    new-array v2, v2, [B

    fill-array-data v2, :array_aba

    invoke-static {v3, v2}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v11}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    move-result-object v3

    invoke-static {v2, v3}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v12, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_680
    new-instance v1, Lorg/json/JSONArray;

    invoke-direct {v1}, Lorg/json/JSONArray;-><init>()V

    invoke-virtual {v1, v12}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    move-result-object v1

    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    const/4 v3, 0x4

    new-array v3, v3, [B

    fill-array-data v3, :array_ac2

    const/16 v4, 0x8

    new-array v4, v4, [B

    fill-array-data v4, :array_ac8

    invoke-static {v3, v4}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v1

    invoke-virtual {v1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v1

    return-object v1

    :array_6a8
    .array-data 1
        -0x52t
        0x5ft
        0x8t
        0x10t
        0x4ft
        -0x5at
        -0x45t
        -0x4ct
        -0x5at
    .end array-data

    nop

    :array_6b2
    .array-data 1
        -0x36t
        0x3at
        0x7ct
        0x71t
        0x26t
        -0x36t
        -0x12t
        -0x3at
    .end array-data

    :array_6ba
    .array-data 1
        0x13t
        0x6bt
        0x6bt
        -0x1bt
        0x1bt
        0x4ft
        0x2at
        0x42t
        0x11t
        0x6bt
        0x6dt
        -0x1ft
        0x0t
    .end array-data

    nop

    :array_6c6
    .array-data 1
        0x77t
        0xet
        0x1ft
        -0x7ct
        0x72t
        0x23t
        0x78t
        0x27t
    .end array-data

    :array_6ce
    .array-data 1
        -0x4dt
        -0x13t
        0x6at
        -0x29t
        -0x1t
        -0x1dt
        -0x38t
        0x10t
        -0x1ct
        -0x1dt
        0x7at
        -0x2bt
        -0x52t
        -0x56t
        -0x38t
    .end array-data

    :array_6da
    .array-data 1
        -0x6ft
        -0x80t
        0x19t
        -0x50t
        -0x23t
        -0x27t
        -0x16t
        0x43t
    .end array-data

    :array_6e2
    .array-data 1
        -0x23t
        0x4et
        0x29t
        0x65t
    .end array-data

    :array_6e8
    .array-data 1
        -0x47t
        0x2ft
        0x5dt
        0x4t
        -0x41t
        0x73t
        0x5et
        0x75t
    .end array-data

    :array_6f0
    .array-data 1
        0x34t
        0x4et
        0x3bt
        -0x6t
        -0x62t
    .end array-data

    nop

    :array_6f8
    .array-data 1
        0x40t
        0x27t
        0x4ft
        -0x6at
        -0x5t
        -0x77t
        0x46t
        0x5ft
    .end array-data

    :array_700
    .array-data 1
        -0x6ft
        0x3dt
        -0x79t
        0x60t
        0x37t
        -0x76t
        -0x43t
        -0x4t
        -0x7ct
        0x30t
        -0x7et
        0x69t
    .end array-data

    :array_70a
    .array-data 1
        -0x10t
        0x51t
        -0x15t
        0x5t
        0x47t
        -0x1dt
        -0x27t
        -0x67t
    .end array-data

    :array_712
    .array-data 1
        0x33t
        -0x4dt
        -0x22t
        0x4ft
        0x7ft
        0x65t
        0x1ft
        0x2dt
        0x27t
        -0x41t
        -0x35t
        0x41t
        0x6et
        0x6ct
    .end array-data

    nop

    :array_71e
    .array-data 1
        0x57t
        -0x2at
        -0x48t
        0x2et
        0xat
        0x9t
        0x6bt
        0x48t
    .end array-data

    :array_726
    .array-data 1
        0xat
        0x64t
        -0x6dt
        0x7at
        -0x3ct
        -0x77t
        0x64t
        0x5ct
        0x9t
        0x6ct
        -0x69t
        0x77t
        -0x37t
        -0x77t
        0x66t
    .end array-data

    :array_732
    .array-data 1
        0x7at
        0x8t
        -0xet
        0x3t
        -0x58t
        -0x20t
        0xat
        0x37t
    .end array-data

    :array_73a
    .array-data 1
        0x10t
        -0x5at
        0x49t
        0x69t
        -0x74t
        0x17t
        0x73t
        -0x5ct
        0x3ft
        -0x47t
        0x41t
        0x64t
        -0x7bt
        0xdt
    .end array-data

    nop

    :array_746
    .array-data 1
        0x60t
        -0x36t
        0x28t
        0x10t
        -0x20t
        0x7et
        0x1dt
        -0x31t
    .end array-data

    :array_74e
    .array-data 1
        0x3ct
        -0x56t
        -0x49t
        0x4ft
        0x72t
        -0x52t
        0x76t
        -0x31t
        0x71t
        -0xct
    .end array-data

    nop

    :array_758
    .array-data 1
        0x1at
        -0x37t
        -0x2at
        0x23t
        0x1et
        -0x34t
        0x17t
        -0x54t
    .end array-data

    :array_760
    .array-data 1
        0x7ft
        -0x54t
        0x7dt
        0x13t
        0x65t
        0x3ft
    .end array-data

    nop

    :array_768
    .array-data 1
        0x59t
        -0x21t
        0x14t
        0x67t
        0x0t
        0x2t
        -0x57t
        0x18t
    .end array-data

    :array_770
    .array-data 1
        0x20t
        0x3t
        -0x59t
        0x30t
        0xat
        0x49t
        -0x55t
        -0x34t
        0x6dt
        0x5dt
    .end array-data

    nop

    :array_77a
    .array-data 1
        0x6t
        0x60t
        -0x3at
        0x5ct
        0x66t
        0x2bt
        -0x36t
        -0x51t
    .end array-data

    :array_782
    .array-data 1
        -0x55t
        -0x15t
        0x11t
        -0x54t
        -0x25t
        0x41t
        -0xat
        0x49t
        -0x4t
        -0x1bt
        0x1t
        -0x52t
        -0x76t
        0x8t
        -0xat
    .end array-data

    :array_78e
    .array-data 1
        -0x77t
        -0x7at
        0x62t
        -0x35t
        -0x7t
        0x7bt
        -0x2ct
        0x1at
    .end array-data

    :array_796
    .array-data 1
        0x76t
        -0x3bt
        -0x56t
        0x55t
    .end array-data

    :array_79c
    .array-data 1
        0x12t
        -0x5ct
        -0x22t
        0x34t
        -0x4ct
        -0x56t
        -0x38t
        -0x7et
    .end array-data

    :array_7a4
    .array-data 1
        0x28t
        -0x12t
        -0x4t
        0x4dt
        -0x53t
        0x1et
        -0x4bt
        -0x6bt
        0x26t
    .end array-data

    nop

    :array_7ae
    .array-data 1
        0x49t
        -0x7et
        -0x70t
        0x38t
        -0x23t
        0x77t
        -0x25t
        -0xdt
    .end array-data

    :array_7b6
    .array-data 1
        0x41t
        -0xct
        0x69t
        0x3et
        0x75t
        0x63t
        -0x37t
    .end array-data

    :array_7be
    .array-data 1
        0x67t
        -0x79t
        0x1dt
        0x5ft
        0x7t
        0x17t
        -0xct
        -0x35t
    .end array-data

    :array_7c6
    .array-data 1
        -0x77t
        -0xft
        0x1ct
        0xft
        0x6t
    .end array-data

    nop

    :array_7ce
    .array-data 1
        -0x51t
        -0x6ct
        0x72t
        0x6bt
        0x3bt
        -0x17t
        0x3ct
        -0x77t
    .end array-data

    :array_7d6
    .array-data 1
        0x35t
        -0x75t
        0x27t
        0x43t
        0x50t
        0x7at
    .end array-data

    nop

    :array_7de
    .array-data 1
        0x13t
        -0x8t
        0x4et
        0x37t
        0x35t
        0x47t
        -0x1et
        0x42t
    .end array-data

    :array_7e6
    .array-data 1
        -0x4et
        -0x60t
        -0x3et
        -0x41t
        0x38t
        -0x28t
        0x1dt
        -0x77t
        -0x1t
        -0x2t
    .end array-data

    nop

    :array_7f0
    .array-data 1
        -0x6ct
        -0x3dt
        -0x5dt
        -0x2dt
        0x54t
        -0x46t
        0x7ct
        -0x16t
    .end array-data

    :array_7f8
    .array-data 1
        0x61t
        -0x78t
        -0x73t
        -0x73t
        0x6dt
        -0x7t
        -0x36t
        -0x26t
        0x36t
        -0x7at
        -0x63t
        -0x71t
        0x3ct
        -0x50t
        -0x36t
    .end array-data

    :array_804
    .array-data 1
        0x43t
        -0x1bt
        -0x2t
        -0x16t
        0x4ft
        -0x3dt
        -0x18t
        -0x77t
    .end array-data

    :array_80c
    .array-data 1
        0x14t
        0x3dt
        0x4ft
        0xct
    .end array-data

    :array_812
    .array-data 1
        0x70t
        0x5ct
        0x3bt
        0x6dt
        -0x60t
        0x68t
        -0x6t
        -0x34t
    .end array-data

    :array_81a
    .array-data 1
        0xat
        0x54t
        0x8t
        -0x3t
        0x4ft
        -0x78t
        -0x2et
        -0x18t
        0x1ft
        0x59t
        0xdt
        -0xct
    .end array-data

    :array_824
    .array-data 1
        0x6bt
        0x38t
        0x64t
        -0x68t
        0x3ft
        -0x1ft
        -0x4at
        -0x73t
    .end array-data

    :array_82c
    .array-data 1
        0x11t
        0x49t
        0x68t
    .end array-data

    :array_832
    .array-data 1
        -0xat
        -0x1bt
        -0x3ct
        0x4ct
        -0x46t
        0x66t
        0x41t
        -0x2et
    .end array-data

    :array_83a
    .array-data 1
        -0x19t
        0x58t
        0x5dt
        -0x9t
        0x28t
        -0x1et
        -0x1dt
        -0x25t
        -0x38t
        0x5at
        0x49t
        -0x1dt
    .end array-data

    :array_844
    .array-data 1
        -0x69t
        0x34t
        0x3ct
        -0x72t
        0x44t
        -0x75t
        -0x73t
        -0x50t
    .end array-data

    :array_84c
    .array-data 1
        -0x63t
        -0x67t
        -0x69t
    .end array-data

    :array_852
    .array-data 1
        0x74t
        0x2t
        0x11t
        -0x50t
        -0x1ct
        -0x6bt
        -0x3at
        -0x7et
    .end array-data

    :array_85a
    .array-data 1
        -0x44t
        -0x60t
        -0x7et
    .end array-data

    :array_860
    .array-data 1
        -0x37t
        -0x2et
        -0x12t
        0x2et
        0x6et
        -0x4ft
        0x68t
        -0x59t
    .end array-data

    :array_868
    .array-data 1
        0xat
        0x66t
        0x25t
        -0x67t
        0x18t
        -0x8t
        -0x33t
        0x1et
    .end array-data

    :array_870
    .array-data 1
        -0x2et
        -0x18t
        -0x7bt
        -0x22t
        0x57t
        0x1ct
        0x4at
        0x58t
    .end array-data

    :array_878
    .array-data 1
        0x74t
        -0x65t
        -0xbt
    .end array-data

    :array_87e
    .array-data 1
        0x0t
        -0x6t
        -0x6et
        0x1at
        0x1at
        0x27t
        -0x1t
        0x16t
    .end array-data

    :array_886
    .array-data 1
        0x4bt
        0x15t
        -0x54t
    .end array-data

    :array_88c
    .array-data 1
        0x3ft
        0x74t
        -0x35t
        0x5ct
        0x63t
        -0x58t
        -0x24t
        0x22t
    .end array-data

    :array_894
    .array-data 1
        0x33t
        -0x51t
        0x0t
        -0x4ct
        0x7dt
        -0x44t
    .end array-data

    nop

    :array_89c
    .array-data 1
        0x15t
        -0x24t
        0x69t
        -0x40t
        0x18t
        -0x7ft
        0x58t
        -0x8t
    .end array-data

    :array_8a4
    .array-data 1
        0x59t
        -0x73t
        0x7bt
        -0x1t
        -0x60t
        0x1at
    .end array-data

    nop

    :array_8ac
    .array-data 1
        0x7ft
        -0xct
        0x1et
        -0x62t
        -0x2et
        0x27t
        0x2t
        0x55t
    .end array-data

    :array_8b4
    .array-data 1
        0x2at
        0x71t
        0x5dt
        -0x65t
        -0x12t
        0x77t
        -0x7t
        -0x54t
        0x67t
        0x2ft
    .end array-data

    nop

    :array_8be
    .array-data 1
        0xct
        0x12t
        0x3ct
        -0x9t
        -0x7et
        0x15t
        -0x68t
        -0x31t
    .end array-data

    :array_8c6
    .array-data 1
        0x4ct
        -0x3et
        0x5dt
        0x64t
        -0x47t
        -0x65t
        -0x7bt
        0x58t
        0x1bt
        -0x34t
        0x4dt
        0x66t
        -0x18t
        -0x2et
        -0x7bt
    .end array-data

    :array_8d2
    .array-data 1
        0x6et
        -0x51t
        0x2et
        0x3t
        -0x65t
        -0x5ft
        -0x59t
        0xbt
    .end array-data

    :array_8da
    .array-data 1
        0x4ct
        0x3bt
        -0x32t
        0x37t
    .end array-data

    :array_8e0
    .array-data 1
        0x28t
        0x5at
        -0x46t
        0x56t
        0x32t
        0x65t
        -0x4ct
        0x0t
    .end array-data

    :array_8e8
    .array-data 1
        -0x40t
        -0x1et
        -0x38t
        -0x1dt
        -0x65t
        0x39t
        -0x14t
        -0x54t
        -0x2ct
        -0x12t
        -0x23t
        -0x13t
        -0x76t
        0x30t
    .end array-data

    nop

    :array_8f4
    .array-data 1
        -0x5ct
        -0x79t
        -0x52t
        -0x7et
        -0x12t
        0x55t
        -0x68t
        -0x37t
    .end array-data

    :array_8fc
    .array-data 1
        0x1dt
        0x7ft
        -0x6ft
        0x3t
        -0x4dt
        -0x53t
    .end array-data

    nop

    :array_904
    .array-data 1
        0x6dt
        0x1at
        -0x1dt
        0x6at
        -0x24t
        -0x37t
        0x6ft
        -0x76t
    .end array-data

    :array_90c
    .array-data 1
        -0x10t
        -0xbt
        0x18t
        -0x5ct
    .end array-data

    :array_912
    .array-data 1
        -0x62t
        -0x6ct
        0x75t
        -0x3ft
        -0x2et
        -0x63t
        0x2dt
        -0x38t
    .end array-data

    :array_91a
    .array-data 1
        -0x66t
        0x31t
        0x5at
    .end array-data

    :array_920
    .array-data 1
        -0x11t
        0x43t
        0x36t
        0x5ct
        -0x4et
        -0x52t
        0x4bt
        -0x7at
    .end array-data

    :array_928
    .array-data 1
        -0x41t
        0x64t
        -0x10t
        -0x4ct
        -0x36t
        0x23t
        0x1ft
        0x53t
    .end array-data

    :array_930
    .array-data 1
        0x6et
        0x5t
        -0x5dt
        0x12t
        0x1ft
        -0x63t
        0x25t
        0x5t
    .end array-data

    :array_938
    .array-data 1
        0x10t
        -0x3ct
        -0x70t
        0x4dt
        0xft
        0x6ft
        -0x6bt
        0x4bt
        0x1t
        -0x2dt
        -0x66t
    .end array-data

    :array_942
    .array-data 1
        0x74t
        -0x5ft
        -0xat
        0x2ct
        0x7at
        0x3t
        -0x1ft
        0x14t
    .end array-data

    :array_94a
    .array-data 1
        -0x79t
        0x65t
        0x36t
        0x3at
        -0xct
        -0x48t
        0x67t
    .end array-data

    :array_952
    .array-data 1
        0x61t
        -0x38t
        -0x6bt
        -0x23t
        0x7dt
        0x3ft
        0x43t
        0x2t
    .end array-data

    :array_95a
    .array-data 1
        0x35t
        -0x8t
        0x57t
        0x2et
        -0x1dt
        0x5t
        -0x3dt
        0x78t
    .end array-data

    :array_962
    .array-data 1
        -0x7at
        0x73t
        -0xdt
        -0x2ft
        -0x64t
        -0x3ft
        0x60t
        -0x55t
    .end array-data

    :array_96a
    .array-data 1
        -0x1bt
        0x17t
        -0x63t
        -0x4et
        -0xdt
        -0x49t
        0x5t
        -0x27t
    .end array-data

    :array_972
    .array-data 1
        0xdt
        -0x3t
        -0x21t
        -0x5et
        -0x56t
        -0x31t
        0x70t
        -0x54t
        0x5t
        -0xbt
        -0x3at
        -0x47t
        -0x4at
    .end array-data

    nop

    :array_97e
    .array-data 1
        0x60t
        -0x6et
        -0x57t
        -0x35t
        -0x31t
        -0x54t
        0x11t
        -0x28t
    .end array-data

    :array_986
    .array-data 1
        0x50t
        -0x4t
        0x29t
        -0x13t
        -0x33t
        0x31t
        -0x50t
    .end array-data

    :array_98e
    .array-data 1
        0x20t
        -0x77t
        0x4bt
        -0x77t
        -0x54t
        0x45t
        -0x2bt
        0x44t
    .end array-data

    :array_996
    .array-data 1
        -0x39t
        0x4at
        0x42t
        -0x2t
    .end array-data

    :array_99c
    .array-data 1
        -0x5at
        0x38t
        0x27t
        -0x61t
        -0x42t
        0x18t
        -0x32t
        0x2bt
    .end array-data

    :array_9a4
    .array-data 1
        -0x3t
        -0x7ft
        0x4ft
        0x36t
        0x36t
    .end array-data

    nop

    :array_9ac
    .array-data 1
        -0x64t
        -0x1et
        0x3bt
        0x59t
        0x44t
        -0x1at
        -0x3bt
        -0x41t
    .end array-data

    :array_9b4
    .array-data 1
        0x2dt
        -0x2ft
        0x21t
        0x59t
        0x4dt
        -0x6et
        0x1ft
        -0xft
    .end array-data

    :array_9bc
    .array-data 1
        0x49t
        -0x48t
        0x53t
        0x3ct
        0x2et
        -0x1at
        0x70t
        -0x7dt
    .end array-data

    :array_9c4
    .array-data 1
        0x34t
        0x56t
        0x24t
        -0x50t
        -0x46t
        -0x23t
        0x22t
        -0x41t
        0x39t
        0x5ct
        0x39t
    .end array-data

    :array_9ce
    .array-data 1
        0x50t
        0x33t
        0x57t
        -0x2dt
        -0x38t
        -0x4ct
        0x52t
        -0x35t
    .end array-data

    :array_9d6
    .array-data 1
        -0x13t
        -0x5ct
        -0x48t
        -0x32t
        -0x73t
        -0x7dt
    .end array-data

    nop

    :array_9de
    .array-data 1
        -0x65t
        -0x35t
        -0x24t
        -0x6ft
        -0x1ct
        -0x19t
        -0x29t
        -0x15t
    .end array-data

    :array_9e6
    .array-data 1
        -0x2dt
        0x60t
        -0x72t
        -0x3dt
        -0x74t
        0x46t
        -0x1bt
        -0x14t
    .end array-data

    :array_9ee
    .array-data 1
        -0x5bt
        0xft
        -0x16t
        -0x64t
        -0x1et
        0x27t
        -0x78t
        -0x77t
    .end array-data

    :array_9f6
    .array-data 1
        -0xbt
        -0x36t
        0x76t
        0x51t
        0x1ft
        -0x49t
        0x6ft
    .end array-data

    :array_9fe
    .array-data 1
        -0x7dt
        -0x5bt
        0x12t
        0xet
        0x6ft
        -0x22t
        0xct
        0x66t
    .end array-data

    :array_a06
    .array-data 1
        -0x30t
        -0x4ct
        -0x1et
        0x40t
        0x67t
        -0xat
        -0x7et
        -0x38t
        -0x3ft
    .end array-data

    nop

    :array_a10
    .array-data 1
        -0x5ct
        -0x33t
        -0x6et
        0x25t
        0x38t
        -0x68t
        -0x1dt
        -0x5bt
    .end array-data

    :array_a18
    .array-data 1
        -0x13t
        -0x65t
        0x76t
        -0x21t
        -0x77t
        -0x49t
        0x6at
        -0x4ct
    .end array-data

    :array_a20
    .array-data 1
        -0x65t
        -0xct
        0x12t
        -0x80t
        -0x10t
        -0x2et
        0xbt
        -0x3at
    .end array-data

    :array_a28
    .array-data 1
        0x17t
        -0x59t
        -0x59t
        -0x3dt
        -0x80t
        -0x6dt
        0x70t
        -0x52t
    .end array-data

    :array_a30
    .array-data 1
        0x61t
        -0x38t
        -0x3dt
        -0x64t
        -0x1ft
        -0x1ft
        0x15t
        -0x31t
    .end array-data

    :array_a38
    .array-data 1
        -0x47t
        0x37t
        -0x6dt
        -0x1t
        0x54t
        0x3ft
        -0x7t
        -0x4at
        -0x43t
        0x33t
        -0x7ct
    .end array-data

    :array_a42
    .array-data 1
        -0x31t
        0x58t
        -0x9t
        -0x60t
        0x26t
        0x5at
        -0x6ct
        -0x29t
    .end array-data

    :array_a4a
    .array-data 1
        0x57t
        -0x3t
        -0xet
        -0x16t
        0x50t
        0x52t
        0x19t
        0x3et
        0x53t
    .end array-data

    nop

    :array_a54
    .array-data 1
        0x21t
        -0x6et
        -0x6at
        -0x4bt
        0x31t
        0x31t
        0x6dt
        0x51t
    .end array-data

    :array_a5c
    .array-data 1
        0x1ct
        -0x74t
        -0x1bt
        0x14t
        0x5at
        0x2at
        -0x45t
        0x12t
        0x9t
        -0x69t
        -0x12t
        0x39t
    .end array-data

    :array_a66
    .array-data 1
        0x6at
        -0x1dt
        -0x7ft
        0x4bt
        0x3et
        0x43t
        -0x37t
        0x77t
    .end array-data

    :array_a6e
    .array-data 1
        0x3ct
        0x7ft
        -0x2ct
        0x55t
        -0x6at
        -0x68t
        0x60t
        -0x6bt
        0x2ft
        0x7et
        -0x3ct
    .end array-data

    :array_a78
    .array-data 1
        0x4at
        0x10t
        -0x50t
        0xat
        -0xbt
        -0x9t
        0xet
        -0x1ft
    .end array-data

    :array_a80
    .array-data 1
        0x5ct
        -0x67t
        0x7ct
        0x4at
        -0x2ct
        0x47t
        -0x5at
        0x7ct
        0x75t
        -0x70t
        0x6at
        0x7at
        -0x37t
    .end array-data

    nop

    :array_a8c
    .array-data 1
        0x2at
        -0xat
        0x18t
        0x15t
        -0x5ct
        0x2bt
        -0x39t
        0x5t
    .end array-data

    :array_a94
    .array-data 1
        -0x48t
        -0x54t
        0x7bt
    .end array-data

    :array_a9a
    .array-data 1
        -0x64t
        -0x78t
        0x5ft
        0x3t
        0x73t
        -0x2bt
        -0x15t
        0x1et
    .end array-data

    :array_aa2
    .array-data 1
        0x2bt
        -0x21t
        0x6ct
        0x56t
        -0x67t
        0x7et
        -0x48t
        0x42t
        0x2t
        -0x3bt
        0x7at
        0x65t
    .end array-data

    :array_aac
    .array-data 1
        0x5dt
        -0x50t
        0x8t
        0x9t
        -0x17t
        0x12t
        -0x27t
        0x3bt
    .end array-data

    :array_ab4
    .array-data 1
        -0x5t
        -0x37t
        0x4bt
    .end array-data

    :array_aba
    .array-data 1
        -0x21t
        -0x13t
        0x6ft
        -0x74t
        -0xet
        -0x73t
        0x20t
        0x36t
    .end array-data

    :array_ac2
    .array-data 1
        0x1bt
        0x6bt
        -0x50t
        -0x11t
    .end array-data

    :array_ac8
    .array-data 1
        0x77t
        0x2t
        -0x3dt
        -0x65t
        0x6at
        0x61t
        0x1ct
        0x35t
    .end array-data
.end method

.method public homeContent(Z)Ljava/lang/String;
    .registers 13

    new-instance p1, Lorg/json/JSONArray;

    invoke-direct {p1}, Lorg/json/JSONArray;-><init>()V

    const/4 v0, 0x4

    new-array v1, v0, [Ljava/lang/String;

    const/4 v2, 0x1

    new-array v3, v2, [B

    const/16 v4, -0x75

    const/4 v5, 0x0

    aput-byte v4, v3, v5

    const/16 v4, 0x8

    new-array v6, v4, [B

    fill-array-data v6, :array_114

    invoke-static {v3, v6}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    aput-object v3, v1, v5

    new-array v3, v2, [B

    const/16 v6, -0x53

    aput-byte v6, v3, v5

    new-array v6, v4, [B

    fill-array-data v6, :array_11c

    invoke-static {v3, v6}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    aput-object v3, v1, v2

    new-array v3, v2, [B

    const/16 v6, -0x36

    aput-byte v6, v3, v5

    new-array v6, v4, [B

    fill-array-data v6, :array_124

    invoke-static {v3, v6}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x2

    aput-object v3, v1, v6

    new-array v3, v2, [B

    const/16 v7, -0xc

    aput-byte v7, v3, v5

    new-array v7, v4, [B

    fill-array-data v7, :array_12c

    invoke-static {v3, v7}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x3

    aput-object v3, v1, v7

    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    new-array v0, v0, [Ljava/lang/String;

    const/4 v3, 0x6

    new-array v8, v3, [B

    fill-array-data v8, :array_134

    new-array v9, v4, [B

    fill-array-data v9, :array_13c

    invoke-static {v8, v9}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    aput-object v8, v0, v5

    const/16 v8, 0x9

    new-array v9, v8, [B

    fill-array-data v9, :array_144

    new-array v10, v4, [B

    fill-array-data v10, :array_14e

    invoke-static {v9, v10}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v9

    aput-object v9, v0, v2

    new-array v2, v3, [B

    fill-array-data v2, :array_156

    new-array v9, v4, [B

    fill-array-data v9, :array_15e

    invoke-static {v2, v9}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v6

    new-array v2, v3, [B

    fill-array-data v2, :array_166

    new-array v3, v4, [B

    fill-array-data v3, :array_16e

    invoke-static {v2, v3}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v7

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    :goto_9f
    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v2

    const/4 v3, 0x7

    if-ge v5, v2, :cond_db

    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    new-array v3, v3, [B

    fill-array-data v3, :array_176

    new-array v6, v4, [B

    fill-array-data v6, :array_17e

    invoke-static {v3, v6}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v1, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v2, v3, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v3, v8, [B

    fill-array-data v3, :array_186

    new-array v6, v4, [B

    fill-array-data v6, :array_190

    invoke-static {v3, v6}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v0, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v2, v3, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {p1, v2}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    add-int/lit8 v5, v5, 0x1

    goto :goto_9f

    :cond_db
    new-instance v0, Lorg/json/JSONObject;

    const-string v1, "31704B697C6E11295820233768685A6925222B2109696A6E683C1B26236C707258ACF7F5AFCCF1696A6E68241B27332B68685A103D6C2470406B64ABCFFA93C8EEA9FBE99FD5CD6C6672583D64746A7058366A6E317014697C6E68B7ECD7A3C7ED70566B643868685A69A3D8D6B7F3EC643366720169286C707258ACCEFFACD1FF696A6E68245871666CADDACBADC5CB682F566B3D6C2470406B64ABC0FA9EF6DA6C6672583D64746A709FC1EEAAF7CE58366A6E317014697C6E68B4FBDBA0CEDC70566B643868685A69A0CFDAB4FADD643366720169286C707258ACE1DFAFEBC1696A6E68245871666CADF5EBAEFFF5682F566B3D6C2470406B64ABC3F59CC8C36C6672583D64746A709FC2E1A8C9D758366A6E317014697C6E68B5F0E4A1F3E070566B643868685A69A1C4E5B5C7E1643366720169286C707258AEE3C9AFEBC1696A6E68245871666CAFF7FDAEFFF5682F566B3D6C2470406B64A8C2CA9EF1CF6C6672583D64746A709CC3DEAAF0DB58366A6E317014697C6E68B4F8E7A1D8DB70566B643868685A69A0CCE6B5ECDA643366720169286C707258AECCE6ADC6C1696A6E68245871666CAFD8D2ACD2F5682F566B3D6C2470406B64A8DCD592C2FC6C6672583D64746A709CDDC1A6C3E858366A6E317014697C6E68BAD4FBA3F3DF70566B643868685A69AEE0FAB7C7DE643366720169286C707258AFFAEEA2FCCA696A6E68245871666CAEEEDAA3E8FE682F566B3D6C2470406B64A8E7DE92C3D86C6672583D64746A709CE6CAA6C2CC58366A6E317014697C6E68B7F5EFAEEDCF70566B643868685A69A3C1EEBAD9CE643366720169286C707258AEC8C8AFDDC8696A6E68245871666CAFDCFCAEC9FC682F566B3D6C2470406B64A8C9D89CC9DC6C6672583D64746A709CC8CCA8C8C858366A6E317014697C6E68B6C6EDA1DECC70566B643868685A69A2F2ECB5EACD643366720169286C707258AEC3F8AEE9EC696A6E68245871666CAFD7CCAFFDD8682F27366A6E3170112E3F6C70725832232F3870566B64202B3F1F697C6E68B7C3FFA2F5E970566B64382B3E0F2E64746A090169286C707258AEC3E6A3D1D2AEFFFAAEE9D9696A6E68245871666C682F566B3D6C2470406B647C7A604E696A6E68245871666C7862487F643366720169286C70725879767C7970566B643868685A69747E786158366A6E317014697C6E68604A79746C6672583D64746A70487B747C682F566B3D6C2470406B647C7A604B696A6E68245871666C7862487A643366720169286C70725879767C7A70566B643868685A69747E786258366A6E317014697C6E68604A7A7F6C6672583D64746A70487B7777682F566B3D6C2470406B647C7A6342696A6E68245871666C78624B73643366720169286C70725879767F7D70566B643868685A69747E7B6558366A6E317014697C6E68604A7A706C6672583D64746A70487B7778682F566B3D6C2470406B647C7A634F696A6E68245871666C78624B7E643366720169286C70725879767F7E70566B643868685A69747E7B6658366A6E317014697C6E68604A7A756C6672583D64746A70487B777D682F566B3D6C2470406B647C7A6348696A6E68245871666C78624B79643366720169286C70725879767F7B70566B643868685A69747E7B6358366A6E317014697C6E68604A7A766C6672583D64746A70487B777E682F566B3D6C2470406B647C7A6243696A6E68245871666C78624A72643366720169286C70725879767E7270566B643868685A69747E7A6A58366A6E317014697C6E68604A7B716C6672583D64746A70487B7679682F566B3D6C2470406B64A8D1E69CDCEF6C6672583D64746A709CD0F2A8DDFB58361B33667201692D2B3370406B642F38371B696A6E683C1B26236C707258AEDAFEAFDEC0696A6E68241B27332B68685A103D6C2470406B64ABCFFA93C8EEABD6E29FC7FC6C6672583D64746A7058366A6E317014697C6E68B7FCCEA3D2FA70566B643868685A69A3EAEDBBE3CD643366720169286C707258AFFEE3AFC9C7A2E0D7ACEAD5696A6E68245871666CA3F4E3ADFEE1682F566B3D6C2470406B64AAF2FF9FD0FBABC5E29CF2F86C6672583D64746A709FC4F6A8F3EC58366A6E317014697C6E68B4C9FBA3D5F770566B643868685A69A0FDFAB7E1F6643366720169286C707258ACF8C0AFC9C7696A6E68245871666CADECF4AEDDF3682F566B3D6C2470406B64A7D5FB9FD0FB6C6672583D64746A7093D4EFABD1EF58366A6E317014697C6E68B4EDEEA0D2E670566B643868685A69A0D9EFB4E6E7643366720169286C707258ADF5DBAFC9C7696A6E68245871666CACE1EFAEDDF3682F566B3D6C2470406B64A6C1E39FD0FB6C6672583D64746A7092C0F7ABD1EF58366A6E317014697C6E68B7C4FCA3D5F770566B643868685A69A3F0FDB7E1F6643366720169286C707258AECBFEAFE8DC696A6E68245871666CAFDFCAAEFCE8682F566B3D6C2470406B64ABCFE49EF0D06C6672583D64746A709FCEF0AAF1C458361B33667201692D2B3370406B642F2926153964626A70142A2B2B68685A69A0D6C4B4E2D464626A700C2A2A3B2F70406B1D35683C5871666CAFD7D2A2C5E6ACCAF4ADDED1687E5A69306C707258693B626A29582564746A709CC3D6A7F4CB5867666C3C70406B64A8C2C293F5DF6C377E5A30642068685A69A3DFE2B4E2D4AFE7FA70566B643868685A69A3DFE2B4E2D4AFE7FA7007676635683C5871666CACCFF4A3F9D0ACCFCA696A6E68245871666CACCFF4A3F9D0ACCFCA693B626A29582564746A709CD5D1A8E7F192C0F76C6672583D64746A709CD5D1A8E7F192C0F76C377E5A30642068685A69A3DEFEB6C0E764626A700C697C6E68B7EAFFA2F4E67007676635683C5871666CAFECEAAEF5EB687E5A69306C707258AEF8DEAFE1DF693B626A29582564746A7093F0C2A8F2F65867666C3C70406B64A7F1D69CF3E26C377E5A30642068685A69A1C0C1B7D4D6A3F2F070566B643868685A69A1C0C1B7D4D6A3F2F07007676635683C5871666CACCFF4AEF6C1A3ECE3696A6E68245871666CACCFF4AEF6C1A3ECE3693B626A29582564746A709FF7E6ABD1EF92C6E56C6672583D64746A709FF7E6ABD1EF92C6E56C377E5A30642068685A69A0FAE0BBFDDAA3E0D770566B643868685A69A0FAE0BBFDDAA3E0D77007676635683C5871666CAFF5E6ADD0C9687E5A69306C707258AEE1D2ACC4FD693B626A29582564746A709CF9CEA6CFEC5867666C3C70406B64A8F8DA92CEF86C377E5A30642068685A69AFCCD9BACCCE64626A700C697C6E68BBF8D8AEF8CF7007676635683C5871666CAFE5D3AFF9DE687E5A69306C707258AEF1E7AEEDEA693B626A29582564746A7093E2EAAAF2EF5867666C3C70406B64A7E3FE9EF3FB6C377E5A30642068685A69AFD9E1B7DCE564626A700C697C6E68BBEDE0A3E8E47007676635683C5871666CAFC3D2AEC0E2A3C9D2696A6E68245871666CAFC3D2AEC0E2A3C9D2693B626A29582564746A709FC3DEA8D2D89DCFF06C6672583D64746A709FC3DEA8D2D89DCFF06C377E5A30642068685A69A0FFEEB7EEE464626A700C697C6E68B4CBEFA3DAE57007676635683C5871666CA2DAE8ADF1C9687E5A69306C707258A3CEDCACE5FD693B626A29582564746A709DD2FBA9D3EC9EF6D36C6672583D64746A709DD2FBA9D3EC9EF6D36C370F0767663568391F3264746A70183264626A70142A2B2B68685A69A0C0D8B7C0C464626A700C2A2A3B2F70406B1D35683C5871666CACCEFAA3F9DFADD1D7ADDEEE687E5A69306C707258392720213A153F643366720169286C707258ADDACEA2EDEBAFFEC4ACCADA696A6E68245871666C383314202A2F3E37093F643366720169286C707258ADDACEAFDDEDAEE3F3A2FDFE696A6E68245871666C383314203621233C0E693B13370F566B647C68685A103D6C213703697C6E6831162A353D687E5A69282F27375871666CADE3C1AED8C5687E5A69302F26271F697C6E1129582564746A709FCEEEA7C9FA9DFAFDABD4D95867666C3C70406B646C377E5A30642068685A69AEE6CAB4F9CE64626A700C697C6E68BAD2CBA0CDCF7007676635683C5871666CAFDBDDADC5CB687E5A69306C707258AECFE9ACD1FF693B626A29582564746A709EF7E0A9DAD45867666C3C70406B64AAF6F49DDBC06C377E5A30642068685A69A3D8D6B7F3EC64626A700C697C6E68B7ECD7A3C7ED7007676635683C5871666CACD0D6ACD0DF687E5A69306C707258ADC4E2ADC4EB693B626A29582564746A7093C8FBABF2D05867666C3C70406B64A7C9EF9FF3C46C377E5A30642068685A69A3CFFCB7F9C464626A700C697C6E68B7FBFDA3CDC57007676635683C5871666CAFDDDEA3E5CB687E5A69306C707258AEC9EAA2F1FF693B626A29582564746A709FCDDDAAF0D95867666C3C70406B64ABCCC99EF1CD6C377E5A30642068685A69AEE3ECB7F6E164626A700C697C6E68BAD7EDA3C2E07007676635683C5871666CAFDCFCAEC9FC687E5A69306C707258AEC8C8AFDDC8693B626A29582564746A709FC1F7ABF5C55867666C3C70406B64ABC0E39FF4D16C377E5A30642068685A69A1EBD4BAD5D664626A700C697C6E68B5DFD5AEE1D77007676635683C5871666CA2E2F7ADCED6687E5A69306C707258A3F6C3ACDAE2693B626A29582564746A7093D6D4A8D2F75867666C3C70406B64A7D7C09CD3E36C377E5A30642068685A69A3E0FCB7C0E664626A700C697C6E68B7D4FDA3F4E77007676635683C5871666CAFD8D2AFFBD2687E5A69306C707258AECCE6AEEFE6693B626A29582564746A709CC8C3A8D3FD5867666C3C70406B64A8C9D79CD2E96C377E5A30642068685A69A0E3ECB6C4EB64626A700C697C6E68B4D7EDA2F0EA7007676635683C5871666CADF5EBAEFFF5687E5A69306C707258ACE1DFAFEBC1693B626A29582564746A709FCEF0AAF1C45867666C3C70406B64ABCFE49EF0D06C370F0767663568391F3264746A70032E273C687E5A69282F27375871666CAFEBCEAFFDED687E5A69302F26271F697C6E1129582564746A709FCEEEA7C9FA9FF2F2AAF1F15867666C3C70406B646C377E5A30642068685A69747E78665867666C3C70406B647C7A604E693B626A29582564746A70487B747D687E5A69306C70725879767C797007676635683C5871666C7862487964626A700C697C6E68604A79746C377E5A30642068685A69747E78635867666C3C70406B647C7A604B693B626A29582564746A70487B747E687E5A69306C70725879767C7A7007676635683C5871666C78624B7264626A700C697C6E68604A7A7F6C377E5A30642068685A69747E7B6A5867666C3C70406B647C7A6342693B626A29582564746A70487B7779687E5A69306C70725879767F7D7007676635683C5871666C78624B7D64626A700C697C6E68604A7A706C377E5A30642068685A69747E7B675867666C3C70406B647C7A634F693B626A29582564746A70487B777A687E5A69306C70725879767F7E7007676635683C5871666C78624B7864626A700C697C6E68604A7A756C377E5A30642068685A69747E7B605867666C3C70406B647C7A6348693B626A29582564746A70487B777F687E5A69306C70725879767F7B7007676635683C5871666C78624B7B64626A700C697C6E68604A7A766C377E5A30642068685A69747E7A6B5867666C3C70406B647C7A6243693B626A29582564746A70487B7676687E5A69306C70725879767E727007676635683C5871666C78624A7C64626A700C697C6E68604A7B716C377E5A30642068685A69A0D5FEB4EDE264626A700C697C6E68B4E1FFA0D9E37007163B626A295820233768685A69273C2F335867666C2433172E64746A709FD7F6ABC6E85867666C3C33163E236C70722130642068685A69A3CBE2BBF9E3A3D2FAB7F6F164626A700C697C6E687007676635683C5871666CAFD4FFAEDAFE687E5A69306C707258AEC0CBAFCECA693B626A29582564746A709EF3EBABD1EF93EDDFA8F2FD5867666C3C70406B64A7ECCB9CF3E96C377E5A30642068685A69A2F6E7B7E1F6A3C1FAB4C3F564626A700C697C6E68B7F5FBA0F7F47007676635683C5871666CACE1CAAEDDF3687E5A69306C707258ADF5FEAFC9C7693B626A29582564746A709CDCE3A8D6FE5867666C3C70406B64A8DDF79CD7EA6C377E5A30642068685A69AFD1E3B7E1F664626A700C697C6E68BBE5E2A3D5F77007676635683C5871666CADECF4AEDDF3687E5A69306C707258ACF8C0AFC9C7693B626A29582564746A7092C0F7ABD1EF5867666C3C70406B64A6C1E39FD0FB6C377E5A30642068685A69A0D8FAB7F0EBA3D3EB70566B643868685A69A0D8FAB7F0EBA3D3EB7007163B626A295820233768685A69272D3E3D08696A6E683C1B26236C707258ADDEC0ACCAE5696A6E68241B27332B68685A103D6C2470406B64ABCFFA93C8EEA8D2DC9CD3D96C6672583D64746A7058366A6E317014697C6E68B4E7E3A3F7C870566B643868685A69A0D3E2B7C3C9643366720169286C707258ACC5E3AFE5CE696A6E68245871666CA2EDD0AFFEF3ADD1D7AEF1FA682F566B3D6C2470406B64ABF6F29FD3CFA6E5C35867666C3C70406B64ABF6F29FD3CFA6E5C358366A6E317014697C6E68BACFFEA2F6F7BBD8DD64626A700C697C6E68BACFFEA2F6F7BBD8DD643366720169286C707258A3F3FBAFDDF2AEFDF9687E5A69306C707258A3F3FBAFDDF2AEFDF9682F566B3D6C2470406B64A6C9F39CE6CA6C6672583D64746A7092C8E7A8E7DE58366A6E317014697C6E68B7D7D2A2F1E070566B643868685A69A3E3D3B6C5E1643366720169286C707258A2D9E7AEEAE6AED6D5687E5A69306C707258A2D9E7AEEAE6AED6D5682F566B3D6C2470406B64ABDBFA92F4C36C6672583D64746A709FDAEEA6F5D758366A6E317014697C6E68B7C6EBA2F6CAB7CBFA64626A700C697C6E68B7C6EBA2F6CAB7CBFA643366720169286C707258ADDBC0AFE2F5ACD4DE687E5A69306C707258ADDBC0AFE2F5ACD4DE682F566B3D6C2470406B64A8D7DC9CF9C76C6672583D64746A709CD6C8A8F8D358366A6E317014697C6E68BBE3C3A3D3EE70566B643868685A69AFD7C2B7E7EF643366720169286C707258AECED6AEE8DCA3C9FC687E5A69306C707258AECED6AEE8DCA3C9FC682F566B3D6C2470406B64ABDEC29FE0E56C6672583D64746A709FDFD6ABE1F158366A6E317014697C6E68B4E7C5A3FEC5B7FCC264626A700C697C6E68B4E7C5A3FEC5B7FCC2643366720169286C707258AED7E6AFD4D6A2DDE6687E5A69306C707258AED7E6AFD4D6A2DDE6682F566B3D6C2470406B64AAF0DC9FD9CAAAF6CD5867666C3C70406B64AAF0DC9FD9CAAAF6CD58366A6E317014697C6E68B4E7C5A0D6D9B7C9FB64626A700C697C6E68B4E7C5A0D6D9B7C9FB643366720169286C707258A2DDF9AEEFC9A2D9FD687E5A69306C707258A2DDF9AEEFC9A2D9FD682F566B3D6C2470406B64AAF7C79FCDF66C6672583D64746A709EF6D3ABCCE258366A6E317014697C6E68BBE2E5A1F5C5B7DEE264626A700C697C6E68BBE2E5A1F5C5B7DEE2643366720169286C707258ADE4CBAFFBCD696A6E68245871666CACF0FFAEEFF9682F566B3D6C2470406B64ABF4C29FF8E36C6672583D64746A709FF5D6ABF9F758366A6E317014697C6E68B5DFDDA3FDFA70566B643868685A69A1EBDCB7C9FB643366720169286C707258ACE1E8ACE7CDACD4DE687E5A69306C707258ACE1E8ACE7CDACD4DE682F566B3D6C2470406B64A8D7FA9DFFED6C6672583D64746A709CD6EEA9FEF958366A6E317014697C6E68B6C1F0A3D6C3B6C6ED64626A700C697C6E68B6C1F0A3D6C3B6C6ED643366720169286C707258A3F2F0AEEBF9AFFCE0687E5A69306C707258A3F2F0AEEBF9AFFCE0682F566B3D6C2470406B64A9F7C59CD2CD6C6672583D64746A709DF6D1A8D3D958361B33667201692D2B3370406B642C3370566B64202B3F1F697C6E68B4F4D9A3F4C570566B64382B3E0F2E64746A090169286C707258ADDACEA2EDEBACC5E3ACCADA696A6E68245871666C383314202E213E7007676635683C5871666CACCEFAA3F9DFAEEAF0ADDEEE687E5A69306C707258392720213E1B3F233D3E7007676635683C5871666CACCEFAAEC9D9AFF7C7A3E9CA687E5A69306C70725839272021221522283A682F27361B626A7049697C6E11295820233768685A6925222B2109696A6E683C1B26236C707258ACF7F5AFCCF1696A6E68241B27332B68685A103D6C2470406B64ABCFFA93C8EEA9FBE99FD5CD6C6672583D64746A7058366A6E317014697C6E68BAFEFAA3C1E9B5DDCB64626A700C697C6E68BAFEFAA3C1E9B5DDCB643366720169286C707258ACDAD1AEE8C0ACE1CE687E5A69306C707258ACDAD1AEE8C0ACE1CE682F566B3D6C2470406B64A8DACC9DE7D76C6672583D64746A709CDBD8A9E6C358366A6E317014697C6E68BBFAC2A1E9CA70566B643868685A69AFCEC3B5DDCB643366720169286C707258AEC3E5AFDFDC696A6E68245871666CAFD7D1AECBE8682F566B3D6C2470406B64A6E4ED92FBCE6C6672583D64746A7092E5F9A6FADA58366A6E317014697C6E68B4F9CEA0CAD570566B643868685A69A0CDCFB4FED4643366720169286C707258ACD2D1ACE6C1696A6E68245871666CADC6E5ADF2F5682F566B3D6C2470406B64A8D3C89EF7DC6C6672583D64746A709CD2DCAAF6C858366A6E317014697C6E68BBE5F8A2F7DA70566B643868685A69AFD1F9B6C3DB643366720169286C707258A3C7C2AFCEC0696A6E68245871666CA2D3F6AEDAF4682F566B3D6C2470406B64A9F4DC93E8D96C6672583D64746A709DF5C8A7E9CD58366A6E317014697C6E68B4EDFDA3FED070566B643868685A69A0D9FCB7CAD1643366720169286C707258ADFEF6ACDAF5696A6E68245871666CACEAC2ADCEC1682F566B3D6C2470406B64ABFAC39FCFF96C6672583D64746A709FFBD7ABCEED58366A6E317014697C6E68B6C7D8AECCF870566B643868685A69A2F3D9BAF8F9643366720169286C707258ACFCE4AFFCE4696A6E68245871666CADE8D0AEE8D0682F566B3D6C2470406B64A9EDC39CDEDF6C6672583D64746A709DECD7A8DFCB58366A6E317014697C6E68B4E1F9AEC7F070566B643868685A69A0D5F8BAF3F1643366720169286C707258ADEBC2A2DAE4696A6E68245871666CACFFF6A3CED0682F566B3D6C2470406B64A6FEF09DF0C96C6672583D64746A7092FFE4A9F1DD58366A6E317014697C6E68B4CBF6AEF3EC70566B643868685A69A0FFF7BAC7ED643366720169286C707258ADD4E3ACD8DF696A6E68245871666CACC0D7ADCCEB682F566B3D6C2470406B64ABCFE49EF0D06C6672583D64746A709FCEF0AAF1C458361B33667201692D2B3370406B642F38371B696A6E683C1B26236C707258AEDAFEAFDEC0696A6E68241B27332B68685A103D6C2470406B64ABCFFA93C8EEABD6E29FC7FC6C6672583D64746A7058366A6E317014697C6E68B6C2E6A3D5F7B7DEECAFD7CC70566B643868685A69A2F6E7B7E1F6A3EAEDBBE3CD643366720169286C707258ACF8C0AFC9C7696A6E68245871666CADECF4AEDDF3682F566B3D6C2470406B64A8DDF79CD7EA6C6672583D64746A709CDCE3A8D6FE58366A6E317014697C6E68B6C2E6A3D5F7BBDCD2A0F6E570566B643868685A69A2F6E7B7E1F6AFE8D3B4C2E4643366720169286C707258AFFEE3AFC9C7AEC9FEACEBC4696A6E68245871666CAEEAD7AEDDF3AFDDCAADFFF0682F566B3D6C2470406B64A7D5FB9FD0FB6C6672583D64746A7093D4EFABD1EF58366A6E317014697C6E68B4D6ECA0FAF870566B643868685A69A0E2EDB4CEF9643366720169286C707258AEC3F8AEE9EC696A6E68245871666CACE1CAAEDDF3682F27366A6E3170112E3F6C7072582A253A25205867666C2433172E64746A709CD3C8A8D2CD5867666C3C33163E236C70722130642068685A69A3CBE2BBF9E3A0D6C4B4E2D464626A700C697C6E687007676635683C5871666CA3D0E9A3F0CB687E5A69306C707258A2C4DDA2E4FF693B626A29582564746A7093D2CEA6FFF95867666C3C70406B64A7D3DA92FEED6C377E5A30642068685A69A2F3DFB5F8CE64626A700C697C6E68B6C7DEA1CCCF7007676635683C5871666CACE3D0ADF0FB687E5A69306C707258ADF7E4ACE4CF693B626A29582564746A709DC5CDAAF5D89FCCE96C6672583D64746A709DC5CDAAF5D89FCCE96C377E5A30642068685A69AFF5CEB5D9C164626A700C697C6E68BBC1CFA1EDC07007676635683C5871666CA2E2D8AEEED2687E5A69306C707258A3F6ECAFFAE6693B626A29582564746A7093F0C2A8F2F65867666C3C70406B64A7F1D69CF3E26C377E5A30642068685A69A3DFE2B4E7FBA2F2EC70566B643868685A69A3DFE2B4E7FBA2F2EC7007676635683C5871666CA2C4E1AFFFC5A2E2DC696A6E68245871666CA2C4E1AFFFC5A2E2DC693B626A29582564746A703B25212B2633182A2437687E5A69306C7072580A28292F3E1B29272C337007676635683C5871666CACCAE9ACC5C4AFDFF9ACC8F4687E5A69306C707258ADDEDDADD1F0AECBCDADDCC0693B626A29582564746A709FF9F5AAF0C393F2C96C6672583D64746A709FF9F5AAF0C393F2C96C377E5A30642068685A69A1C0C1B7E2C2A3FEDE70566B643868685A69A1C0C1B7E2C2A3FEDE7007676635683C5871666CA3EBC5ADDFD9687E5A69306C707258A2FFF1ACCBED693B626A29582564746A709CD6EEABF3D05867666C3C70406B64A8D7FA9FF2C46C377E5A30642068685A69A0FCC2BAFFF564626A700C697C6E68B4C8C3AECBF47007676635683C5871666CAFEEDAA3CFF4AFD7CE696A6E68245871666CAFEEDAA3CFF4AFD7CE693B626A29582564746A709CF6DEA9C4FC9CD4C96C6672583D64746A709CF6DEA9C4FC9CD4C96C377E5A30642068685A69A3C3C4B4E3E3A3E0CD70566B643868685A69A3C3C4B4E3E3A3E0CD7007676635683C5871666CACCFF4ACFDFAAFCAF3696A6E68245871666CACCFF4ACFDFAAFCAF3693B626A29582564746A709FE5CDABFADD9FE5DB6C6672583D64746A709FE5CDABFADD9FE5DB6C377E5A30642068685A69AEFAF4B5F4F964626A700C697C6E68BACEF5A1C0F87007676635683C5871666CACE0E3ADFCEC687E5A69306C707258ADF4D7ACE8D8693B626A29582564746A709CD9D4A6FECF9FE5C76C6672583D64746A709CD9D4A6FECF9FE5C76C377E5A30642068685A69A0F8C8B5D9C164626A700C697C6E68B4CCC9A1EDC07007163B626A295820233768685A692437687E5A69282F27375871666CACDCE8AEFCC1687E5A69302F26271F697C6E1129582564746A709CD7C6A6F5C39DC8EBA8D2F25867666C3C70406B643C2B3C1123293A682F566B3D6C2470406B64A8D6D292F4D7AAF2D89CD3E66C6672583D64746A70082A282526330E2E353A682F27361B626A704E697C6E11295820233768685A6925222B2109696A6E683C1B26236C707258ACF7F5AFCCF1696A6E68241B27332B68685A103D6C2470406B64ABCFFA93C8EEA9FBE99FD5CD6C6672583D64746A7058366A6E317014697C6E68B5F9E6AEEFCA70566B643868685A69A1CDE7BADBCB643366720169286C707258ACE1DFAFEBC1696A6E68245871666CADF5EBAEFFF5682F566B3D6C2470406B64A9F4DC9FFBD7ABEFE15867666C3C70406B64A9F4DC9FFBD7ABEFE158366A6E317014697C6E68BBD7DFA3F7F170566B643868685A69AFE3DEB7C3F0643366720169286C707258ACFDC1AFD7C2696A6E68245871666CADE9F5AEC3F6682F566B3D6C2470406B64ABC0E39FF4D16C6672583D64746A709FC1F7ABF5C558366A6E317014697C6E68B7CADAA3CAF570566B643868685A69A3FEDBB7FEF4643366720169286C707258AEC0DCA3CBD3696A6E68245871666CAFD4E8A2DFE7682F566B3D6C2470406B64A8DACC9DE7D76C6672583D64746A709CDBD8A9E6C358366A6E317014697C6E68B4F4E3A1DECC70566B643868685A69A0C0E2B5EACD643366720169286C707258ADC7C5ADDACB696A6E68245871666CACD3F1ACCEFF682F566B3D6C2470406B64A8F8E99CCFCE6C6672583D64746A709CF9FDA8CEDA58366A6E317014697C6E68B7C3F0A0CDF970566B643868685A69A3F7F1B4F9F8643366720169286C707258ADE6EFAFC9D7696A6E68245871666CACF2DBAEDDE3682F566B3D6C2470406B64ABC0FA9DC2EF6C6672583D64746A709FC1EEA9C3FB58366A6E317014697C6E68B4E6F1A0C6D270566B643868685A69A0D2F0B4F2D3643366720169286C707258AFFCFCAFFFEA696A6E68245871666CAEE8C8AEEBDE682F566B3D6C2470406B64ABCEED9CE6CA6C6672583D64746A709FCFF9A8E7DE58366A6E317014697C6E68BAC5DBA3C4E270566B643868685A69AEF1DAB7F0E3643366720169286C707258ADC4E2ADC4EB696A6E68245871666CACD0D6ACD0DF682F566B3D6C2470406B64A8CAF89DC2EF6C6672583D64746A709CCBECA9C3FB58366A6E317014697C6E68B4F2D3A2F4C370566B643868685A69A0C6D2B6C0C2643366720169286C707258ACDDC4ACCBC0696A6E68245871666CADC9F0ADDFF4682F566B3D6C2470406B64A7D7C09CD3E36C6672583D64746A7093D6D4A8D2F758366A6E317014697C6E68B5D1EEAEE1D770566B643868685A69A1E5EFBAD5D6643366720169286C707258ACEDD0ACD8FA696A6E68245871666CADF9E4ADCCCE682F566B3D6C2470406B64ABC0FA9EF6DA6C6672583D64746A709FC1EEAAF7CE58366A6E317014697C6E68B5DEF5A2F2D070566B643868685A69A1EAF4B6C6D1643366720169286C707258AEC9C5ACD1FF696A6E68245871666CAFDDF1ADC5CB682F566B3D6C2470406B64A9D6CD9EF1FCA9C3DA5867666C3C70406B64A9D6CD9EF1FCA9C3DA58366A6E317014697C6E68B5EEFEA3F3FBB5F3C364626A700C697C6E68B5EEFEA3F3FBB5F3C3643366720169286C70725804100FADDBF2696A6E68245871666C05043BACCFC6682F27366A6E3170112E3F6C70725832232F3870566B64202B3F1F697C6E68B7C3FFA2F5E970566B64382B3E0F2E64746A090169286C707258AEC3E6A3D1D2AEFFFAAEE9D9696A6E68245871666C682F566B3D6C2470406B647C7A604E696A6E68245871666C7862487F643366720169286C70725879767C7970566B643868685A69747E786158366A6E317014697C6E68604A79746C6672583D64746A70487B747C682F566B3D6C2470406B647C7A604B696A6E68245871666C7862487A643366720169286C70725879767C7A70566B643868685A69747E786258366A6E317014697C6E68604A7A7F6C6672583D64746A70487B7777682F566B3D6C2470406B647C7A6342696A6E68245871666C78624B73643366720169286C70725879767F7D70566B643868685A69747E7B6558366A6E317014697C6E68604A7A706C6672583D64746A70487B7778682F566B3D6C2470406B647C7A634F696A6E68245871666C78624B7E643366720169286C70725879767F7E70566B643868685A69747E7B6658366A6E317014697C6E68604A7A756C6672583D64746A70487B777D682F566B3D6C2470406B647C7A6348696A6E68245871666C78624B79643366720169286C70725879767F7B70566B643868685A69747E7B6358366A6E317014697C6E68604A7A766C6672583D64746A70487B777E682F566B3D6C2470406B647C7A6243696A6E68245871666C78624A72643366720169286C70725879767E7270566B643868685A69747E7A6A58366A6E317014697C6E68604A7B716C6672583D64746A70487B7679682F566B3D6C2470406B647C7A624C696A6E68245871666C78624A7D643366720169286C70725879767E7F70566B643868685A69747E7A6758366A6E317014697C6E68604A7B726C6672583D64746A70487B767A682F566B3D6C2470406B64A8D1E69CDCEF6C6672583D64746A709CD0F2A8DDFB58361B33667201692D2B3370406B642F38371B696A6E683C1B26236C707258AEDAFEAFDEC0696A6E68241B27332B68685A103D6C2470406B64ABCFFA93C8EEABD6E29FC7FC6C6672583D64746A7058366A6E317014697C6E68B7FCCEA3D2FA70566B643868685A69A3EAEDBBE3CD643366720169286C707258ACF8C0AFC9C7696A6E68245871666CADECF4AEDDF3682F566B3D6C2470406B64A8DDF79CD7EA6C6672583D64746A709CDCE3A8D6FE58361B33667201692D2B3370406B642C3370566B64202B3F1F697C6E68B4F4D9A3F4C570566B64382B3E0F2E64746A090169286C707258ADDACEA2EDEBACC5E3ACCADA696A6E68245871666C383314202E213E7007676635683C5871666CACCEFAA3F9DFAEEAF0ADDEEE687E5A69306C707258392720213E1B3F233D3E7007163B1337"

    invoke-static {v1}, Lcom/github/catvod/spider/merge/mdw;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    const/4 v2, 0x5

    new-array v2, v2, [B

    fill-array-data v2, :array_198

    new-array v5, v4, [B

    fill-array-data v5, :array_1a0

    invoke-static {v2, v5}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array p1, v3, [B

    fill-array-data p1, :array_1a8

    new-array v2, v4, [B

    fill-array-data v2, :array_1b0

    invoke-static {p1, v2}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {v1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1

    nop

    :array_114
    .array-data 1
        -0x46t
        -0x13t
        -0x64t
        -0x7t
        -0x76t
        0x37t
        0x30t
        0x7dt
    .end array-data

    :array_11c
    .array-data 1
        -0x61t
        -0x4t
        0x42t
        0x7dt
        0x5et
        0x2ct
        -0x59t
        -0x63t
    .end array-data

    :array_124
    .array-data 1
        -0x7t
        0x75t
        0x75t
        0x55t
        -0x78t
        0x2at
        0x27t
        -0xat
    .end array-data

    :array_12c
    .array-data 1
        -0x40t
        -0x3at
        -0x7dt
        0x38t
        -0x62t
        0x7ft
        -0x3bt
        0x57t
    .end array-data

    :array_134
    .array-data 1
        0x6dt
        0x28t
        0x54t
        -0x4et
        -0x77t
        -0x6t
    .end array-data

    nop

    :array_13c
    .array-data 1
        -0x76t
        -0x44t
        -0x1ft
        0x57t
        0x34t
        0x4bt
        0x75t
        -0x7dt
    .end array-data

    :array_144
    .array-data 1
        -0x63t
        -0x48t
        0x7ct
        0x52t
        0x2ct
        0x13t
        -0x66t
        0x26t
        -0x23t
    .end array-data

    nop

    :array_14e
    .array-data 1
        0x7at
        0x2ct
        -0x37t
        -0x46t
        -0x75t
        -0x6bt
        0x7ft
        -0x51t
    .end array-data

    :array_156
    .array-data 1
        0x2ft
        0xft
        -0x4bt
        0x16t
        0x32t
        -0x46t
    .end array-data

    nop

    :array_15e
    .array-data 1
        -0x38t
        -0x4ct
        0x9t
        -0x2t
        -0x45t
        0x0t
        0x33t
        -0x5t
    .end array-data

    :array_166
    .array-data 1
        -0x64t
        0xdt
        0x5et
        0x54t
        0x6ft
        -0x5bt
    .end array-data

    nop

    :array_16e
    .array-data 1
        0x79t
        -0x79t
        -0xat
        -0x4et
        -0x2dt
        0xet
        -0x4at
        0x58t
    .end array-data

    :array_176
    .array-data 1
        0x38t
        0x17t
        -0xct
        -0x5et
        -0x2at
        0x67t
        -0x12t
    .end array-data

    :array_17e
    .array-data 1
        0x4ct
        0x6et
        -0x7ct
        -0x39t
        -0x77t
        0xet
        -0x76t
        0x40t
    .end array-data

    :array_186
    .array-data 1
        -0x65t
        -0x35t
        0x23t
        0x3ft
        -0x30t
        -0x63t
        0x4bt
        0x60t
        -0x76t
    .end array-data

    nop

    :array_190
    .array-data 1
        -0x11t
        -0x4et
        0x53t
        0x5at
        -0x71t
        -0xdt
        0x2at
        0xdt
    .end array-data

    :array_198
    .array-data 1
        0x69t
        0x4dt
        0x23t
        0x13t
        0x7ft
    .end array-data

    nop

    :array_1a0
    .array-data 1
        0xat
        0x21t
        0x42t
        0x60t
        0xct
        -0x5ft
        0x6et
        -0x5et
    .end array-data

    :array_1a8
    .array-data 1
        0x3ft
        -0x2ct
        -0x40t
        0x3dt
        0x4dt
        0x4ct
        -0x13t
    .end array-data

    :array_1b0
    .array-data 1
        0x59t
        -0x43t
        -0x54t
        0x49t
        0x28t
        0x3et
        -0x62t
        -0x61t
    .end array-data
.end method

.method public homeVideoContent()Ljava/lang/String;
    .registers 14

    new-instance v0, Lorg/json/JSONArray;

    invoke-direct {v0}, Lorg/json/JSONArray;-><init>()V

    const/16 v1, 0x32

    new-array v1, v1, [B

    fill-array-data v1, :array_182

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_1a0

    invoke-static {v1, v3}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    const/16 v3, 0x24

    new-array v3, v3, [B

    fill-array-data v3, :array_1a8

    new-array v4, v2, [B

    fill-array-data v4, :array_1be

    invoke-static {v3, v4}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-direct {p0, v1, v3}, Lcom/github/catvod/spider/SP360;->b(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    new-instance v3, Lorg/json/JSONObject;

    invoke-direct {v3, v1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x4

    new-array v4, v1, [B

    fill-array-data v4, :array_1c6

    new-array v5, v2, [B

    fill-array-data v5, :array_1cc

    invoke-static {v4, v5}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v3

    const/4 v4, 0x0

    :goto_44
    invoke-virtual {v3}, Lorg/json/JSONArray;->length()I

    move-result v5

    if-ge v4, v5, :cond_166

    invoke-virtual {v3, v4}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v5

    const/4 v6, 0x6

    new-array v7, v6, [B

    fill-array-data v7, :array_1d4

    new-array v8, v2, [B

    fill-array-data v8, :array_1dc

    invoke-static {v7, v8}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5, v7}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v9, 0x2e

    new-array v9, v9, [B

    fill-array-data v9, :array_1e4

    new-array v10, v2, [B

    fill-array-data v10, :array_200

    .line 1
    invoke-static {v9, v10, v8, v7}, Lcom/github/catvod/spider/merge/b/v;->a([B[BLjava/lang/StringBuilder;Ljava/lang/String;)V

    const/16 v9, 0xa

    new-array v9, v9, [B

    .line 2
    fill-array-data v9, :array_208

    new-array v10, v2, [B

    fill-array-data v10, :array_212

    .line 3
    invoke-static {v9, v10, v8}, Lcom/github/catvod/spider/merge/b/t;->b([B[BLjava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v8

    .line 4
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v10, 0x19

    new-array v10, v10, [B

    fill-array-data v10, :array_21a

    new-array v11, v2, [B

    fill-array-data v11, :array_22c

    .line 5
    invoke-static {v10, v11, v9, v7}, Lcom/github/catvod/spider/merge/b/v;->a([B[BLjava/lang/StringBuilder;Ljava/lang/String;)V

    const/4 v7, 0x5

    new-array v10, v7, [B

    .line 6
    fill-array-data v10, :array_234

    new-array v11, v2, [B

    fill-array-data v11, :array_23c

    .line 7
    invoke-static {v10, v11, v9}, Lcom/github/catvod/spider/merge/b/t;->b([B[BLjava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v9

    .line 8
    new-instance v10, Lorg/json/JSONObject;

    invoke-direct {v10}, Lorg/json/JSONObject;-><init>()V

    const/16 v11, 0x9

    new-array v11, v11, [B

    fill-array-data v11, :array_244

    new-array v12, v2, [B

    fill-array-data v12, :array_24e

    invoke-static {v11, v12}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v8

    const/16 v10, 0xd

    new-array v10, v10, [B

    fill-array-data v10, :array_256

    new-array v11, v2, [B

    fill-array-data v11, :array_262

    invoke-static {v10, v11}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v8, v10, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v8

    new-array v9, v7, [B

    fill-array-data v9, :array_26a

    new-array v10, v2, [B

    fill-array-data v10, :array_272

    invoke-static {v9, v10}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v5, v9}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    new-array v7, v7, [B

    fill-array-data v7, :array_27a

    new-array v10, v2, [B

    fill-array-data v10, :array_282

    invoke-static {v7, v10}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5, v7}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    new-array v10, v2, [B

    fill-array-data v10, :array_28a

    new-array v11, v2, [B

    fill-array-data v11, :array_292

    invoke-static {v10, v11}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v5, v10}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v5

    invoke-direct {p0, v5}, Lcom/github/catvod/spider/SP360;->a(Lorg/json/JSONArray;)Ljava/lang/String;

    move-result-object v5

    new-instance v10, Lorg/json/JSONObject;

    invoke-direct {v10}, Lorg/json/JSONObject;-><init>()V

    new-array v6, v6, [B

    fill-array-data v6, :array_29a

    new-array v11, v2, [B

    fill-array-data v11, :array_2a2

    invoke-static {v6, v11}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v8}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v10, v6, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v6, v2, [B

    fill-array-data v6, :array_2aa

    new-array v8, v2, [B

    fill-array-data v8, :array_2b2

    invoke-static {v6, v8}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v10, v6, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v6, 0x7

    new-array v6, v6, [B

    fill-array-data v6, :array_2ba

    new-array v8, v2, [B

    fill-array-data v8, :array_2c2

    invoke-static {v6, v8}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v10, v6, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/16 v6, 0xb

    new-array v6, v6, [B

    fill-array-data v6, :array_2ca

    new-array v7, v2, [B

    fill-array-data v7, :array_2d4

    invoke-static {v6, v7}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v10, v6, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {v0, v10}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    add-int/lit8 v4, v4, 0x1

    goto/16 :goto_44

    :cond_166
    new-instance v3, Lorg/json/JSONObject;

    invoke-direct {v3}, Lorg/json/JSONObject;-><init>()V

    new-array v1, v1, [B

    fill-array-data v1, :array_2dc

    new-array v2, v2, [B

    fill-array-data v2, :array_2e2

    invoke-static {v1, v2}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {v3}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    nop

    :array_182
    .array-data 1
        0x4dt
        0x7ft
        0x59t
        -0x3at
        0x7ct
        -0x18t
        0x4et
        -0x2bt
        0x44t
        0x7bt
        0x44t
        -0x68t
        0x78t
        -0x49t
        0x3t
        -0x2ct
        0x16t
        0x3dt
        0x1dt
        -0x23t
        0x6et
        -0x44t
        0x4ft
        -0x67t
        0x4at
        0x66t
        0x2t
        -0x40t
        0x3et
        -0x3t
        0x13t
        -0x65t
        0x4bt
        0x60t
        0x12t
        -0x2bt
        0x6et
        -0x5at
        0x5ct
        -0x38t
        0x3t
        0x68t
        0x4ct
        -0x26t
        0x63t
        -0x50t
        0x0t
        -0x67t
        0x4et
        0x36t
    .end array-data

    nop

    :array_1a0
    .array-data 1
        0x25t
        0xbt
        0x2dt
        -0x4at
        0xft
        -0x2et
        0x61t
        -0x6t
    .end array-data

    :array_1a8
    .array-data 1
        0x33t
        -0x6ct
        -0x59t
        0x4et
        -0x61t
        -0x64t
        -0x80t
        0x4et
        0x2ct
        -0x69t
        -0x5ct
        0x10t
        -0x21t
        -0x70t
        -0x61t
        0xat
        0x3at
        -0x72t
        -0x3t
        0x5dt
        -0x7dt
        -0x35t
        -0x80t
        0x13t
        0x3at
        -0x72t
        -0x48t
        0x11t
        -0x78t
        -0x31t
        -0x32t
        0xft
        0x22t
        -0x77t
        -0x43t
        0x59t
    .end array-data

    :array_1be
    .array-data 1
        0x5bt
        -0x20t
        -0x2dt
        0x3et
        -0x14t
        -0x5at
        -0x51t
        0x61t
    .end array-data

    :array_1c6
    .array-data 1
        0x37t
        -0x77t
        0x76t
        -0x37t
    .end array-data

    :array_1cc
    .array-data 1
        0x53t
        -0x18t
        0x2t
        -0x58t
        -0x4ct
        0x5dt
        0x6ct
        0x37t
    .end array-data

    :array_1d4
    .array-data 1
        0x7dt
        0x6at
        -0x7bt
        0x15t
        0x3bt
        0x3dt
    .end array-data

    nop

    :array_1dc
    .array-data 1
        0x18t
        0x4t
        -0xft
        0x4at
        0x52t
        0x59t
        -0x3et
        -0x24t
    .end array-data

    :array_1e4
    .array-data 1
        -0x2bt
        0x4ct
        -0x5dt
        0x38t
        -0x15t
        -0x10t
        -0xat
        -0x6ft
        -0x24t
        0x48t
        -0x42t
        0x66t
        -0x11t
        -0x51t
        -0x45t
        -0x70t
        -0x72t
        0xet
        -0x19t
        0x23t
        -0x7t
        -0x5ct
        -0x9t
        -0x23t
        -0x2et
        0x55t
        -0x8t
        0x3et
        -0x57t
        -0x1bt
        -0x43t
        -0x25t
        -0x37t
        0x59t
        -0x42t
        0x24t
        -0x59t
        -0x57t
        -0x48t
        -0x36t
        -0x80t
        0x9t
        -0xft
        0x21t
        -0x4t
        -0x9t
    .end array-data

    nop

    :array_200
    .array-data 1
        -0x43t
        0x38t
        -0x29t
        0x48t
        -0x68t
        -0x36t
        -0x27t
        -0x42t
    .end array-data

    :array_208
    .array-data 1
        -0x26t
        -0x2at
        0x3dt
        0x59t
        0x1ft
        0x5et
        -0x2ct
        -0x42t
        -0x69t
        -0x78t
    .end array-data

    nop

    :array_212
    .array-data 1
        -0x4t
        -0x4bt
        0x5ct
        0x35t
        0x73t
        0x3ct
        -0x4bt
        -0x23t
    .end array-data

    :array_21a
    .array-data 1
        0x5ft
        -0x68t
        0x5et
        0x53t
        0x1t
        -0x7ft
        -0x12t
        -0xft
        0x40t
        -0x65t
        0x5dt
        0xdt
        0x41t
        -0x73t
        -0xft
        -0x4bt
        0x56t
        -0x7et
        0x4t
        0x40t
        0x1dt
        -0x2at
        -0x12t
        -0x4dt
        0x18t
    .end array-data

    nop

    :array_22c
    .array-data 1
        0x37t
        -0x14t
        0x2at
        0x23t
        0x72t
        -0x45t
        -0x3ft
        -0x22t
    .end array-data

    :array_234
    .array-data 1
        -0x25t
        0x52t
        -0x6ft
        -0x44t
        -0x28t
    .end array-data

    nop

    :array_23c
    .array-data 1
        -0xbt
        0x3at
        -0x1bt
        -0x2ft
        -0x4ct
        -0x17t
        -0x35t
        0x7ct
    .end array-data

    :array_244
    .array-data 1
        -0x56t
        -0x5bt
        -0x53t
        -0x63t
        0x55t
        0x7ft
        0x40t
        -0x7ft
        -0x5et
    .end array-data

    nop

    :array_24e
    .array-data 1
        -0x32t
        -0x40t
        -0x27t
        -0x4t
        0x3ct
        0x13t
        0x15t
        -0xdt
    .end array-data

    :array_256
    .array-data 1
        -0x71t
        0x20t
        0x3et
        -0x79t
        -0x14t
        -0x15t
        -0x51t
        -0x35t
        -0x73t
        0x20t
        0x38t
        -0x7dt
        -0x9t
    .end array-data

    nop

    :array_262
    .array-data 1
        -0x15t
        0x45t
        0x4at
        -0x1at
        -0x7bt
        -0x79t
        -0x3t
        -0x52t
    .end array-data

    :array_26a
    .array-data 1
        -0x4ft
        0x1ct
        0x29t
        -0x35t
        0x6ft
    .end array-data

    nop

    :array_272
    .array-data 1
        -0x3bt
        0x75t
        0x5dt
        -0x59t
        0xat
        -0x72t
        0x6bt
        0x65t
    .end array-data

    :array_27a
    .array-data 1
        0x78t
        -0x14t
        0x6ct
        0x16t
        0xet
    .end array-data

    nop

    :array_282
    .array-data 1
        0x1bt
        -0x7dt
        0x1at
        0x73t
        0x7ct
        -0x55t
        -0x6at
        0x55t
    .end array-data

    :array_28a
    .array-data 1
        -0x67t
        -0x43t
        -0x2et
        -0x40t
        0x39t
        -0x78t
        -0xft
        -0x2bt
    .end array-data

    :array_292
    .array-data 1
        -0xct
        -0x2et
        -0x5ct
        -0x57t
        0x5ct
        -0x15t
        -0x70t
        -0x5ft
    .end array-data

    :array_29a
    .array-data 1
        -0xdt
        0x40t
        0x25t
        -0x19t
        -0x7ct
        0x11t
    .end array-data

    nop

    :array_2a2
    .array-data 1
        -0x7bt
        0x2ft
        0x41t
        -0x48t
        -0x13t
        0x75t
        -0x4ct
        -0x60t
    .end array-data

    :array_2aa
    .array-data 1
        -0x6t
        0x38t
        0x49t
        -0x69t
        -0x42t
        -0x10t
        0xat
        -0x23t
    .end array-data

    :array_2b2
    .array-data 1
        -0x74t
        0x57t
        0x2dt
        -0x38t
        -0x30t
        -0x6ft
        0x67t
        -0x48t
    .end array-data

    :array_2ba
    .array-data 1
        -0x26t
        0x29t
        0x79t
        0x39t
        0x2bt
        -0x9t
        0x5t
    .end array-data

    :array_2c2
    .array-data 1
        -0x54t
        0x46t
        0x1dt
        0x66t
        0x5bt
        -0x62t
        0x66t
        -0x80t
    .end array-data

    :array_2ca
    .array-data 1
        0x58t
        0x69t
        -0x44t
        -0x5ft
        0x3ft
        0x4et
        -0x44t
        -0x1et
        0x5ct
        0x6dt
        -0x55t
    .end array-data

    :array_2d4
    .array-data 1
        0x2et
        0x6t
        -0x28t
        -0x2t
        0x4dt
        0x2bt
        -0x2ft
        -0x7dt
    .end array-data

    :array_2dc
    .array-data 1
        0x5et
        -0x57t
        -0x4at
        -0x72t
    .end array-data

    :array_2e2
    .array-data 1
        0x32t
        -0x40t
        -0x3bt
        -0x6t
        -0x5dt
        0x44t
        0x54t
        -0x38t
    .end array-data
.end method

.method public init(Landroid/content/Context;Ljava/lang/String;)V
    .registers 3

    invoke-super {p0, p1, p2}, Lcom/github/catvod/crawler/Spider;->init(Landroid/content/Context;Ljava/lang/String;)V

    if-eqz p2, :cond_6

    goto :goto_8

    :cond_6
    const-string p2, ""

    :goto_8
    iput-object p2, p0, Lcom/github/catvod/spider/SP360;->b:Ljava/lang/String;

    return-void
.end method

.method public playerContent(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)Ljava/lang/String;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    new-instance p1, Ljava/util/HashMap;

    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    const/16 p3, 0xa

    new-array p3, p3, [B

    fill-array-data p3, :array_34

    const/16 v0, 0x8

    new-array v0, v0, [B

    fill-array-data v0, :array_3e

    invoke-static {p3, v0}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p3

    iget-object v0, p0, Lcom/github/catvod/spider/SP360;->a:Ljava/lang/String;

    invoke-virtual {p1, p3, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1
    new-instance p3, Lcom/github/catvod/spider/merge/c/g;

    invoke-direct {p3}, Lcom/github/catvod/spider/merge/c/g;-><init>()V

    .line 2
    invoke-virtual {p3, p2}, Lcom/github/catvod/spider/merge/c/g;->y(Ljava/lang/String;)Lcom/github/catvod/spider/merge/c/g;

    const/4 p2, 0x1

    invoke-virtual {p3, p2}, Lcom/github/catvod/spider/merge/c/g;->m(I)Lcom/github/catvod/spider/merge/c/g;

    invoke-virtual {p3}, Lcom/github/catvod/spider/merge/c/g;->g()Lcom/github/catvod/spider/merge/c/g;

    invoke-virtual {p3, p1}, Lcom/github/catvod/spider/merge/c/g;->f(Ljava/util/Map;)Lcom/github/catvod/spider/merge/c/g;

    .line 3
    invoke-virtual {p3}, Lcom/github/catvod/spider/merge/c/g;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1

    nop

    :array_34
    .array-data 1
        -0x6ft
        0x71t
        -0x69t
        -0x47t
        -0x62t
        -0x53t
        -0x65t
        -0x15t
        -0x56t
        0x76t
    .end array-data

    nop

    :array_3e
    .array-data 1
        -0x3ct
        0x2t
        -0xet
        -0x35t
        -0x4dt
        -0x14t
        -0x4t
        -0x72t
    .end array-data
.end method

.method public searchContent(Ljava/lang/String;Z)Ljava/lang/String;
    .registers 14

    invoke-static {p1}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v0, 0x2d

    new-array v0, v0, [B

    fill-array-data v0, :array_1ce

    const/16 v1, 0x8

    new-array v2, v1, [B

    fill-array-data v2, :array_1ea

    .line 1
    invoke-static {v0, v2, p2, p1}, Lcom/github/catvod/spider/merge/b/v;->a([B[BLjava/lang/StringBuilder;Ljava/lang/String;)V

    const/16 v0, 0x1e

    new-array v0, v0, [B

    .line 2
    fill-array-data v0, :array_1f2

    new-array v2, v1, [B

    fill-array-data v2, :array_206

    .line 3
    invoke-static {v0, v2, p2}, Lcom/github/catvod/spider/merge/b/t;->b([B[BLjava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object p2

    .line 4
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v2, 0x1a

    new-array v2, v2, [B

    fill-array-data v2, :array_20e

    new-array v3, v1, [B

    fill-array-data v3, :array_220

    .line 5
    invoke-static {v2, v3, v0, p1}, Lcom/github/catvod/spider/merge/b/u;->b([B[BLjava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 6
    invoke-direct {p0, p2, p1}, Lcom/github/catvod/spider/SP360;->b(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    new-instance p2, Lorg/json/JSONArray;

    invoke-direct {p2}, Lorg/json/JSONArray;-><init>()V

    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 p1, 0x4

    new-array v2, p1, [B

    fill-array-data v2, :array_228

    new-array v3, v1, [B

    fill-array-data v3, :array_22e

    invoke-static {v2, v3}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    new-array v2, v1, [B

    fill-array-data v2, :array_236

    new-array v3, v1, [B

    fill-array-data v3, :array_23e

    invoke-static {v2, v3}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    new-array v2, p1, [B

    fill-array-data v2, :array_246

    new-array v3, v1, [B

    fill-array-data v3, :array_24c

    invoke-static {v2, v3}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v0

    const/4 v2, 0x0

    :goto_85
    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    move-result v3

    if-ge v2, v3, :cond_1b3

    invoke-virtual {v0, v2}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v3

    const/4 v4, 0x5

    new-array v5, v4, [B

    fill-array-data v5, :array_254

    new-array v6, v1, [B

    fill-array-data v6, :array_25c

    invoke-static {v5, v6}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const/4 v6, 0x6

    new-array v7, v6, [B

    fill-array-data v7, :array_264

    new-array v8, v1, [B

    fill-array-data v8, :array_26c

    invoke-static {v7, v8}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v3, v7}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v9, 0x29

    new-array v9, v9, [B

    fill-array-data v9, :array_274

    new-array v10, v1, [B

    fill-array-data v10, :array_28e

    .line 7
    invoke-static {v9, v10, v8, v7}, Lcom/github/catvod/spider/merge/b/v;->a([B[BLjava/lang/StringBuilder;Ljava/lang/String;)V

    new-array v7, p1, [B

    .line 8
    fill-array-data v7, :array_296

    new-array v9, v1, [B

    fill-array-data v9, :array_29c

    .line 9
    invoke-static {v7, v9, v8, v5}, Lcom/github/catvod/spider/merge/b/v;->a([B[BLjava/lang/StringBuilder;Ljava/lang/String;)V

    const/16 v5, 0xa

    new-array v5, v5, [B

    .line 10
    fill-array-data v5, :array_2a4

    new-array v7, v1, [B

    fill-array-data v7, :array_2ae

    .line 11
    invoke-static {v5, v7, v8}, Lcom/github/catvod/spider/merge/b/t;->b([B[BLjava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x3

    new-array v7, v7, [B

    .line 12
    fill-array-data v7, :array_2b6

    new-array v8, v1, [B

    fill-array-data v8, :array_2bc

    invoke-static {v7, v8}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v3, v7}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    new-instance v8, Lorg/json/JSONObject;

    invoke-direct {v8}, Lorg/json/JSONObject;-><init>()V

    const/16 v9, 0x9

    new-array v9, v9, [B

    fill-array-data v9, :array_2c4

    new-array v10, v1, [B

    fill-array-data v10, :array_2ce

    invoke-static {v9, v10}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v5

    const/16 v8, 0xd

    new-array v8, v8, [B

    fill-array-data v8, :array_2d6

    new-array v9, v1, [B

    fill-array-data v9, :array_2e2

    invoke-static {v8, v9}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v5, v8, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v5

    new-array v7, v1, [B

    fill-array-data v7, :array_2ea

    new-array v8, v1, [B

    fill-array-data v8, :array_2f2

    invoke-static {v7, v8}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v3, v7}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    new-array v4, v4, [B

    fill-array-data v4, :array_2fa

    new-array v8, v1, [B

    fill-array-data v8, :array_302

    invoke-static {v4, v8}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    new-array v8, v1, [B

    fill-array-data v8, :array_30a

    new-array v9, v1, [B

    fill-array-data v9, :array_312

    invoke-static {v8, v9}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v3, v8}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v5}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v5

    new-instance v8, Lorg/json/JSONObject;

    invoke-direct {v8}, Lorg/json/JSONObject;-><init>()V

    new-array v6, v6, [B

    fill-array-data v6, :array_31a

    new-array v9, v1, [B

    fill-array-data v9, :array_322

    invoke-static {v6, v9}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v8, v6, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v5, v1, [B

    fill-array-data v5, :array_32a

    new-array v6, v1, [B

    fill-array-data v6, :array_332

    invoke-static {v5, v6}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v8, v5, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x7

    new-array v5, v5, [B

    fill-array-data v5, :array_33a

    new-array v6, v1, [B

    fill-array-data v6, :array_342

    invoke-static {v5, v6}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v8, v5, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/16 v4, 0xb

    new-array v4, v4, [B

    fill-array-data v4, :array_34a

    new-array v5, v1, [B

    fill-array-data v5, :array_354

    invoke-static {v4, v5}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v8, v4, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {p2, v8}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    add-int/lit8 v2, v2, 0x1

    goto/16 :goto_85

    :cond_1b3
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    new-array p1, p1, [B

    fill-array-data p1, :array_35c

    new-array v1, v1, [B

    fill-array-data v1, :array_362

    invoke-static {p1, v1}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1

    :array_1ce
    .array-data 1
        -0x67t
        -0x5at
        -0x2bt
        -0x57t
        0x7et
        0x3et
        -0x46t
        0x10t
        -0x70t
        -0x5et
        -0x38t
        -0x9t
        0x7et
        0x6bt
        -0x45t
        0xct
        -0x39t
        -0x1et
        -0x36t
        -0x48t
        0x63t
        0x2at
        -0xat
        0x50t
        -0x64t
        -0x3t
        -0x38t
        -0x49t
        0x69t
        0x61t
        -0x13t
        0x0t
        -0x69t
        -0x43t
        -0x2dt
        -0x46t
        0x68t
        0x5bt
        -0x1dt
        0x2t
        -0x40t
        -0xct
        -0x36t
        -0x52t
        0x30t
    .end array-data

    nop

    :array_1ea
    .array-data 1
        -0xft
        -0x2et
        -0x5ft
        -0x27t
        0xdt
        0x4t
        -0x6bt
        0x3ft
    .end array-data

    :array_1f2
    .array-data 1
        -0x11t
        -0x6dt
        0x1t
        -0x71t
        0x16t
        0x60t
        0x76t
        0x26t
        -0x58t
        -0x6et
        0x16t
        -0x72t
        0x14t
        0x60t
        0x61t
        0x70t
        -0x41t
        -0x56t
        0x12t
        -0x70t
        0x46t
        0x6ct
        0x76t
        0x22t
        -0x58t
        -0x69t
        0x4et
        -0x7ft
        0x17t
        0x31t
    .end array-data

    nop

    :array_206
    .array-data 1
        -0x37t
        -0xbt
        0x73t
        -0x20t
        0x7bt
        0x5dt
        0x50t
        0x56t
    .end array-data

    :array_20e
    .array-data 1
        0x69t
        0x78t
        0x4ft
        0x43t
        0x72t
        -0x2ct
        -0x53t
        -0x28t
        0x72t
        0x63t
        0x15t
        0x0t
        0x37t
        -0x22t
        -0x17t
        -0x6at
        0x6ft
        0x22t
        0x58t
        0x5ct
        0x6ct
        -0x3ft
        -0x43t
        -0x64t
        0x76t
        0x31t
    .end array-data

    nop

    :array_220
    .array-data 1
        0x1t
        0xct
        0x3bt
        0x33t
        0x1t
        -0x12t
        -0x7et
        -0x9t
    .end array-data

    :array_228
    .array-data 1
        -0x7bt
        -0x68t
        -0x7t
        0x17t
    .end array-data

    :array_22e
    .array-data 1
        -0x1ft
        -0x7t
        -0x73t
        0x76t
        -0x31t
        -0x3dt
        0x6at
        -0x59t
    .end array-data

    :array_236
    .array-data 1
        0x53t
        0x12t
        -0x6ct
        -0x6bt
        -0x2at
        -0x2et
        -0xet
        0x64t
    .end array-data

    :array_23e
    .array-data 1
        0x3ft
        0x7dt
        -0x6t
        -0xet
        -0x6et
        -0x4dt
        -0x7at
        0x5t
    .end array-data

    :array_246
    .array-data 1
        -0x4t
        -0x55t
        -0x7ct
        -0x60t
    .end array-data

    :array_24c
    .array-data 1
        -0x72t
        -0x3ct
        -0xdt
        -0x2dt
        0x43t
        -0x72t
        0x7t
        -0x10t
    .end array-data

    :array_254
    .array-data 1
        0x71t
        0x74t
        -0x6ft
        -0x52t
        -0x21t
    .end array-data

    nop

    :array_25c
    .array-data 1
        0x14t
        0x1at
        -0x32t
        -0x39t
        -0x45t
        -0x40t
        0xbt
        0x14t
    .end array-data

    :array_264
    .array-data 1
        -0x15t
        -0x30t
        0x1ft
        -0x43t
        -0x32t
        -0x2t
    .end array-data

    nop

    :array_26c
    .array-data 1
        -0x78t
        -0x4ft
        0x6bt
        -0x1et
        -0x59t
        -0x66t
        -0x47t
        0x33t
    .end array-data

    :array_274
    .array-data 1
        0x8t
        -0x70t
        -0x41t
        0x50t
        -0x5bt
        0x13t
        -0x32t
        -0x45t
        0x1t
        -0x6ct
        -0x5et
        0xet
        -0x5ft
        0x4ct
        -0x7dt
        -0x46t
        0x53t
        -0x2et
        -0x5t
        0x4bt
        -0x49t
        0x47t
        -0x31t
        -0x9t
        0xft
        -0x77t
        -0x1ct
        0x56t
        -0x19t
        0x6t
        -0x7bt
        -0xft
        0x14t
        -0x7bt
        -0x5et
        0x4ct
        -0x17t
        0x4at
        -0x80t
        -0x20t
        0x5dt
    .end array-data

    nop

    :array_28e
    .array-data 1
        0x60t
        -0x1ct
        -0x35t
        0x20t
        -0x2at
        0x29t
        -0x1ft
        -0x6ct
    .end array-data

    :array_296
    .array-data 1
        -0x15t
        -0x79t
        0x5ct
        0x69t
    .end array-data

    :array_29c
    .array-data 1
        -0x33t
        -0x12t
        0x38t
        0x54t
        0x47t
        -0x3t
        -0x39t
        -0x24t
    .end array-data

    :array_2a4
    .array-data 1
        0x38t
        0x2et
        0x33t
        0x2ft
        0x59t
        -0x22t
        0x38t
        0x2dt
        0x75t
        0x70t
    .end array-data

    nop

    :array_2ae
    .array-data 1
        0x1et
        0x4dt
        0x52t
        0x43t
        0x35t
        -0x44t
        0x59t
        0x4et
    .end array-data

    :array_2b6
    .array-data 1
        0x5ft
        0x5et
        -0x5at
    .end array-data

    :array_2bc
    .array-data 1
        0x2at
        0x2ct
        -0x36t
        0x1t
        -0x17t
        0x10t
        0x7t
        0x3ct
    .end array-data

    :array_2c4
    .array-data 1
        -0x2ft
        -0x46t
        0x8t
        -0x4ct
        -0x41t
        0x4dt
        -0x44t
        -0x14t
        -0x27t
    .end array-data

    nop

    :array_2ce
    .array-data 1
        -0x4bt
        -0x21t
        0x7ct
        -0x2bt
        -0x2at
        0x21t
        -0x17t
        -0x62t
    .end array-data

    :array_2d6
    .array-data 1
        0x41t
        -0x68t
        0x8t
        -0x19t
        0x28t
        -0x40t
        -0x1dt
        0x65t
        0x43t
        -0x68t
        0xet
        -0x1dt
        0x33t
    .end array-data

    nop

    :array_2e2
    .array-data 1
        0x25t
        -0x3t
        0x7ct
        -0x7at
        0x41t
        -0x54t
        -0x4ft
        0x0t
    .end array-data

    :array_2ea
    .array-data 1
        -0x30t
        0x2ct
        0x4et
        0x3ct
        -0x2at
        -0x23t
        0x66t
        0x6ct
    .end array-data

    :array_2f2
    .array-data 1
        -0x5ct
        0x45t
        0x3at
        0x50t
        -0x4dt
        -0x77t
        0x1et
        0x18t
    .end array-data

    :array_2fa
    .array-data 1
        0x42t
        -0x70t
        0x30t
        0x34t
        -0x6dt
    .end array-data

    nop

    :array_302
    .array-data 1
        0x21t
        -0x1t
        0x46t
        0x51t
        -0x1ft
        0x30t
        -0x73t
        0x33t
    .end array-data

    :array_30a
    .array-data 1
        0x5bt
        0x76t
        -0x50t
        -0x62t
        0x5at
        0x2ct
        -0x37t
        -0x56t
    .end array-data

    :array_312
    .array-data 1
        0x38t
        0x17t
        -0x3ct
        -0x3ft
        0x34t
        0x4dt
        -0x5ct
        -0x31t
    .end array-data

    :array_31a
    .array-data 1
        -0x3ct
        0xat
        -0x47t
        0x40t
        -0x31t
        0x19t
    .end array-data

    nop

    :array_322
    .array-data 1
        -0x4et
        0x65t
        -0x23t
        0x1ft
        -0x5at
        0x7dt
        0x66t
        -0x7at
    .end array-data

    :array_32a
    .array-data 1
        -0x42t
        0x31t
        -0x72t
        0x67t
        0x7ft
        -0x1dt
        -0x76t
        0x53t
    .end array-data

    :array_332
    .array-data 1
        -0x38t
        0x5et
        -0x16t
        0x38t
        0x11t
        -0x7et
        -0x19t
        0x36t
    .end array-data

    :array_33a
    .array-data 1
        -0x71t
        0x20t
        0x30t
        0x43t
        -0x1at
        0x8t
        -0x76t
    .end array-data

    :array_342
    .array-data 1
        -0x7t
        0x4ft
        0x54t
        0x1ct
        -0x6at
        0x61t
        -0x17t
        -0x6ft
    .end array-data

    :array_34a
    .array-data 1
        0x40t
        0x35t
        0x70t
        0x79t
        0x7ct
        -0x70t
        -0x38t
        0x74t
        0x44t
        0x31t
        0x67t
    .end array-data

    :array_354
    .array-data 1
        0x36t
        0x5at
        0x14t
        0x26t
        0xet
        -0xbt
        -0x5bt
        0x15t
    .end array-data

    :array_35c
    .array-data 1
        -0x21t
        0x51t
        -0x51t
        0x6ft
    .end array-data

    :array_362
    .array-data 1
        -0x4dt
        0x38t
        -0x24t
        0x1bt
        -0x7at
        0x24t
        -0x66t
        -0x42t
    .end array-data
.end method

.class public final Lcom/github/catvod/spider/merge/c/e;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# instance fields
.field private a:I

.field private b:Ljava/lang/String;

.field private c:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, Lcom/github/catvod/spider/merge/c/e;->a:I

    const-string v0, ""

    iput-object v0, p0, Lcom/github/catvod/spider/merge/c/e;->b:Ljava/lang/String;

    return-void
.end method

.method public static a(Ljava/lang/String;)Lcom/github/catvod/spider/merge/c/e;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/String;",
            ")",
            "Lcom/github/catvod/spider/merge/c/e<",
            "TT;>;"
        }
    .end annotation

    new-instance v0, Lcom/github/catvod/spider/merge/c/e;

    invoke-direct {v0}, Lcom/github/catvod/spider/merge/c/e;-><init>()V

    const/4 v1, 0x1

    iput v1, v0, Lcom/github/catvod/spider/merge/c/e;->a:I

    iput-object p0, v0, Lcom/github/catvod/spider/merge/c/e;->b:Ljava/lang/String;

    return-object v0
.end method

.method public static h(Ljava/lang/Object;)Lcom/github/catvod/spider/merge/c/e;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;)",
            "Lcom/github/catvod/spider/merge/c/e<",
            "TT;>;"
        }
    .end annotation

    new-instance v0, Lcom/github/catvod/spider/merge/c/e;

    invoke-direct {v0}, Lcom/github/catvod/spider/merge/c/e;-><init>()V

    iput-object p0, v0, Lcom/github/catvod/spider/merge/c/e;->c:Ljava/lang/Object;

    return-object v0
.end method


# virtual methods
.method public final b()I
    .registers 2

    iget v0, p0, Lcom/github/catvod/spider/merge/c/e;->a:I

    return v0
.end method

.method public final c()Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    iget-object v0, p0, Lcom/github/catvod/spider/merge/c/e;->c:Ljava/lang/Object;

    return-object v0
.end method

.method public final d()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lcom/github/catvod/spider/merge/c/e;->b:Ljava/lang/String;

    return-object v0
.end method

.method public final e(I)V
    .registers 2

    iput p1, p0, Lcom/github/catvod/spider/merge/c/e;->a:I

    return-void
.end method

.method public final f(Ljava/lang/Object;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    iput-object p1, p0, Lcom/github/catvod/spider/merge/c/e;->c:Ljava/lang/Object;

    return-void
.end method

.method public final g(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lcom/github/catvod/spider/merge/c/e;->b:Ljava/lang/String;

    return-void
.end method

.method public final toString()Ljava/lang/String;
    .registers 6

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v1, 0x9

    new-array v1, v1, [B

    fill-array-data v1, :array_5c

    const/16 v2, 0x8

    new-array v3, v2, [B

    fill-array-data v3, :array_66

    invoke-static {v1, v3}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Lcom/github/catvod/spider/merge/c/e;->a:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v1, 0x7

    new-array v3, v1, [B

    fill-array-data v3, :array_6e

    new-array v4, v2, [B

    fill-array-data v4, :array_76

    invoke-static {v3, v4}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, p0, Lcom/github/catvod/spider/merge/c/e;->b:Ljava/lang/String;

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v3, 0x27

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    new-array v1, v1, [B

    fill-array-data v1, :array_7e

    new-array v2, v2, [B

    fill-array-data v2, :array_86

    invoke-static {v1, v2}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/github/catvod/spider/merge/c/e;->c:Ljava/lang/Object;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 v1, 0x7d

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    nop

    :array_5c
    .array-data 1
        -0x69t
        -0x39t
        -0x2bt
        -0x58t
        0xct
        0xft
        0x5dt
        -0x62t
        -0x8t
    .end array-data

    nop

    :array_66
    .array-data 1
        -0x3bt
        -0x5et
        -0x5at
        -0x2dt
        0x6ft
        0x60t
        0x39t
        -0x5t
    .end array-data

    :array_6e
    .array-data 1
        0x64t
        0x64t
        -0x3bt
        0x26t
        -0x4dt
        -0x3ft
        -0x78t
    .end array-data

    :array_76
    .array-data 1
        0x48t
        0x44t
        -0x58t
        0x55t
        -0x2ct
        -0x4t
        -0x51t
        0x36t
    .end array-data

    :array_7e
    .array-data 1
        0x12t
        0x6t
        0x43t
        -0x51t
        0x65t
        -0xat
        0x12t
    .end array-data

    :array_86
    .array-data 1
        0x3et
        0x26t
        0x27t
        -0x32t
        0x11t
        -0x69t
        0x2ft
        -0x2et
    .end array-data
.end method

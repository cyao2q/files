.class public final Lcom/github/catvod/spider/merge/c/j;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field private a:Ljava/lang/String;
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "type_name"
    .end annotation
.end field

.field private b:Ljava/lang/String;
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "vod_id"
    .end annotation
.end field

.field private c:Ljava/lang/String;
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "vod_name"
    .end annotation
.end field

.field private d:Ljava/lang/String;
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "vod_pic"
    .end annotation
.end field

.field private e:Ljava/lang/String;
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "vod_remarks"
    .end annotation
.end field

.field private f:Ljava/lang/String;
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "vod_year"
    .end annotation
.end field

.field private g:Ljava/lang/String;
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "vod_area"
    .end annotation
.end field

.field private h:Ljava/lang/String;
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "vod_actor"
    .end annotation
.end field

.field private i:Ljava/lang/String;
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "vod_director"
    .end annotation
.end field

.field private j:Ljava/lang/String;
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "vod_content"
    .end annotation
.end field

.field private k:Ljava/lang/String;
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "vod_play_from"
    .end annotation
.end field

.field private l:Ljava/lang/String;
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "vod_play_url"
    .end annotation
.end field

.field private m:Ljava/lang/String;
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "vod_tag"
    .end annotation
.end field

.field private n:Ljava/lang/String;
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "action"
    .end annotation
.end field

.field private o:Lcom/github/catvod/spider/merge/c/i;
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "style"
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1
    iput-object p1, p0, Lcom/github/catvod/spider/merge/c/j;->b:Ljava/lang/String;

    .line 2
    iput-object p2, p0, Lcom/github/catvod/spider/merge/c/j;->c:Ljava/lang/String;

    .line 3
    iput-object p3, p0, Lcom/github/catvod/spider/merge/c/j;->d:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lcom/github/catvod/spider/merge/c/j;->b:Ljava/lang/String;

    .line 5
    iput-object p2, p0, Lcom/github/catvod/spider/merge/c/j;->c:Ljava/lang/String;

    .line 6
    iput-object p3, p0, Lcom/github/catvod/spider/merge/c/j;->d:Ljava/lang/String;

    .line 7
    iput-object p4, p0, Lcom/github/catvod/spider/merge/c/j;->e:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/github/catvod/spider/merge/c/i;Ljava/lang/String;)V
    .registers 7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    iput-object p1, p0, Lcom/github/catvod/spider/merge/c/j;->b:Ljava/lang/String;

    .line 9
    iput-object p2, p0, Lcom/github/catvod/spider/merge/c/j;->c:Ljava/lang/String;

    .line 10
    iput-object p3, p0, Lcom/github/catvod/spider/merge/c/j;->d:Ljava/lang/String;

    .line 11
    iput-object p4, p0, Lcom/github/catvod/spider/merge/c/j;->e:Ljava/lang/String;

    .line 12
    iput-object p5, p0, Lcom/github/catvod/spider/merge/c/j;->o:Lcom/github/catvod/spider/merge/c/i;

    .line 13
    iput-object p6, p0, Lcom/github/catvod/spider/merge/c/j;->n:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 14
    iput-object p1, p0, Lcom/github/catvod/spider/merge/c/j;->b:Ljava/lang/String;

    .line 15
    iput-object p2, p0, Lcom/github/catvod/spider/merge/c/j;->c:Ljava/lang/String;

    .line 16
    iput-object p3, p0, Lcom/github/catvod/spider/merge/c/j;->d:Ljava/lang/String;

    .line 17
    iput-object p4, p0, Lcom/github/catvod/spider/merge/c/j;->e:Ljava/lang/String;

    const/16 p1, 0x8

    if-eqz p5, :cond_1f

    const/4 p2, 0x6

    new-array p2, p2, [B

    .line 18
    fill-array-data p2, :array_32

    new-array p1, p1, [B

    fill-array-data p1, :array_3a

    invoke-static {p2, p1}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    goto :goto_2e

    :cond_1f
    const/4 p2, 0x4

    new-array p2, p2, [B

    fill-array-data p2, :array_42

    new-array p1, p1, [B

    fill-array-data p1, :array_48

    invoke-static {p2, p1}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    .line 19
    :goto_2e
    iput-object p1, p0, Lcom/github/catvod/spider/merge/c/j;->m:Ljava/lang/String;

    return-void

    nop

    :array_32
    .array-data 1
        0x2ct
        -0x6dt
        -0x5et
        0x7ft
        0x2ct
        0x6t
    .end array-data

    nop

    :array_3a
    .array-data 1
        0x4at
        -0x4t
        -0x32t
        0x1bt
        0x49t
        0x74t
        -0x34t
        -0x55t
    .end array-data

    :array_42
    .array-data 1
        0x6et
        -0x80t
        0x72t
        -0x3dt
    .end array-data

    :array_48
    .array-data 1
        0x8t
        -0x17t
        0x1et
        -0x5at
        -0x18t
        0x42t
        -0x8t
        -0x1ft
    .end array-data
.end method


# virtual methods
.method public final a()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lcom/github/catvod/spider/merge/c/j;->l:Ljava/lang/String;

    return-object v0
.end method

.method public final b(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lcom/github/catvod/spider/merge/c/j;->a:Ljava/lang/String;

    return-void
.end method

.method public final c(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lcom/github/catvod/spider/merge/c/j;->h:Ljava/lang/String;

    return-void
.end method

.method public final d(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lcom/github/catvod/spider/merge/c/j;->g:Ljava/lang/String;

    return-void
.end method

.method public final e(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lcom/github/catvod/spider/merge/c/j;->j:Ljava/lang/String;

    return-void
.end method

.method public final f(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lcom/github/catvod/spider/merge/c/j;->i:Ljava/lang/String;

    return-void
.end method

.method public final g(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lcom/github/catvod/spider/merge/c/j;->b:Ljava/lang/String;

    return-void
.end method

.method public final h(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lcom/github/catvod/spider/merge/c/j;->c:Ljava/lang/String;

    return-void
.end method

.method public final i(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lcom/github/catvod/spider/merge/c/j;->d:Ljava/lang/String;

    return-void
.end method

.method public final j(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lcom/github/catvod/spider/merge/c/j;->k:Ljava/lang/String;

    return-void
.end method

.method public final k(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lcom/github/catvod/spider/merge/c/j;->l:Ljava/lang/String;

    return-void
.end method

.method public final l(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lcom/github/catvod/spider/merge/c/j;->e:Ljava/lang/String;

    return-void
.end method

.method public final m(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lcom/github/catvod/spider/merge/c/j;->m:Ljava/lang/String;

    return-void
.end method

.method public final n(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lcom/github/catvod/spider/merge/c/j;->f:Ljava/lang/String;

    return-void
.end method

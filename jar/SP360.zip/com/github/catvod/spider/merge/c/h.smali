.class public final Lcom/github/catvod/spider/merge/c/h;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field private a:Ljava/lang/String;
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "url"
    .end annotation
.end field

.field private b:Ljava/lang/String;
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "name"
    .end annotation
.end field

.field private c:Ljava/lang/String;
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "lang"
    .end annotation
.end field

.field private d:Ljava/lang/String;
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "format"
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/String;)Lcom/github/catvod/spider/merge/c/h;
    .registers 8

    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v0

    const v1, 0x17a81

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    const/16 v5, 0x8

    if-eq v0, v1, :cond_45

    const v1, 0x1be01

    if-eq v0, v1, :cond_2f

    const v1, 0x1c976

    if-eq v0, v1, :cond_19

    goto :goto_5b

    :cond_19
    new-array v0, v4, [B

    fill-array-data v0, :array_9a

    new-array v1, v5, [B

    fill-array-data v1, :array_a0

    invoke-static {v0, v1}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_5b

    const/4 p1, 0x0

    goto :goto_5c

    :cond_2f
    new-array v0, v4, [B

    fill-array-data v0, :array_a8

    new-array v1, v5, [B

    fill-array-data v1, :array_ae

    invoke-static {v0, v1}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_5b

    const/4 p1, 0x2

    goto :goto_5c

    :cond_45
    new-array v0, v4, [B

    fill-array-data v0, :array_b6

    new-array v1, v5, [B

    fill-array-data v1, :array_bc

    invoke-static {v0, v1}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_5b

    const/4 p1, 0x1

    goto :goto_5c

    :cond_5b
    :goto_5b
    const/4 p1, -0x1

    :goto_5c
    if-eqz p1, :cond_88

    if-eq p1, v3, :cond_75

    if-eq p1, v2, :cond_75

    const/16 p1, 0x14

    new-array p1, p1, [B

    fill-array-data p1, :array_c4

    new-array v0, v5, [B

    fill-array-data v0, :array_d2

    invoke-static {p1, v0}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    .line 1
    iput-object p1, p0, Lcom/github/catvod/spider/merge/c/h;->d:Ljava/lang/String;

    return-object p0

    :cond_75
    const/16 p1, 0xa

    new-array p1, p1, [B

    .line 2
    fill-array-data p1, :array_da

    new-array v0, v5, [B

    fill-array-data v0, :array_e4

    invoke-static {p1, v0}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    .line 3
    iput-object p1, p0, Lcom/github/catvod/spider/merge/c/h;->d:Ljava/lang/String;

    return-object p0

    :cond_88
    new-array p1, v5, [B

    .line 4
    fill-array-data p1, :array_ec

    new-array v0, v5, [B

    fill-array-data v0, :array_f4

    invoke-static {p1, v0}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p1

    .line 5
    iput-object p1, p0, Lcom/github/catvod/spider/merge/c/h;->d:Ljava/lang/String;

    return-object p0

    nop

    :array_9a
    .array-data 1
        0x71t
        0x34t
        -0x47t
    .end array-data

    :array_a0
    .array-data 1
        0x7t
        0x40t
        -0x33t
        0x29t
        -0x3dt
        0x51t
        -0x3t
        0x7et
    .end array-data

    :array_a8
    .array-data 1
        0x1dt
        -0x23t
        -0x76t
    .end array-data

    :array_ae
    .array-data 1
        0x6et
        -0x52t
        -0x15t
        -0x7bt
        -0x4dt
        -0x44t
        0x57t
        0x11t
    .end array-data

    :array_b6
    .array-data 1
        0x7et
        -0x53t
        -0x76t
    .end array-data

    :array_bc
    .array-data 1
        0x1ft
        -0x22t
        -0x7t
        0x69t
        -0x5ct
        0x1t
        0x71t
        -0x28t
    .end array-data

    :array_c4
    .array-data 1
        -0x4at
        -0x2dt
        -0x14t
        0x22t
        0x6ft
        0x4t
        -0x71t
        0x3dt
        -0x42t
        -0x34t
        -0xet
        0x61t
        0x7et
        0x4at
        -0x63t
        0x3ct
        -0x4bt
        -0x2ft
        -0xbt
        0x3et
    .end array-data

    :array_d2
    .array-data 1
        -0x29t
        -0x5dt
        -0x64t
        0x4et
        0x6t
        0x67t
        -0x12t
        0x49t
    .end array-data

    :array_da
    .array-data 1
        0x61t
        -0x59t
        0x49t
        -0x69t
        0x63t
        -0x9t
        0x6dt
        0x7ft
        0x66t
        -0x5dt
    .end array-data

    nop

    :array_e4
    .array-data 1
        0x15t
        -0x3et
        0x31t
        -0x1dt
        0x4ct
        -0x71t
        0x40t
        0xct
    .end array-data

    :array_ec
    .array-data 1
        0x73t
        -0x3ft
        0x17t
        0x48t
        -0x2at
        0xdt
        0x4at
        -0x4at
    .end array-data

    :array_f4
    .array-data 1
        0x7t
        -0x5ct
        0x6ft
        0x3ct
        -0x7t
        0x7bt
        0x3et
        -0x3et
    .end array-data
.end method

.method public final b(Ljava/lang/String;)Lcom/github/catvod/spider/merge/c/h;
    .registers 2

    iput-object p1, p0, Lcom/github/catvod/spider/merge/c/h;->c:Ljava/lang/String;

    return-object p0
.end method

.method public final c(Ljava/lang/String;)Lcom/github/catvod/spider/merge/c/h;
    .registers 2

    iput-object p1, p0, Lcom/github/catvod/spider/merge/c/h;->b:Ljava/lang/String;

    return-object p0
.end method

.method public final d(Ljava/lang/String;)Lcom/github/catvod/spider/merge/c/h;
    .registers 2

    iput-object p1, p0, Lcom/github/catvod/spider/merge/c/h;->a:Ljava/lang/String;

    return-object p0
.end method

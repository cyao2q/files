.class public final Lcom/github/catvod/spider/merge/c/i;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field private final a:Ljava/lang/String;
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "type"
    .end annotation
.end field

.field private b:Ljava/lang/Float;
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "ratio"
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/Float;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/github/catvod/spider/merge/c/i;->a:Ljava/lang/String;

    iput-object p2, p0, Lcom/github/catvod/spider/merge/c/i;->b:Ljava/lang/Float;

    return-void
.end method

.method public static a(F)Lcom/github/catvod/spider/merge/c/i;
    .registers 4

    new-instance v0, Lcom/github/catvod/spider/merge/c/i;

    const/4 v1, 0x4

    new-array v1, v1, [B

    fill-array-data v1, :array_1c

    const/16 v2, 0x8

    new-array v2, v2, [B

    fill-array-data v2, :array_22

    invoke-static {v1, v2}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-static {p0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p0

    invoke-direct {v0, v1, p0}, Lcom/github/catvod/spider/merge/c/i;-><init>(Ljava/lang/String;Ljava/lang/Float;)V

    return-object v0

    nop

    :array_1c
    .array-data 1
        -0x4dt
        -0x3t
        0x7bt
        0x9t
    .end array-data

    :array_22
    .array-data 1
        -0x3ft
        -0x68t
        0x18t
        0x7dt
        -0x27t
        0x6ct
        0x41t
        0x27t
    .end array-data
.end method

.class public final Lcom/github/catvod/spider/merge/c/g;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field private a:Ljava/util/List;
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "class"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/github/catvod/spider/merge/c/a;",
            ">;"
        }
    .end annotation
.end field

.field private b:Ljava/util/List;
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "list"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/github/catvod/spider/merge/c/j;",
            ">;"
        }
    .end annotation
.end field

.field private c:Ljava/util/LinkedHashMap;
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "filters"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/LinkedHashMap<",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lcom/github/catvod/spider/merge/c/c;",
            ">;>;"
        }
    .end annotation
.end field

.field private d:Ljava/lang/String;
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "header"
    .end annotation
.end field

.field private e:Ljava/lang/String;
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "format"
    .end annotation
.end field

.field private f:Ljava/lang/String;
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "danmaku"
    .end annotation
.end field

.field private g:Ljava/lang/String;
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "click"
    .end annotation
.end field

.field private h:Ljava/lang/String;
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "msg"
    .end annotation
.end field

.field private i:Ljava/lang/Object;
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "url"
    .end annotation
.end field

.field private j:Ljava/util/List;
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "subs"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/github/catvod/spider/merge/c/h;",
            ">;"
        }
    .end annotation
.end field

.field private k:I
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "parse"
    .end annotation
.end field

.field private l:I
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "jx"
    .end annotation
.end field

.field private m:Ljava/lang/Integer;
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "page"
    .end annotation
.end field

.field private n:Ljava/lang/Integer;
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "pagecount"
    .end annotation
.end field

.field private o:Ljava/lang/Integer;
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "limit"
    .end annotation
.end field

.field private p:Ljava/lang/Integer;
    .annotation runtime Lcom/google/gson/annotations/SerializedName;
        value = "total"
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static c(Ljava/lang/String;)Ljava/lang/String;
    .registers 3

    .line 1
    new-instance v0, Lcom/github/catvod/spider/merge/c/g;

    invoke-direct {v0}, Lcom/github/catvod/spider/merge/c/g;-><init>()V

    .line 2
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v1

    .line 3
    iput-object v1, v0, Lcom/github/catvod/spider/merge/c/g;->b:Ljava/util/List;

    .line 4
    iput-object p0, v0, Lcom/github/catvod/spider/merge/c/g;->h:Ljava/lang/String;

    .line 5
    invoke-virtual {v0}, Lcom/github/catvod/spider/merge/c/g;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static e()Lcom/github/catvod/spider/merge/c/g;
    .registers 1

    new-instance v0, Lcom/github/catvod/spider/merge/c/g;

    invoke-direct {v0}, Lcom/github/catvod/spider/merge/c/g;-><init>()V

    return-object v0
.end method

.method public static i(Ljava/lang/String;)Ljava/lang/String;
    .registers 2

    .line 1
    new-instance v0, Lcom/github/catvod/spider/merge/c/g;

    invoke-direct {v0}, Lcom/github/catvod/spider/merge/c/g;-><init>()V

    .line 2
    iput-object p0, v0, Lcom/github/catvod/spider/merge/c/g;->h:Ljava/lang/String;

    .line 3
    invoke-virtual {v0}, Lcom/github/catvod/spider/merge/c/g;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static n(Ljava/lang/String;)Ljava/lang/String;
    .registers 15

    :try_start_0
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const/4 v1, 0x5

    new-array v2, v1, [B

    const/4 v3, 0x6

    const/4 v4, 0x0

    aput-byte v3, v2, v4

    const/4 v5, -0x8

    const/4 v6, 0x1

    aput-byte v5, v2, v6

    const/16 v5, 0x3c

    const/4 v7, 0x2

    aput-byte v5, v2, v7

    const/4 v5, 0x3

    aput-byte v4, v2, v5

    const/16 v8, 0x24

    const/4 v9, 0x4

    aput-byte v8, v2, v9

    const/16 v8, 0x8

    new-array v10, v8, [B

    const/16 v11, 0x76

    aput-byte v11, v10, v4

    const/16 v11, -0x67

    aput-byte v11, v10, v6

    const/16 v11, 0x4e

    aput-byte v11, v10, v7

    const/16 v11, 0x73

    aput-byte v11, v10, v5

    const/16 v11, 0x41

    aput-byte v11, v10, v9

    const/16 v11, -0x5a

    aput-byte v11, v10, v1

    const/16 v11, 0x3e

    aput-byte v11, v10, v3

    const/16 v11, 0xf

    const/4 v12, 0x7

    aput-byte v11, v10, v12

    invoke-static {v2, v10}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    new-array v2, v5, [B

    const/16 v10, -0x39

    aput-byte v10, v2, v4

    const/16 v10, -0x26

    aput-byte v10, v2, v6

    const/16 v11, 0x5f

    aput-byte v11, v2, v7

    new-array v11, v8, [B

    const/16 v13, -0x4e

    aput-byte v13, v11, v4

    const/16 v13, -0x58

    aput-byte v13, v11, v6

    const/16 v13, 0x33

    aput-byte v13, v11, v7

    const/16 v13, 0x37

    aput-byte v13, v11, v5

    const/16 v13, 0x5e

    aput-byte v13, v11, v9

    const/16 v13, 0x36

    aput-byte v13, v11, v1

    const/16 v13, 0x6d

    aput-byte v13, v11, v3

    const/16 v13, -0x40

    aput-byte v13, v11, v12

    invoke-static {v2, v11}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    const-string v11, ""

    invoke-virtual {v0, v2, v11}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v2, v5, [B

    const/16 v11, -0x54

    aput-byte v11, v2, v4

    const/16 v11, -0x48

    aput-byte v11, v2, v6

    const/16 v11, -0x7f

    aput-byte v11, v2, v7

    new-array v11, v8, [B

    const/16 v13, -0x3f

    aput-byte v13, v11, v4

    const/16 v13, -0x35

    aput-byte v13, v11, v6

    const/16 v13, -0x1a

    aput-byte v13, v11, v7

    const/16 v13, -0x5c

    aput-byte v13, v11, v5

    const/16 v13, -0x3d

    aput-byte v13, v11, v9

    const/16 v13, -0x29

    aput-byte v13, v11, v1

    const/16 v13, 0x61

    aput-byte v13, v11, v3

    const/16 v13, -0xd

    aput-byte v13, v11, v12

    invoke-static {v2, v11}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    new-array v2, v3, [B

    const/16 v11, 0xe

    aput-byte v11, v2, v4

    const/16 v11, -0x4a

    aput-byte v11, v2, v6

    const/16 v11, 0x70

    aput-byte v11, v2, v7

    const/16 v11, 0x47

    aput-byte v11, v2, v5

    const/16 v11, -0x14

    aput-byte v11, v2, v9

    const/16 v11, -0x43

    aput-byte v11, v2, v1

    new-array v8, v8, [B

    const/16 v11, 0x6b

    aput-byte v11, v8, v4

    const/16 v4, -0x3c

    aput-byte v4, v8, v6

    aput-byte v7, v8, v7

    const/16 v4, 0xa

    aput-byte v4, v8, v5

    const/16 v4, -0x61

    aput-byte v4, v8, v9

    aput-byte v10, v8, v1

    const/16 v1, 0x56

    aput-byte v1, v8, v3

    const/16 v1, -0x18

    aput-byte v1, v8, v12

    invoke-static {v2, v8}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_fc
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_fc} :catch_fc

    :catch_fc
    return-object p0
.end method

.method public static p(Lcom/github/catvod/spider/merge/c/j;)Ljava/lang/String;
    .registers 2

    .line 1
    new-instance v0, Lcom/github/catvod/spider/merge/c/g;

    invoke-direct {v0}, Lcom/github/catvod/spider/merge/c/g;-><init>()V

    .line 2
    invoke-static {p0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    iput-object p0, v0, Lcom/github/catvod/spider/merge/c/g;->b:Ljava/util/List;

    .line 3
    invoke-virtual {v0}, Lcom/github/catvod/spider/merge/c/g;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static q(Ljava/util/List;)Ljava/lang/String;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/github/catvod/spider/merge/c/a;",
            ">;",
            "Lcom/google/gson/JsonElement;",
            ")",
            "Ljava/lang/String;"
        }
    .end annotation

    .line 1
    new-instance v0, Lcom/github/catvod/spider/merge/c/g;

    invoke-direct {v0}, Lcom/github/catvod/spider/merge/c/g;-><init>()V

    .line 2
    iput-object p0, v0, Lcom/github/catvod/spider/merge/c/g;->a:Ljava/util/List;

    .line 3
    invoke-virtual {v0}, Lcom/github/catvod/spider/merge/c/g;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static r(Ljava/util/List;Ljava/util/LinkedHashMap;)Ljava/lang/String;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/github/catvod/spider/merge/c/a;",
            ">;",
            "Ljava/util/LinkedHashMap<",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lcom/github/catvod/spider/merge/c/c;",
            ">;>;)",
            "Ljava/lang/String;"
        }
    .end annotation

    .line 1
    new-instance v0, Lcom/github/catvod/spider/merge/c/g;

    invoke-direct {v0}, Lcom/github/catvod/spider/merge/c/g;-><init>()V

    .line 2
    iput-object p0, v0, Lcom/github/catvod/spider/merge/c/g;->a:Ljava/util/List;

    .line 3
    iput-object p1, v0, Lcom/github/catvod/spider/merge/c/g;->c:Ljava/util/LinkedHashMap;

    .line 4
    invoke-virtual {v0}, Lcom/github/catvod/spider/merge/c/g;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static s(Ljava/util/List;Ljava/util/List;)Ljava/lang/String;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/github/catvod/spider/merge/c/a;",
            ">;",
            "Ljava/util/List<",
            "Lcom/github/catvod/spider/merge/c/j;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    .line 1
    new-instance v0, Lcom/github/catvod/spider/merge/c/g;

    invoke-direct {v0}, Lcom/github/catvod/spider/merge/c/g;-><init>()V

    .line 2
    iput-object p0, v0, Lcom/github/catvod/spider/merge/c/g;->a:Ljava/util/List;

    .line 3
    iput-object p1, v0, Lcom/github/catvod/spider/merge/c/g;->b:Ljava/util/List;

    .line 4
    invoke-virtual {v0}, Lcom/github/catvod/spider/merge/c/g;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static t(Ljava/util/List;Ljava/util/List;Ljava/util/LinkedHashMap;)Ljava/lang/String;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/github/catvod/spider/merge/c/a;",
            ">;",
            "Ljava/util/List<",
            "Lcom/github/catvod/spider/merge/c/j;",
            ">;",
            "Ljava/util/LinkedHashMap<",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lcom/github/catvod/spider/merge/c/c;",
            ">;>;)",
            "Ljava/lang/String;"
        }
    .end annotation

    .line 1
    new-instance v0, Lcom/github/catvod/spider/merge/c/g;

    invoke-direct {v0}, Lcom/github/catvod/spider/merge/c/g;-><init>()V

    .line 2
    iput-object p0, v0, Lcom/github/catvod/spider/merge/c/g;->a:Ljava/util/List;

    .line 3
    iput-object p1, v0, Lcom/github/catvod/spider/merge/c/g;->b:Ljava/util/List;

    .line 4
    iput-object p2, v0, Lcom/github/catvod/spider/merge/c/g;->c:Ljava/util/LinkedHashMap;

    .line 5
    invoke-virtual {v0}, Lcom/github/catvod/spider/merge/c/g;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static u(Ljava/util/List;Ljava/util/List;Lorg/json/JSONObject;)Ljava/lang/String;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/github/catvod/spider/merge/c/a;",
            ">;",
            "Ljava/util/List<",
            "Lcom/github/catvod/spider/merge/c/j;",
            ">;",
            "Lorg/json/JSONObject;",
            ")",
            "Ljava/lang/String;"
        }
    .end annotation

    .line 1
    new-instance v0, Lcom/github/catvod/spider/merge/c/g;

    invoke-direct {v0}, Lcom/github/catvod/spider/merge/c/g;-><init>()V

    .line 2
    iput-object p0, v0, Lcom/github/catvod/spider/merge/c/g;->a:Ljava/util/List;

    .line 3
    iput-object p1, v0, Lcom/github/catvod/spider/merge/c/g;->b:Ljava/util/List;

    .line 4
    invoke-virtual {v0, p2}, Lcom/github/catvod/spider/merge/c/g;->d(Lorg/json/JSONObject;)Lcom/github/catvod/spider/merge/c/g;

    .line 5
    invoke-virtual {v0}, Lcom/github/catvod/spider/merge/c/g;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static v(Ljava/util/List;Lorg/json/JSONObject;)Ljava/lang/String;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/github/catvod/spider/merge/c/a;",
            ">;",
            "Lorg/json/JSONObject;",
            ")",
            "Ljava/lang/String;"
        }
    .end annotation

    .line 1
    new-instance v0, Lcom/github/catvod/spider/merge/c/g;

    invoke-direct {v0}, Lcom/github/catvod/spider/merge/c/g;-><init>()V

    .line 2
    iput-object p0, v0, Lcom/github/catvod/spider/merge/c/g;->a:Ljava/util/List;

    .line 3
    invoke-virtual {v0, p1}, Lcom/github/catvod/spider/merge/c/g;->d(Lorg/json/JSONObject;)Lcom/github/catvod/spider/merge/c/g;

    .line 4
    invoke-virtual {v0}, Lcom/github/catvod/spider/merge/c/g;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static w(Ljava/util/List;)Ljava/lang/String;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/github/catvod/spider/merge/c/j;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    .line 1
    new-instance v0, Lcom/github/catvod/spider/merge/c/g;

    invoke-direct {v0}, Lcom/github/catvod/spider/merge/c/g;-><init>()V

    .line 2
    iput-object p0, v0, Lcom/github/catvod/spider/merge/c/g;->b:Ljava/util/List;

    .line 3
    invoke-virtual {v0}, Lcom/github/catvod/spider/merge/c/g;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final A(Ljava/util/List;)Lcom/github/catvod/spider/merge/c/g;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/github/catvod/spider/merge/c/j;",
            ">;)",
            "Lcom/github/catvod/spider/merge/c/g;"
        }
    .end annotation

    iput-object p1, p0, Lcom/github/catvod/spider/merge/c/g;->b:Ljava/util/List;

    return-object p0
.end method

.method public final a(Ljava/lang/String;)Lcom/github/catvod/spider/merge/c/g;
    .registers 2

    iput-object p1, p0, Lcom/github/catvod/spider/merge/c/g;->f:Ljava/lang/String;

    return-object p0
.end method

.method public final b()Lcom/github/catvod/spider/merge/c/g;
    .registers 3

    const/16 v0, 0x14

    new-array v0, v0, [B

    fill-array-data v0, :array_16

    const/16 v1, 0x8

    new-array v1, v1, [B

    fill-array-data v1, :array_24

    invoke-static {v0, v1}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/github/catvod/spider/merge/c/g;->e:Ljava/lang/String;

    return-object p0

    nop

    :array_16
    .array-data 1
        -0x27t
        -0x62t
        0x54t
        0x5t
        -0x38t
        0x63t
        -0x6t
        0x24t
        -0x2ft
        -0x7ft
        0x4at
        0x46t
        -0x3bt
        0x61t
        -0x18t
        0x38t
        -0x6dt
        -0x6at
        0x49t
        0x5t
    .end array-data

    :array_24
    .array-data 1
        -0x48t
        -0x12t
        0x24t
        0x69t
        -0x5ft
        0x0t
        -0x65t
        0x50t
    .end array-data
.end method

.method public final d(Lorg/json/JSONObject;)Lcom/github/catvod/spider/merge/c/g;
    .registers 4

    new-instance v0, Lcom/github/catvod/spider/merge/c/f;

    invoke-direct {v0}, Lcom/github/catvod/spider/merge/c/f;-><init>()V

    invoke-virtual {v0}, Lcom/google/gson/reflect/TypeToken;->getType()Ljava/lang/reflect/Type;

    move-result-object v0

    new-instance v1, Lcom/google/gson/Gson;

    invoke-direct {v1}, Lcom/google/gson/Gson;-><init>()V

    invoke-virtual {p1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1, v0}, Lcom/google/gson/Gson;->fromJson(Ljava/lang/String;Ljava/lang/reflect/Type;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/LinkedHashMap;

    iput-object p1, p0, Lcom/github/catvod/spider/merge/c/g;->c:Ljava/util/LinkedHashMap;

    return-object p0
.end method

.method public final f(Ljava/util/Map;)Lcom/github/catvod/spider/merge/c/g;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lcom/github/catvod/spider/merge/c/g;"
        }
    .end annotation

    invoke-interface {p1}, Ljava/util/Map;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_7

    return-object p0

    :cond_7
    new-instance v0, Lcom/google/gson/Gson;

    invoke-direct {v0}, Lcom/google/gson/Gson;-><init>()V

    invoke-virtual {v0, p1}, Lcom/google/gson/Gson;->toJson(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/github/catvod/spider/merge/c/g;->d:Ljava/lang/String;

    return-object p0
.end method

.method public final g()Lcom/github/catvod/spider/merge/c/g;
    .registers 2

    const/4 v0, 0x1

    iput v0, p0, Lcom/github/catvod/spider/merge/c/g;->l:I

    return-object p0
.end method

.method public final h()Lcom/github/catvod/spider/merge/c/g;
    .registers 3

    const/16 v0, 0x15

    new-array v0, v0, [B

    fill-array-data v0, :array_16

    const/16 v1, 0x8

    new-array v1, v1, [B

    fill-array-data v1, :array_26

    invoke-static {v0, v1}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/github/catvod/spider/merge/c/g;->e:Ljava/lang/String;

    return-object p0

    nop

    :array_16
    .array-data 1
        0x30t
        0xct
        0x24t
        0x59t
        -0x28t
        -0x7ct
        0x2ct
        -0x57t
        0x38t
        0x13t
        0x3at
        0x1at
        -0x37t
        -0x36t
        0x20t
        -0x53t
        0x34t
        0x1bt
        0x1t
        0x67t
        -0x3t
    .end array-data

    nop

    :array_26
    .array-data 1
        0x51t
        0x7ct
        0x54t
        0x35t
        -0x4ft
        -0x19t
        0x4dt
        -0x23t
    .end array-data
.end method

.method public final j()Lcom/github/catvod/spider/merge/c/g;
    .registers 3

    const/16 v0, 0x18

    new-array v0, v0, [B

    fill-array-data v0, :array_16

    const/16 v1, 0x8

    new-array v1, v1, [B

    fill-array-data v1, :array_26

    invoke-static {v0, v1}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/github/catvod/spider/merge/c/g;->e:Ljava/lang/String;

    return-object p0

    nop

    :array_16
    .array-data 1
        -0x62t
        -0x1bt
        0x14t
        -0x6t
        -0x70t
        0x70t
        0x3dt
        -0x16t
        -0x6at
        -0x6t
        0xat
        -0x47t
        -0x6at
        0x70t
        0x28t
        -0x5t
        -0x75t
        -0x48t
        0x17t
        -0x1et
        -0x75t
        0x76t
        0x3dt
        -0xdt
    .end array-data

    :array_26
    .array-data 1
        -0x1t
        -0x6bt
        0x64t
        -0x6at
        -0x7t
        0x13t
        0x5ct
        -0x62t
    .end array-data
.end method

.method public final k(IIII)Lcom/github/catvod/spider/merge/c/g;
    .registers 6

    const v0, 0x7fffffff

    if-lez p1, :cond_6

    goto :goto_9

    :cond_6
    const p1, 0x7fffffff

    :goto_9
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    iput-object p1, p0, Lcom/github/catvod/spider/merge/c/g;->m:Ljava/lang/Integer;

    if-lez p3, :cond_12

    goto :goto_15

    :cond_12
    const p3, 0x7fffffff

    :goto_15
    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    iput-object p1, p0, Lcom/github/catvod/spider/merge/c/g;->o:Ljava/lang/Integer;

    if-lez p4, :cond_1e

    goto :goto_21

    :cond_1e
    const p4, 0x7fffffff

    :goto_21
    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    iput-object p1, p0, Lcom/github/catvod/spider/merge/c/g;->p:Ljava/lang/Integer;

    if-lez p2, :cond_2a

    goto :goto_2d

    :cond_2a
    const p2, 0x7fffffff

    :goto_2d
    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    iput-object p1, p0, Lcom/github/catvod/spider/merge/c/g;->n:Ljava/lang/Integer;

    return-object p0
.end method

.method public final l()Lcom/github/catvod/spider/merge/c/g;
    .registers 2

    const/4 v0, 0x1

    iput v0, p0, Lcom/github/catvod/spider/merge/c/g;->k:I

    return-object p0
.end method

.method public final m(I)Lcom/github/catvod/spider/merge/c/g;
    .registers 2

    iput p1, p0, Lcom/github/catvod/spider/merge/c/g;->k:I

    return-object p0
.end method

.method public final o()Ljava/lang/String;
    .registers 2

    invoke-virtual {p0}, Lcom/github/catvod/spider/merge/c/g;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 2

    new-instance v0, Lcom/google/gson/Gson;

    invoke-direct {v0}, Lcom/google/gson/Gson;-><init>()V

    invoke-virtual {v0}, Lcom/google/gson/Gson;->newBuilder()Lcom/google/gson/GsonBuilder;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/gson/GsonBuilder;->disableHtmlEscaping()Lcom/google/gson/GsonBuilder;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/gson/GsonBuilder;->create()Lcom/google/gson/Gson;

    move-result-object v0

    invoke-virtual {v0, p0}, Lcom/google/gson/Gson;->toJson(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final x(Ljava/util/List;)Lcom/github/catvod/spider/merge/c/g;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/github/catvod/spider/merge/c/h;",
            ">;)",
            "Lcom/github/catvod/spider/merge/c/g;"
        }
    .end annotation

    iput-object p1, p0, Lcom/github/catvod/spider/merge/c/g;->j:Ljava/util/List;

    return-object p0
.end method

.method public final y(Ljava/lang/String;)Lcom/github/catvod/spider/merge/c/g;
    .registers 2

    iput-object p1, p0, Lcom/github/catvod/spider/merge/c/g;->i:Ljava/lang/Object;

    return-object p0
.end method

.method public final z(Ljava/util/List;)Lcom/github/catvod/spider/merge/c/g;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)",
            "Lcom/github/catvod/spider/merge/c/g;"
        }
    .end annotation

    iput-object p1, p0, Lcom/github/catvod/spider/merge/c/g;->i:Ljava/lang/Object;

    return-object p0
.end method

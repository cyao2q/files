.class final Lcom/github/catvod/spider/merge/q/d;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field private a:Ljava/lang/String;

.field private b:Ljava/lang/Object;

.field private final c:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final d:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final e:Lcom/github/catvod/spider/merge/q/c;

.field private f:Lokhttp3/Request;

.field private g:Lokhttp3/Request$Builder;


# direct methods
.method constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;Lcom/github/catvod/spider/merge/q/c;)V
    .registers 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Lcom/github/catvod/spider/merge/q/c;",
            ")V"
        }
    .end annotation

    const/4 v4, 0x0

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v5, p4

    move-object v6, p5

    invoke-direct/range {v0 .. v6}, Lcom/github/catvod/spider/merge/q/d;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;Lcom/github/catvod/spider/merge/q/c;)V

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;Lcom/github/catvod/spider/merge/q/c;)V
    .registers 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Lcom/github/catvod/spider/merge/q/c;",
            ")V"
        }
    .end annotation

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/github/catvod/spider/merge/q/d;->b:Ljava/lang/Object;

    iput-object p2, p0, Lcom/github/catvod/spider/merge/q/d;->a:Ljava/lang/String;

    iput-object p4, p0, Lcom/github/catvod/spider/merge/q/d;->c:Ljava/util/Map;

    iput-object p5, p0, Lcom/github/catvod/spider/merge/q/d;->d:Ljava/util/Map;

    iput-object p6, p0, Lcom/github/catvod/spider/merge/q/d;->e:Lcom/github/catvod/spider/merge/q/c;

    .line 1
    new-instance p2, Lokhttp3/Request$Builder;

    invoke-direct {p2}, Lokhttp3/Request$Builder;-><init>()V

    iput-object p2, p0, Lcom/github/catvod/spider/merge/q/d;->g:Lokhttp3/Request$Builder;

    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result p2

    const/4 p5, 0x0

    const/4 p6, 0x1

    const v0, 0x11336

    const/16 v1, 0x8

    if-eq p2, v0, :cond_3f

    const v0, 0x2590a0

    if-eq p2, v0, :cond_28

    goto :goto_56

    :cond_28
    const/4 p2, 0x4

    new-array p2, p2, [B

    fill-array-data p2, :array_168

    new-array v0, v1, [B

    fill-array-data v0, :array_16e

    invoke-static {p2, v0}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_56

    const/4 p1, 0x1

    goto :goto_57

    :cond_3f
    const/4 p2, 0x3

    new-array p2, p2, [B

    fill-array-data p2, :array_176

    new-array v0, v1, [B

    fill-array-data v0, :array_17c

    invoke-static {p2, v0}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_56

    const/4 p1, 0x0

    goto :goto_57

    :cond_56
    :goto_56
    const/4 p1, -0x1

    :goto_57
    if-eqz p1, :cond_ae

    if-eq p1, p6, :cond_5d

    goto/16 :goto_128

    :cond_5d
    iget-object p1, p0, Lcom/github/catvod/spider/merge/q/d;->g:Lokhttp3/Request$Builder;

    .line 2
    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p2

    if-nez p2, :cond_7e

    const/16 p2, 0x1f

    new-array p2, p2, [B

    fill-array-data p2, :array_184

    new-array p4, v1, [B

    fill-array-data p4, :array_198

    invoke-static {p2, p4}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p2

    invoke-static {p2}, Lokhttp3/MediaType;->parse(Ljava/lang/String;)Lokhttp3/MediaType;

    move-result-object p2

    invoke-static {p2, p3}, Lokhttp3/RequestBody;->create(Lokhttp3/MediaType;Ljava/lang/String;)Lokhttp3/RequestBody;

    move-result-object p2

    goto :goto_a9

    :cond_7e
    new-instance p2, Lokhttp3/FormBody$Builder;

    invoke-direct {p2}, Lokhttp3/FormBody$Builder;-><init>()V

    if-eqz p4, :cond_a5

    invoke-interface {p4}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object p3

    invoke-interface {p3}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p3

    :goto_8d
    invoke-interface {p3}, Ljava/util/Iterator;->hasNext()Z

    move-result p4

    if-eqz p4, :cond_a5

    invoke-interface {p3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p4

    check-cast p4, Ljava/lang/String;

    iget-object p5, p0, Lcom/github/catvod/spider/merge/q/d;->c:Ljava/util/Map;

    invoke-interface {p5, p4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p5

    check-cast p5, Ljava/lang/String;

    invoke-virtual {p2, p4, p5}, Lokhttp3/FormBody$Builder;->add(Ljava/lang/String;Ljava/lang/String;)Lokhttp3/FormBody$Builder;

    goto :goto_8d

    :cond_a5
    invoke-virtual {p2}, Lokhttp3/FormBody$Builder;->build()Lokhttp3/FormBody;

    move-result-object p2

    .line 3
    :goto_a9
    invoke-virtual {p1, p2}, Lokhttp3/Request$Builder;->post(Lokhttp3/RequestBody;)Lokhttp3/Request$Builder;

    goto/16 :goto_128

    :cond_ae
    if-eqz p4, :cond_128

    .line 4
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object p2, p0, Lcom/github/catvod/spider/merge/q/d;->a:Ljava/lang/String;

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array p2, p6, [B

    const/16 p3, 0xf

    aput-byte p3, p2, p5

    new-array p3, v1, [B

    fill-array-data p3, :array_1a0

    .line 5
    invoke-static {p2, p3, p1}, Lcom/github/catvod/spider/merge/b/t;->b([B[BLjava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object p1

    .line 6
    iput-object p1, p0, Lcom/github/catvod/spider/merge/q/d;->a:Ljava/lang/String;

    invoke-interface {p4}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_d3
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p2

    if-eqz p2, :cond_11b

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/lang/String;

    new-instance p3, Ljava/lang/StringBuilder;

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    iget-object p4, p0, Lcom/github/catvod/spider/merge/q/d;->a:Ljava/lang/String;

    invoke-virtual {p3, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array p4, p6, [B

    const/16 v0, 0x20

    aput-byte v0, p4, p5

    new-array v0, v1, [B

    fill-array-data v0, :array_1a8

    invoke-static {p4, v0}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p4

    invoke-virtual {p3, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p4, p0, Lcom/github/catvod/spider/merge/q/d;->c:Ljava/util/Map;

    invoke-interface {p4, p2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/lang/String;

    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-array p2, p6, [B

    const/16 p4, -0x20

    aput-byte p4, p2, p5

    new-array p4, v1, [B

    fill-array-data p4, :array_1b0

    .line 7
    invoke-static {p2, p4, p3}, Lcom/github/catvod/spider/merge/b/t;->b([B[BLjava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object p2

    .line 8
    iput-object p2, p0, Lcom/github/catvod/spider/merge/q/d;->a:Ljava/lang/String;

    goto :goto_d3

    :cond_11b
    iget-object p1, p0, Lcom/github/catvod/spider/merge/q/d;->a:Ljava/lang/String;

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result p2

    sub-int/2addr p2, p6

    invoke-virtual {p1, p5, p2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/github/catvod/spider/merge/q/d;->a:Ljava/lang/String;

    .line 9
    :cond_128
    :goto_128
    iget-object p1, p0, Lcom/github/catvod/spider/merge/q/d;->g:Lokhttp3/Request$Builder;

    iget-object p2, p0, Lcom/github/catvod/spider/merge/q/d;->a:Ljava/lang/String;

    invoke-virtual {p1, p2}, Lokhttp3/Request$Builder;->url(Ljava/lang/String;)Lokhttp3/Request$Builder;

    iget-object p1, p0, Lcom/github/catvod/spider/merge/q/d;->b:Ljava/lang/Object;

    if-eqz p1, :cond_138

    iget-object p2, p0, Lcom/github/catvod/spider/merge/q/d;->g:Lokhttp3/Request$Builder;

    invoke-virtual {p2, p1}, Lokhttp3/Request$Builder;->tag(Ljava/lang/Object;)Lokhttp3/Request$Builder;

    :cond_138
    iget-object p1, p0, Lcom/github/catvod/spider/merge/q/d;->d:Ljava/util/Map;

    if-eqz p1, :cond_15e

    .line 10
    invoke-interface {p1}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_144
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p2

    if-eqz p2, :cond_15e

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/lang/String;

    iget-object p3, p0, Lcom/github/catvod/spider/merge/q/d;->g:Lokhttp3/Request$Builder;

    iget-object p4, p0, Lcom/github/catvod/spider/merge/q/d;->d:Ljava/util/Map;

    invoke-interface {p4, p2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p4

    check-cast p4, Ljava/lang/String;

    invoke-virtual {p3, p2, p4}, Lokhttp3/Request$Builder;->addHeader(Ljava/lang/String;Ljava/lang/String;)Lokhttp3/Request$Builder;

    goto :goto_144

    .line 11
    :cond_15e
    iget-object p1, p0, Lcom/github/catvod/spider/merge/q/d;->g:Lokhttp3/Request$Builder;

    invoke-virtual {p1}, Lokhttp3/Request$Builder;->build()Lokhttp3/Request;

    move-result-object p1

    iput-object p1, p0, Lcom/github/catvod/spider/merge/q/d;->f:Lokhttp3/Request;

    return-void

    nop

    :array_168
    .array-data 1
        -0x6et
        0x57t
        -0x5at
        -0x2bt
    .end array-data

    :array_16e
    .array-data 1
        -0x3et
        0x18t
        -0xbt
        -0x7ft
        -0x11t
        0x53t
        0x70t
        -0x15t
    .end array-data

    :array_176
    .array-data 1
        0x7et
        0x3ft
        0x3et
    .end array-data

    :array_17c
    .array-data 1
        0x39t
        0x7at
        0x6at
        0x4t
        -0x56t
        -0x9t
        -0x59t
        -0x53t
    .end array-data

    :array_184
    .array-data 1
        0x26t
        -0x2ft
        0x1et
        -0x1at
        -0x7ct
        0x69t
        -0x7ct
        -0x31t
        0x2et
        -0x32t
        0x0t
        -0x5bt
        -0x79t
        0x79t
        -0x76t
        -0x2bt
        0x7ct
        -0x7ft
        0xdt
        -0x1et
        -0x74t
        0x78t
        -0x6at
        -0x22t
        0x33t
        -0x64t
        0x1bt
        -0x2t
        -0x75t
        0x27t
        -0x23t
    .end array-data

    :array_198
    .array-data 1
        0x47t
        -0x5ft
        0x6et
        -0x76t
        -0x13t
        0xat
        -0x1bt
        -0x45t
    .end array-data

    :array_1a0
    .array-data 1
        0x30t
        0x4ct
        -0x63t
        0x7bt
        0x5dt
        0x3ct
        -0x4dt
        0x1t
    .end array-data

    :array_1a8
    .array-data 1
        0x1dt
        0x3et
        -0x78t
        0x30t
        0x60t
        0x65t
        -0x38t
        -0x2t
    .end array-data

    :array_1b0
    .array-data 1
        -0x3at
        0x19t
        0x6dt
        0x49t
        -0x7t
        -0x5at
        0x67t
        0x74t
    .end array-data
.end method

.method constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;Lcom/github/catvod/spider/merge/q/c;)V
    .registers 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Lcom/github/catvod/spider/merge/q/c;",
            ")V"
        }
    .end annotation

    const/4 v3, 0x0

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v4, p3

    move-object v5, p4

    move-object v6, p5

    invoke-direct/range {v0 .. v6}, Lcom/github/catvod/spider/merge/q/d;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;Lcom/github/catvod/spider/merge/q/c;)V

    return-void
.end method


# virtual methods
.method final a(Lokhttp3/OkHttpClient;)V
    .registers 4

    iget-object v0, p0, Lcom/github/catvod/spider/merge/q/d;->f:Lokhttp3/Request;

    invoke-virtual {p1, v0}, Lokhttp3/OkHttpClient;->newCall(Lokhttp3/Request;)Lokhttp3/Call;

    move-result-object p1

    :try_start_6
    invoke-interface {p1}, Lokhttp3/Call;->execute()Lokhttp3/Response;

    move-result-object v0

    iget-object v1, p0, Lcom/github/catvod/spider/merge/q/d;->e:Lcom/github/catvod/spider/merge/q/c;

    if-eqz v1, :cond_1a

    invoke-virtual {v1, p1, v0}, Lcom/github/catvod/spider/merge/q/c;->c(Lokhttp3/Call;Lokhttp3/Response;)V
    :try_end_11
    .catch Ljava/io/IOException; {:try_start_6 .. :try_end_11} :catch_12

    goto :goto_1a

    :catch_12
    move-exception v0

    iget-object v1, p0, Lcom/github/catvod/spider/merge/q/d;->e:Lcom/github/catvod/spider/merge/q/c;

    if-eqz v1, :cond_1a

    invoke-virtual {v1, p1, v0}, Lcom/github/catvod/spider/merge/q/c;->onError(Lokhttp3/Call;Ljava/lang/Exception;)V

    :cond_1a
    :goto_1a
    return-void
.end method

.method public final b(Ljava/lang/Object;)V
    .registers 2

    iput-object p1, p0, Lcom/github/catvod/spider/merge/q/d;->b:Ljava/lang/Object;

    return-void
.end method

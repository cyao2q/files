.class public final Lcom/github/catvod/spider/merge/q/h;
.super Ljavax/net/ssl/SSLSocketFactory;
.source "SourceFile"


# static fields
.field static b:[Ljava/lang/String;

.field static c:[Ljava/lang/String;

.field public static final d:Ljavax/net/ssl/X509TrustManager;


# instance fields
.field private final a:Ljavax/net/ssl/SSLSocketFactory;


# direct methods
.method static constructor <clinit>()V
    .registers 28

    :try_start_0
    invoke-static {}, Ljavax/net/ssl/SSLSocketFactory;->getDefault()Ljavax/net/SocketFactory;

    move-result-object v1

    invoke-virtual {v1}, Ljavax/net/SocketFactory;->createSocket()Ljava/net/Socket;

    move-result-object v1

    check-cast v1, Ljavax/net/ssl/SSLSocket;

    if-eqz v1, :cond_c6d

    new-instance v2, Ljava/util/LinkedList;

    invoke-direct {v2}, Ljava/util/LinkedList;-><init>()V

    invoke-virtual {v1}, Ljavax/net/ssl/SSLSocket;->getSupportedProtocols()[Ljava/lang/String;

    move-result-object v3

    array-length v4, v3

    const/4 v5, 0x0

    const/4 v6, 0x0

    :goto_18
    const/16 v7, 0xd

    const/16 v10, 0x8

    const/4 v11, 0x3

    const/4 v13, 0x5

    const/4 v14, 0x4

    const/4 v15, 0x2

    const/16 v16, 0x1

    if-ge v6, v4, :cond_6a

    aget-object v9, v3, v6

    invoke-virtual {v9}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object v8

    new-array v12, v11, [B

    const/16 v20, 0x7a

    aput-byte v20, v12, v5

    const/16 v20, -0x10

    aput-byte v20, v12, v16

    const/16 v20, -0x2d

    aput-byte v20, v12, v15

    new-array v10, v10, [B

    const/16 v20, 0x29

    aput-byte v20, v10, v5

    const/16 v20, -0x5d

    aput-byte v20, v10, v16

    const/16 v16, -0x61

    aput-byte v16, v10, v15

    const/16 v15, -0x1e

    aput-byte v15, v10, v11

    aput-byte v7, v10, v14

    const/16 v7, -0x50

    aput-byte v7, v10, v13

    const/16 v7, 0x9

    const/4 v11, 0x6

    aput-byte v7, v10, v11

    const/16 v7, 0x49

    const/4 v11, 0x7

    aput-byte v7, v10, v11

    invoke-static {v12, v10}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v8, v7}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v7

    if-nez v7, :cond_67

    invoke-virtual {v2, v9}, Ljava/util/LinkedList;->add(Ljava/lang/Object;)Z

    :cond_67
    add-int/lit8 v6, v6, 0x1

    goto :goto_18

    :cond_6a
    invoke-virtual {v2}, Ljava/util/LinkedList;->size()I

    move-result v3

    new-array v3, v3, [Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/util/LinkedList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v2

    check-cast v2, [Ljava/lang/String;

    sput-object v2, Lcom/github/catvod/spider/merge/q/h;->b:[Ljava/lang/String;

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0x15

    if-ge v2, v3, :cond_c6d

    const/16 v2, 0xe

    new-array v4, v2, [Ljava/lang/String;

    const/16 v6, 0x1f

    new-array v6, v6, [B

    const/16 v8, -0x80

    aput-byte v8, v6, v5

    const/16 v8, 0x1c

    aput-byte v8, v6, v16

    aput-byte v8, v6, v15

    const/16 v9, -0x52

    aput-byte v9, v6, v11

    const/16 v9, -0x21

    aput-byte v9, v6, v14

    const/16 v9, -0x59

    aput-byte v9, v6, v13

    const/16 v9, -0x54

    const/4 v12, 0x6

    aput-byte v9, v6, v12

    const/16 v9, -0x4d

    const/4 v12, 0x7

    aput-byte v9, v6, v12

    const/16 v9, -0x7d

    aput-byte v9, v6, v10

    const/16 v9, 0x19

    const/16 v12, 0x9

    aput-byte v9, v6, v12

    const/16 v12, 0xa

    const/16 v20, 0x1b

    aput-byte v20, v6, v12

    const/16 v21, -0x47

    const/16 v22, 0xb

    aput-byte v21, v6, v22

    const/16 v21, -0x2e

    const/16 v23, 0xc

    aput-byte v21, v6, v23

    const/16 v21, -0x4b

    aput-byte v21, v6, v7

    const/16 v21, -0x58

    aput-byte v21, v6, v2

    const/16 v21, 0xf

    const/16 v24, -0x41

    aput-byte v24, v6, v21

    const/16 v21, 0x10

    const/16 v24, -0x75

    aput-byte v24, v6, v21

    const/16 v21, 0x11

    const/16 v24, 0x62

    aput-byte v24, v6, v21

    const/16 v21, 0x7a

    const/16 v24, 0x12

    aput-byte v21, v6, v24

    const/16 v21, -0x39

    const/16 v25, 0x13

    aput-byte v21, v6, v25

    const/16 v21, 0x14

    const/16 v26, -0x2e

    aput-byte v26, v6, v21

    const/16 v21, -0x4d

    aput-byte v21, v6, v3

    const/16 v21, 0x16

    const/16 v26, -0x52

    aput-byte v26, v6, v21

    const/16 v21, 0x17

    const/16 v26, -0x5f

    aput-byte v26, v6, v21

    const/16 v21, 0x18

    const/16 v26, -0x75

    aput-byte v26, v6, v21

    aput-byte v11, v6, v9

    const/16 v21, 0x1a

    const/16 v17, 0x7

    aput-byte v17, v6, v21

    const/16 v21, -0x50

    aput-byte v21, v6, v20

    const/16 v21, -0x42

    aput-byte v21, v6, v8

    const/16 v21, -0x34

    const/16 v8, 0x1d

    aput-byte v21, v6, v8

    const/16 v21, 0x1e

    const/16 v27, -0x27

    aput-byte v27, v6, v21

    new-array v8, v10, [B

    const/16 v27, -0x2c

    aput-byte v27, v8, v5

    const/16 v27, 0x50

    aput-byte v27, v8, v16

    const/16 v27, 0x4f

    aput-byte v27, v8, v15

    const/16 v27, -0xf

    aput-byte v27, v8, v11

    const/16 v27, -0x73

    aput-byte v27, v8, v14

    const/16 v27, -0xc

    aput-byte v27, v8, v13

    const/16 v27, -0x13

    const/16 v19, 0x6

    aput-byte v27, v8, v19

    const/16 v27, -0x14

    const/16 v17, 0x7

    aput-byte v27, v8, v17

    invoke-static {v6, v8}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    aput-object v6, v4, v5

    const/16 v6, 0x1f

    new-array v6, v6, [B

    const/16 v8, 0x64

    aput-byte v8, v6, v5

    const/16 v8, -0x64

    aput-byte v8, v6, v16

    const/16 v8, -0x19

    aput-byte v8, v6, v15

    const/16 v8, -0x7a

    aput-byte v8, v6, v11

    const/16 v8, 0x20

    aput-byte v8, v6, v14

    const/16 v8, -0x33

    aput-byte v8, v6, v13

    const/16 v8, 0x48

    const/16 v19, 0x6

    aput-byte v8, v6, v19

    const/16 v8, -0x12

    const/16 v17, 0x7

    aput-byte v8, v6, v17

    const/16 v8, 0x67

    aput-byte v8, v6, v10

    const/16 v8, -0x67

    const/16 v18, 0x9

    aput-byte v8, v6, v18

    const/16 v8, -0x20

    aput-byte v8, v6, v12

    const/16 v8, -0x6f

    aput-byte v8, v6, v22

    const/16 v8, 0x2d

    aput-byte v8, v6, v23

    const/16 v8, -0x21

    aput-byte v8, v6, v7

    const/16 v8, 0x4c

    aput-byte v8, v6, v2

    const/16 v8, 0xf

    const/16 v27, -0x1e

    aput-byte v27, v6, v8

    const/16 v8, 0x10

    const/16 v27, 0x6f

    aput-byte v27, v6, v8

    const/16 v8, 0x11

    const/16 v27, -0x1f

    aput-byte v27, v6, v8

    const/16 v8, -0x7a

    aput-byte v8, v6, v24

    const/16 v8, -0x1f

    aput-byte v8, v6, v25

    const/16 v8, 0x14

    const/16 v27, 0x2d

    aput-byte v27, v6, v8

    const/16 v8, -0x27

    aput-byte v8, v6, v3

    const/16 v8, 0x16

    const/16 v27, 0x4a

    aput-byte v27, v6, v8

    const/16 v8, 0x17

    const/16 v27, -0x4

    aput-byte v27, v6, v8

    const/16 v8, 0x18

    const/16 v27, 0x6f

    aput-byte v27, v6, v8

    const/16 v8, -0x7d

    aput-byte v8, v6, v9

    const/16 v8, 0x1a

    const/16 v27, -0x4

    aput-byte v27, v6, v8

    const/16 v8, -0x68

    aput-byte v8, v6, v20

    const/16 v8, 0x40

    const/16 v26, 0x1c

    aput-byte v8, v6, v26

    const/16 v8, -0x55

    const/16 v21, 0x1d

    aput-byte v8, v6, v21

    const/16 v8, 0x1e

    const/16 v27, 0x3f

    aput-byte v27, v6, v8

    new-array v8, v10, [B

    const/16 v27, 0x30

    aput-byte v27, v8, v5

    const/16 v27, -0x30

    aput-byte v27, v8, v16

    const/16 v27, -0x4c

    aput-byte v27, v8, v15

    const/16 v27, -0x27

    aput-byte v27, v8, v11

    const/16 v27, 0x72

    aput-byte v27, v8, v14

    const/16 v27, -0x62

    aput-byte v27, v8, v13

    const/16 v18, 0x9

    const/16 v19, 0x6

    aput-byte v18, v8, v19

    const/16 v27, -0x4f

    const/16 v17, 0x7

    aput-byte v27, v8, v17

    invoke-static {v6, v8}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    aput-object v6, v4, v16

    const/16 v6, 0x27

    new-array v6, v6, [B

    const/16 v8, -0x5a

    aput-byte v8, v6, v5

    const/16 v8, -0x52

    aput-byte v8, v6, v16

    const/16 v8, 0x72

    aput-byte v8, v6, v15

    const/16 v8, -0x37

    aput-byte v8, v6, v11

    const/16 v8, 0x78

    aput-byte v8, v6, v14

    const/16 v8, -0x80

    aput-byte v8, v6, v13

    const/4 v8, -0x1

    const/16 v19, 0x6

    aput-byte v8, v6, v19

    const/16 v8, -0x2a

    const/16 v17, 0x7

    aput-byte v8, v6, v17

    const/16 v8, -0x49

    aput-byte v8, v6, v10

    const/16 v8, -0x43

    const/16 v18, 0x9

    aput-byte v8, v6, v18

    const/16 v8, 0x64

    aput-byte v8, v6, v12

    const/16 v8, -0x2b

    aput-byte v8, v6, v22

    const/16 v8, 0x79

    aput-byte v8, v6, v23

    const/16 v8, -0x70

    aput-byte v8, v6, v7

    const/4 v8, -0x6

    aput-byte v8, v6, v2

    const/16 v8, 0xf

    const/16 v27, -0x3f

    aput-byte v27, v6, v8

    const/16 v8, 0x10

    const/16 v27, -0x5b

    aput-byte v27, v6, v8

    const/16 v8, 0x11

    const/16 v27, -0x55

    aput-byte v27, v6, v8

    const/16 v8, 0x75

    aput-byte v8, v6, v24

    const/16 v8, -0x22

    aput-byte v8, v6, v25

    const/16 v8, 0x14

    const/16 v27, 0x62

    aput-byte v27, v6, v8

    const/16 v8, -0x7e

    aput-byte v8, v6, v3

    const/16 v8, 0x16

    const/16 v27, -0x2

    aput-byte v27, v6, v8

    const/16 v8, 0x17

    const/16 v27, -0x33

    aput-byte v27, v6, v8

    const/16 v8, 0x18

    const/16 v27, -0x53

    aput-byte v27, v6, v8

    const/16 v8, -0x2d

    aput-byte v8, v6, v9

    const/16 v8, 0x1a

    aput-byte v25, v6, v8

    const/16 v8, -0x52

    aput-byte v8, v6, v20

    const/16 v8, 0x62

    const/16 v26, 0x1c

    aput-byte v8, v6, v26

    const/16 v8, -0x80

    const/16 v21, 0x1d

    aput-byte v8, v6, v21

    const/16 v8, 0x1e

    const/16 v27, -0x7

    aput-byte v27, v6, v8

    const/16 v8, 0x1f

    const/16 v27, -0x23

    aput-byte v27, v6, v8

    const/16 v8, 0x20

    const/16 v27, -0x53

    aput-byte v27, v6, v8

    const/16 v8, 0x21

    const/16 v27, -0x4f

    aput-byte v27, v6, v8

    const/16 v8, 0x22

    const/16 v27, 0x69

    aput-byte v27, v6, v8

    const/16 v8, 0x23

    const/16 v27, -0x29

    aput-byte v27, v6, v8

    const/16 v8, 0x24

    const/16 v27, 0xf

    aput-byte v27, v6, v8

    const/16 v8, 0x25

    const/16 v27, -0xa

    aput-byte v27, v6, v8

    const/16 v8, 0x26

    const/16 v27, -0x73

    aput-byte v27, v6, v8

    new-array v8, v10, [B

    const/16 v27, -0xe

    aput-byte v27, v8, v5

    const/16 v27, -0x1e

    aput-byte v27, v8, v16

    const/16 v27, 0x21

    aput-byte v27, v8, v15

    const/16 v27, -0x6a

    aput-byte v27, v8, v11

    const/16 v27, 0x3d

    aput-byte v27, v8, v14

    const/16 v27, -0x3d

    aput-byte v27, v8, v13

    const/16 v27, -0x45

    const/16 v19, 0x6

    aput-byte v27, v8, v19

    const/16 v27, -0x62

    const/16 v17, 0x7

    aput-byte v27, v8, v17

    invoke-static {v6, v8}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    aput-object v6, v4, v15

    const/16 v6, 0x27

    new-array v6, v6, [B

    const/16 v8, -0x74

    aput-byte v8, v6, v5

    const/16 v8, 0x53

    aput-byte v8, v6, v16

    const/16 v8, -0x72

    aput-byte v8, v6, v15

    const/16 v8, -0x6c

    aput-byte v8, v6, v11

    const/16 v8, 0x31

    aput-byte v8, v6, v14

    const/16 v8, 0x17

    aput-byte v8, v6, v13

    const/16 v8, -0x74

    const/16 v19, 0x6

    aput-byte v8, v6, v19

    const/16 v8, -0x59

    const/16 v17, 0x7

    aput-byte v8, v6, v17

    const/16 v8, -0x63

    aput-byte v8, v6, v10

    const/16 v8, 0x40

    const/16 v18, 0x9

    aput-byte v8, v6, v18

    const/16 v8, -0x68

    aput-byte v8, v6, v12

    const/16 v8, -0x78

    aput-byte v8, v6, v22

    const/16 v8, 0x30

    aput-byte v8, v6, v23

    const/4 v8, 0x7

    aput-byte v8, v6, v7

    const/16 v8, -0x77

    aput-byte v8, v6, v2

    const/16 v8, 0xf

    const/16 v27, -0x50

    aput-byte v27, v6, v8

    const/16 v8, 0x10

    const/16 v27, -0x71

    aput-byte v27, v6, v8

    const/16 v8, 0x11

    const/16 v27, 0x56

    aput-byte v27, v6, v8

    const/16 v8, -0x77

    aput-byte v8, v6, v24

    const/16 v8, -0x7d

    aput-byte v8, v6, v25

    const/16 v8, 0x14

    const/16 v27, 0x2b

    aput-byte v27, v6, v8

    aput-byte v3, v6, v3

    const/16 v8, 0x16

    const/16 v27, -0x73

    aput-byte v27, v6, v8

    const/16 v8, 0x17

    const/16 v27, -0x44

    aput-byte v27, v6, v8

    const/16 v8, 0x18

    const/16 v27, -0x79

    aput-byte v27, v6, v8

    const/16 v8, 0x2e

    aput-byte v8, v6, v9

    const/16 v8, 0x1a

    const/16 v27, -0x11

    aput-byte v27, v6, v8

    const/16 v8, -0xd

    aput-byte v8, v6, v20

    const/16 v8, 0x2b

    const/16 v26, 0x1c

    aput-byte v8, v6, v26

    const/16 v8, 0x1d

    aput-byte v25, v6, v8

    const/16 v8, 0x1e

    const/16 v27, -0x75

    aput-byte v27, v6, v8

    const/16 v8, 0x1f

    const/16 v27, -0x5e

    aput-byte v27, v6, v8

    const/16 v8, 0x20

    const/16 v27, -0x79

    aput-byte v27, v6, v8

    const/16 v8, 0x21

    const/16 v27, 0x4c

    aput-byte v27, v6, v8

    const/16 v8, 0x22

    const/16 v27, -0x6b

    aput-byte v27, v6, v8

    const/16 v8, 0x23

    const/16 v27, -0x76

    aput-byte v27, v6, v8

    const/16 v8, 0x24

    const/16 v27, 0x46

    aput-byte v27, v6, v8

    const/16 v8, 0x25

    const/16 v27, 0x61

    aput-byte v27, v6, v8

    const/16 v8, 0x26

    const/16 v27, -0x2

    aput-byte v27, v6, v8

    new-array v8, v10, [B

    const/16 v27, -0x28

    aput-byte v27, v8, v5

    const/16 v27, 0x1f

    aput-byte v27, v8, v16

    const/16 v27, -0x23

    aput-byte v27, v8, v15

    const/16 v27, -0x35

    aput-byte v27, v8, v11

    const/16 v27, 0x74

    aput-byte v27, v8, v14

    const/16 v27, 0x54

    aput-byte v27, v8, v13

    const/16 v27, -0x38

    const/16 v19, 0x6

    aput-byte v27, v8, v19

    const/16 v27, -0x11

    const/16 v17, 0x7

    aput-byte v27, v8, v17

    invoke-static {v6, v8}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    aput-object v6, v4, v11

    const/16 v6, 0x27

    new-array v6, v6, [B

    const/16 v8, 0x67

    aput-byte v8, v6, v5

    const/16 v8, -0xd

    aput-byte v8, v6, v16

    const/16 v8, -0x9

    aput-byte v8, v6, v15

    const/16 v8, 0x9

    aput-byte v8, v6, v11

    const/16 v8, -0x28

    aput-byte v8, v6, v14

    const/16 v8, -0x74

    aput-byte v8, v6, v13

    const/16 v8, -0x23

    const/16 v19, 0x6

    aput-byte v8, v6, v19

    const/16 v8, -0x16

    const/16 v17, 0x7

    aput-byte v8, v6, v17

    const/16 v8, 0x76

    aput-byte v8, v6, v10

    const/16 v8, -0x20

    const/16 v18, 0x9

    aput-byte v8, v6, v18

    const/16 v8, -0x1f

    aput-byte v8, v6, v12

    aput-byte v3, v6, v22

    const/16 v8, -0x27

    aput-byte v8, v6, v23

    const/16 v8, -0x64

    aput-byte v8, v6, v7

    const/16 v8, -0x28

    aput-byte v8, v6, v2

    const/16 v8, 0xf

    const/16 v27, -0x3

    aput-byte v27, v6, v8

    const/16 v8, 0x10

    const/16 v27, 0x64

    aput-byte v27, v6, v8

    const/16 v8, 0x11

    const/16 v27, -0xa

    aput-byte v27, v6, v8

    const/16 v8, -0x10

    aput-byte v8, v6, v24

    const/16 v8, 0x1e

    aput-byte v8, v6, v25

    const/16 v8, 0x14

    const/16 v27, -0x3e

    aput-byte v27, v6, v8

    const/16 v8, -0x72

    aput-byte v8, v6, v3

    const/16 v8, 0x16

    const/16 v27, -0x24

    aput-byte v27, v6, v8

    const/16 v8, 0x17

    const/16 v27, -0xf

    aput-byte v27, v6, v8

    const/16 v8, 0x18

    const/16 v27, 0x6c

    aput-byte v27, v6, v8

    const/16 v8, -0x73

    aput-byte v8, v6, v9

    const/16 v8, 0x1a

    const/16 v27, -0x6f

    aput-byte v27, v6, v8

    const/16 v8, 0x60

    aput-byte v8, v6, v20

    const/16 v8, -0x3e

    const/16 v26, 0x1c

    aput-byte v8, v6, v26

    const/16 v8, -0x78

    const/16 v21, 0x1d

    aput-byte v8, v6, v21

    const/16 v8, 0x1e

    const/16 v27, -0x26

    aput-byte v27, v6, v8

    const/16 v8, 0x1f

    const/16 v27, -0x11

    aput-byte v27, v6, v8

    const/16 v8, 0x20

    const/16 v27, 0x6c

    aput-byte v27, v6, v8

    const/16 v8, 0x21

    const/16 v27, -0x14

    aput-byte v27, v6, v8

    const/16 v8, 0x22

    const/16 v27, -0x14

    aput-byte v27, v6, v8

    const/16 v8, 0x23

    const/16 v27, 0x17

    aput-byte v27, v6, v8

    const/16 v8, 0x24

    const/16 v27, -0x52

    aput-byte v27, v6, v8

    const/16 v8, 0x25

    const/16 v27, -0x9

    aput-byte v27, v6, v8

    const/16 v8, 0x26

    const/16 v27, -0x53

    aput-byte v27, v6, v8

    new-array v8, v10, [B

    const/16 v27, 0x33

    aput-byte v27, v8, v5

    const/16 v27, -0x41

    aput-byte v27, v8, v16

    const/16 v27, -0x5c

    aput-byte v27, v8, v15

    const/16 v27, 0x56

    aput-byte v27, v8, v11

    const/16 v27, -0x63

    aput-byte v27, v8, v14

    const/16 v27, -0x31

    aput-byte v27, v8, v13

    const/16 v27, -0x67

    const/16 v19, 0x6

    aput-byte v27, v8, v19

    const/16 v27, -0x5e

    const/16 v17, 0x7

    aput-byte v27, v8, v17

    invoke-static {v6, v8}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    aput-object v6, v4, v14

    const/16 v6, 0x25

    new-array v6, v6, [B

    const/16 v8, -0x1f

    aput-byte v8, v6, v5

    const/16 v8, -0x79

    aput-byte v8, v6, v16

    const/16 v8, -0x25

    aput-byte v8, v6, v15

    const/16 v8, 0x4b

    aput-byte v8, v6, v11

    const/16 v8, 0x40

    aput-byte v8, v6, v14

    const/16 v8, 0x4b

    aput-byte v8, v6, v13

    const/4 v8, 0x6

    aput-byte v10, v6, v8

    const/16 v8, -0x16

    const/16 v17, 0x7

    aput-byte v8, v6, v17

    const/16 v8, -0x10

    aput-byte v8, v6, v10

    const/16 v8, -0x6c

    const/16 v18, 0x9

    aput-byte v8, v6, v18

    const/16 v8, -0x26

    aput-byte v8, v6, v12

    const/16 v8, 0x47

    aput-byte v8, v6, v22

    const/16 v8, 0x44

    aput-byte v8, v6, v23

    const/16 v8, 0x57

    aput-byte v8, v6, v7

    aput-byte v20, v6, v2

    const/16 v8, 0xf

    const/16 v27, -0x15

    aput-byte v27, v6, v8

    const/16 v8, 0x10

    const/16 v27, -0x1f

    aput-byte v27, v6, v8

    const/16 v8, 0x11

    const/16 v27, -0x7d

    aput-byte v27, v6, v8

    const/16 v8, -0x29

    aput-byte v8, v6, v24

    const/16 v8, 0x55

    aput-byte v8, v6, v25

    const/16 v8, 0x14

    const/16 v27, 0x40

    aput-byte v27, v6, v8

    const/16 v8, 0x5b

    aput-byte v8, v6, v3

    const/16 v8, 0x16

    aput-byte v25, v6, v8

    const/16 v8, 0x17

    const/16 v27, -0x6d

    aput-byte v27, v6, v8

    const/16 v8, 0x18

    const/16 v27, -0x79

    aput-byte v27, v6, v8

    const/16 v8, -0xd

    aput-byte v8, v6, v9

    const/16 v8, 0x1a

    const/16 v27, -0x29

    aput-byte v27, v6, v8

    const/16 v8, 0x57

    aput-byte v8, v6, v20

    const/16 v8, 0x47

    const/16 v26, 0x1c

    aput-byte v8, v6, v26

    const/16 v8, 0x4b

    const/16 v21, 0x1d

    aput-byte v8, v6, v21

    const/16 v8, 0x1e

    aput-byte v25, v6, v8

    const/16 v8, 0x1f

    const/16 v27, -0xf

    aput-byte v27, v6, v8

    const/16 v8, 0x20

    const/16 v27, -0x3

    aput-byte v27, v6, v8

    const/16 v8, 0x21

    const/16 v27, -0x76

    aput-byte v27, v6, v8

    const/16 v8, 0x22

    const/16 v27, -0x46

    aput-byte v27, v6, v8

    const/16 v8, 0x23

    const/16 v27, 0x21

    aput-byte v27, v6, v8

    const/16 v8, 0x24

    const/16 v27, 0x33

    aput-byte v27, v6, v8

    new-array v8, v10, [B

    const/16 v27, -0x4b

    aput-byte v27, v8, v5

    const/16 v27, -0x35

    aput-byte v27, v8, v16

    const/16 v27, -0x78

    aput-byte v27, v8, v15

    const/16 v27, 0x14

    aput-byte v27, v8, v11

    aput-byte v13, v8, v14

    aput-byte v10, v8, v13

    const/16 v27, 0x4c

    const/16 v19, 0x6

    aput-byte v27, v8, v19

    const/16 v27, -0x5e

    const/16 v17, 0x7

    aput-byte v27, v8, v17

    invoke-static {v6, v8}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    aput-object v6, v4, v13

    const/16 v6, 0x25

    new-array v6, v6, [B

    const/16 v8, -0x1d

    aput-byte v8, v6, v5

    const/16 v8, -0x3d

    aput-byte v8, v6, v16

    const/16 v8, -0x4d

    aput-byte v8, v6, v15

    const/16 v8, -0x67

    aput-byte v8, v6, v11

    const/16 v8, -0x35

    aput-byte v8, v6, v14

    const/16 v8, -0x7b

    aput-byte v8, v6, v13

    const/16 v8, 0x4c

    const/16 v19, 0x6

    aput-byte v8, v6, v19

    const/16 v8, -0x5b

    const/16 v17, 0x7

    aput-byte v8, v6, v17

    const/16 v8, -0xe

    aput-byte v8, v6, v10

    const/16 v8, -0x30

    const/16 v18, 0x9

    aput-byte v8, v6, v18

    const/16 v8, -0x4e

    aput-byte v8, v6, v12

    const/16 v8, -0x6b

    aput-byte v8, v6, v22

    const/16 v8, -0x31

    aput-byte v8, v6, v23

    const/16 v8, -0x67

    aput-byte v8, v6, v7

    const/16 v8, 0x53

    aput-byte v8, v6, v2

    const/16 v8, 0xf

    const/16 v27, -0x58

    aput-byte v27, v6, v8

    const/16 v8, 0x10

    const/16 v27, -0x1d

    aput-byte v27, v6, v8

    const/16 v8, 0x11

    const/16 v27, -0x39

    aput-byte v27, v6, v8

    const/16 v8, -0x41

    aput-byte v8, v6, v24

    const/16 v8, -0x79

    aput-byte v8, v6, v25

    const/16 v8, 0x14

    const/16 v27, -0x35

    aput-byte v27, v6, v8

    const/16 v8, -0x6b

    aput-byte v8, v6, v3

    const/16 v8, 0x16

    const/16 v27, 0x5b

    aput-byte v27, v6, v8

    const/16 v8, 0x17

    const/16 v27, -0x30

    aput-byte v27, v6, v8

    const/16 v8, 0x18

    const/16 v27, -0x7b

    aput-byte v27, v6, v8

    const/16 v8, -0x49

    aput-byte v8, v6, v9

    const/16 v8, 0x1a

    const/16 v27, -0x41

    aput-byte v27, v6, v8

    const/16 v8, -0x7f

    aput-byte v8, v6, v20

    const/16 v8, -0x33

    const/16 v26, 0x1c

    aput-byte v8, v6, v26

    const/16 v8, -0x75

    const/16 v21, 0x1d

    aput-byte v8, v6, v21

    const/16 v8, 0x1e

    const/16 v27, 0x5b

    aput-byte v27, v6, v8

    const/16 v8, 0x1f

    const/16 v27, -0x4e

    aput-byte v27, v6, v8

    const/16 v8, 0x20

    const/16 v27, -0x1

    aput-byte v27, v6, v8

    const/16 v8, 0x21

    const/16 v27, -0x32

    aput-byte v27, v6, v8

    const/16 v8, 0x22

    const/16 v27, -0x2e

    aput-byte v27, v6, v8

    const/16 v8, 0x23

    const/16 v27, -0xd

    aput-byte v27, v6, v8

    const/16 v8, 0x24

    const/16 v27, -0x48

    aput-byte v27, v6, v8

    new-array v8, v10, [B

    const/16 v27, -0x49

    aput-byte v27, v8, v5

    const/16 v27, -0x71

    aput-byte v27, v8, v16

    const/16 v27, -0x20

    aput-byte v27, v8, v15

    const/16 v27, -0x3a

    aput-byte v27, v8, v11

    const/16 v27, -0x72

    aput-byte v27, v8, v14

    const/16 v27, -0x3a

    aput-byte v27, v8, v13

    const/16 v19, 0x6

    aput-byte v14, v8, v19

    const/16 v27, -0x1f

    const/16 v17, 0x7

    aput-byte v27, v8, v17

    invoke-static {v6, v8}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    aput-object v6, v4, v19

    const/16 v6, 0x1d

    new-array v8, v6, [B

    const/16 v6, -0xb

    aput-byte v6, v8, v5

    const/16 v6, -0x66

    aput-byte v6, v8, v16

    aput-byte v22, v8, v15

    const/16 v6, 0x67

    aput-byte v6, v8, v11

    const/16 v6, -0x3f

    aput-byte v6, v8, v14

    const/4 v6, -0x3

    aput-byte v6, v8, v13

    const/16 v6, 0x62

    const/16 v19, 0x6

    aput-byte v6, v8, v19

    const/16 v6, -0x69

    const/16 v17, 0x7

    aput-byte v6, v8, v17

    const/16 v6, -0xa

    aput-byte v6, v8, v10

    const/16 v6, -0x61

    const/16 v18, 0x9

    aput-byte v6, v8, v18

    aput-byte v23, v8, v12

    const/16 v6, 0x70

    aput-byte v6, v8, v22

    const/16 v6, -0x34

    aput-byte v6, v8, v23

    const/16 v6, -0x63

    aput-byte v6, v8, v7

    const/16 v6, 0x67

    aput-byte v6, v8, v2

    const/16 v6, 0xf

    const/16 v27, -0x73

    aput-byte v27, v8, v6

    const/16 v6, 0x10

    const/16 v27, -0xe

    aput-byte v27, v8, v6

    const/16 v6, 0x11

    const/16 v27, -0x77

    aput-byte v27, v8, v6

    const/16 v6, 0x1d

    aput-byte v6, v8, v24

    const/16 v6, 0x7c

    aput-byte v6, v8, v25

    const/16 v6, 0x14

    const/16 v27, -0x2a

    aput-byte v27, v8, v6

    const/16 v6, -0xf

    aput-byte v6, v8, v3

    const/16 v6, 0x16

    const/16 v27, 0x60

    aput-byte v27, v8, v6

    const/16 v6, 0x17

    const/16 v27, -0x76

    aput-byte v27, v8, v6

    const/16 v6, 0x18

    const/16 v27, -0x1e

    aput-byte v27, v8, v6

    const/16 v6, -0x77

    aput-byte v6, v8, v9

    const/16 v6, 0x1a

    aput-byte v22, v8, v6

    const/16 v6, 0x70

    aput-byte v6, v8, v20

    const/16 v6, -0x2e

    const/16 v26, 0x1c

    aput-byte v6, v8, v26

    new-array v6, v10, [B

    const/16 v27, -0x5f

    aput-byte v27, v6, v5

    const/16 v27, -0x2a

    aput-byte v27, v6, v16

    const/16 v27, 0x58

    aput-byte v27, v6, v15

    const/16 v27, 0x38

    aput-byte v27, v6, v11

    const/16 v27, -0x6d

    aput-byte v27, v6, v14

    const/16 v27, -0x52

    aput-byte v27, v6, v13

    const/16 v27, 0x23

    const/16 v19, 0x6

    aput-byte v27, v6, v19

    const/16 v27, -0x38

    const/16 v17, 0x7

    aput-byte v27, v6, v17

    invoke-static {v8, v6}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    aput-object v6, v4, v17

    const/16 v6, 0x1c

    new-array v8, v6, [B

    aput-byte v20, v8, v5

    const/16 v6, -0x1c

    aput-byte v6, v8, v16

    const/16 v6, 0x25

    aput-byte v6, v8, v15

    const/16 v6, -0x48

    aput-byte v6, v8, v11

    const/16 v6, -0x80

    aput-byte v6, v8, v14

    const/16 v6, -0x6d

    aput-byte v6, v8, v13

    const/16 v6, -0x7f

    const/16 v19, 0x6

    aput-byte v6, v8, v19

    const/16 v6, -0x6f

    const/16 v17, 0x7

    aput-byte v6, v8, v17

    const/16 v6, 0x18

    aput-byte v6, v8, v10

    const/16 v6, -0x1f

    const/16 v18, 0x9

    aput-byte v6, v8, v18

    const/16 v6, 0x22

    aput-byte v6, v8, v12

    const/16 v6, -0x51

    aput-byte v6, v8, v22

    const/16 v6, -0x73

    aput-byte v6, v8, v23

    const/16 v6, -0x7f

    aput-byte v6, v8, v7

    const/16 v6, -0x7b

    aput-byte v6, v8, v2

    const/16 v6, 0xf

    const/16 v27, -0x63

    aput-byte v27, v8, v6

    const/16 v6, 0x10

    const/16 v27, 0x10

    aput-byte v27, v8, v6

    const/16 v6, 0x11

    const/16 v27, -0x67

    aput-byte v27, v8, v6

    const/16 v6, 0x44

    aput-byte v6, v8, v24

    const/16 v6, -0x21

    aput-byte v6, v8, v25

    const/16 v6, 0x14

    const/16 v27, -0x73

    aput-byte v27, v8, v6

    const/16 v6, -0x7d

    aput-byte v6, v8, v3

    const/16 v6, 0x16

    const/16 v27, -0x7e

    aput-byte v27, v8, v6

    const/16 v6, 0x17

    const/16 v27, -0x73

    aput-byte v27, v8, v6

    const/16 v6, 0x18

    const/16 v27, 0x10

    aput-byte v27, v8, v6

    const/4 v6, -0x5

    aput-byte v6, v8, v9

    const/16 v6, 0x1a

    const/16 v27, 0x3e

    aput-byte v27, v8, v6

    const/16 v6, -0x5a

    aput-byte v6, v8, v20

    new-array v6, v10, [B

    const/16 v27, 0x4f

    aput-byte v27, v6, v5

    const/16 v27, -0x58

    aput-byte v27, v6, v16

    const/16 v27, 0x76

    aput-byte v27, v6, v15

    const/16 v27, -0x19

    aput-byte v27, v6, v11

    const/16 v27, -0x2e

    aput-byte v27, v6, v14

    const/16 v27, -0x40

    aput-byte v27, v6, v13

    const/16 v27, -0x40

    const/16 v19, 0x6

    aput-byte v27, v6, v19

    const/16 v27, -0x32

    const/16 v17, 0x7

    aput-byte v27, v6, v17

    invoke-static {v8, v6}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    aput-object v6, v4, v10

    const/16 v6, 0x1c

    new-array v8, v6, [B

    const/16 v6, -0x7c

    aput-byte v6, v8, v5

    const/16 v6, 0x6c

    aput-byte v6, v8, v16

    const/16 v6, -0x47

    aput-byte v6, v8, v15

    const/16 v6, 0x7c

    aput-byte v6, v8, v11

    const/16 v6, 0x27

    aput-byte v6, v8, v14

    const/16 v6, -0x55

    aput-byte v6, v8, v13

    const/4 v6, 0x6

    aput-byte v13, v8, v6

    const/4 v6, 0x7

    aput-byte v2, v8, v6

    const/16 v6, -0x79

    aput-byte v6, v8, v10

    const/16 v6, 0x69

    const/16 v18, 0x9

    aput-byte v6, v8, v18

    const/16 v6, -0x42

    aput-byte v6, v8, v12

    const/16 v6, 0x6b

    aput-byte v6, v8, v22

    const/16 v6, 0x2a

    aput-byte v6, v8, v23

    const/16 v6, -0x47

    aput-byte v6, v8, v7

    aput-byte v16, v8, v2

    const/16 v6, 0xf

    aput-byte v15, v8, v6

    const/16 v6, 0x10

    const/16 v27, -0x71

    aput-byte v27, v8, v6

    const/16 v6, 0x11

    aput-byte v24, v8, v6

    const/16 v6, -0x21

    aput-byte v6, v8, v24

    aput-byte v3, v8, v25

    const/16 v6, 0x14

    const/16 v27, 0x2a

    aput-byte v27, v8, v6

    const/16 v6, -0x45

    aput-byte v6, v8, v3

    const/16 v6, 0x16

    const/16 v19, 0x6

    aput-byte v19, v8, v6

    const/16 v6, 0x17

    aput-byte v24, v8, v6

    const/16 v6, 0x18

    const/16 v27, -0x71

    aput-byte v27, v8, v6

    const/16 v6, 0x73

    aput-byte v6, v8, v9

    const/16 v6, 0x1a

    const/16 v27, -0x5e

    aput-byte v27, v8, v6

    const/16 v6, 0x62

    aput-byte v6, v8, v20

    new-array v6, v10, [B

    const/16 v27, -0x30

    aput-byte v27, v6, v5

    const/16 v27, 0x20

    aput-byte v27, v6, v16

    const/16 v27, -0x16

    aput-byte v27, v6, v15

    const/16 v27, 0x23

    aput-byte v27, v6, v11

    const/16 v27, 0x75

    aput-byte v27, v6, v14

    const/16 v27, -0x8

    aput-byte v27, v6, v13

    const/16 v27, 0x44

    const/16 v19, 0x6

    aput-byte v27, v6, v19

    const/16 v27, 0x51

    const/16 v17, 0x7

    aput-byte v27, v6, v17

    invoke-static {v8, v6}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    const/16 v8, 0x9

    aput-object v6, v4, v8

    const/16 v6, 0x25

    new-array v6, v6, [B

    const/16 v8, 0x50

    aput-byte v8, v6, v5

    const/16 v8, -0x55

    aput-byte v8, v6, v16

    const/16 v8, 0x68

    aput-byte v8, v6, v15

    const/4 v8, -0x3

    aput-byte v8, v6, v11

    const/16 v8, -0x5a

    aput-byte v8, v6, v14

    aput-byte v15, v6, v13

    const/16 v8, -0x79

    const/16 v19, 0x6

    aput-byte v8, v6, v19

    const/16 v8, 0x6d

    const/16 v17, 0x7

    aput-byte v8, v6, v17

    const/16 v8, 0x41

    aput-byte v8, v6, v10

    const/16 v8, -0x48

    const/16 v18, 0x9

    aput-byte v8, v6, v18

    const/16 v8, 0x7e

    aput-byte v8, v6, v12

    const/16 v8, -0x1f

    aput-byte v8, v6, v22

    const/16 v8, -0x59

    aput-byte v8, v6, v23

    aput-byte v24, v6, v7

    const/16 v8, -0x7e

    aput-byte v8, v6, v2

    const/16 v8, 0xf

    const/16 v27, 0x7a

    aput-byte v27, v6, v8

    const/16 v8, 0x10

    const/16 v27, 0x53

    aput-byte v27, v6, v8

    const/16 v8, 0x11

    const/16 v27, -0x52

    aput-byte v27, v6, v8

    const/16 v8, 0x6f

    aput-byte v8, v6, v24

    const/16 v8, -0x16

    aput-byte v8, v6, v25

    const/16 v8, 0x14

    const/16 v27, -0x44

    aput-byte v27, v6, v8

    const/16 v8, 0x72

    aput-byte v8, v6, v3

    const/16 v8, 0x16

    const/16 v27, -0x79

    aput-byte v27, v6, v8

    const/16 v8, 0x17

    const/16 v27, 0x60

    aput-byte v27, v6, v8

    const/16 v8, 0x18

    const/16 v27, 0x57

    aput-byte v27, v6, v8

    const/16 v8, -0x48

    aput-byte v8, v6, v9

    const/16 v8, 0x1a

    const/16 v27, 0x7e

    aput-byte v27, v6, v8

    const/16 v8, -0x1a

    aput-byte v8, v6, v20

    const/16 v8, -0x5a

    const/16 v26, 0x1c

    aput-byte v8, v6, v26

    const/16 v8, 0x1e

    const/16 v21, 0x1d

    aput-byte v8, v6, v21

    const/16 v8, 0x1e

    const/16 v27, -0x80

    aput-byte v27, v6, v8

    const/16 v8, 0x1f

    const/16 v27, 0x67

    aput-byte v27, v6, v8

    const/16 v8, 0x20

    const/16 v27, 0x47

    aput-byte v27, v6, v8

    const/16 v8, 0x21

    const/16 v27, -0x48

    aput-byte v27, v6, v8

    const/16 v8, 0x22

    const/16 v27, 0x68

    aput-byte v27, v6, v8

    const/16 v8, 0x23

    const/16 v27, -0x16

    aput-byte v27, v6, v8

    const/16 v8, 0x24

    const/16 v27, -0x5e

    aput-byte v27, v6, v8

    new-array v8, v10, [B

    aput-byte v14, v8, v5

    const/16 v27, -0x19

    aput-byte v27, v8, v16

    const/16 v27, 0x3b

    aput-byte v27, v8, v15

    const/16 v27, -0x5e

    aput-byte v27, v8, v11

    const/16 v27, -0x1d

    aput-byte v27, v8, v14

    const/16 v27, 0x41

    aput-byte v27, v8, v13

    const/16 v27, -0x3d

    const/16 v19, 0x6

    aput-byte v27, v8, v19

    const/16 v27, 0x25

    const/16 v17, 0x7

    aput-byte v27, v8, v17

    invoke-static {v6, v8}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    aput-object v6, v4, v12

    const/16 v6, 0x24

    new-array v6, v6, [B

    const/16 v8, -0x3a

    aput-byte v8, v6, v5

    const/16 v8, 0x79

    aput-byte v8, v6, v16

    const/16 v8, 0x79

    aput-byte v8, v6, v15

    const/16 v8, 0x3a

    aput-byte v8, v6, v11

    const/16 v8, 0x1c

    aput-byte v8, v6, v14

    const/16 v8, -0x5b

    aput-byte v8, v6, v13

    const/16 v8, -0x59

    const/16 v19, 0x6

    aput-byte v8, v6, v19

    const/16 v8, -0x46

    const/16 v17, 0x7

    aput-byte v8, v6, v17

    const/16 v8, -0x29

    aput-byte v8, v6, v10

    const/16 v8, 0x6a

    const/16 v18, 0x9

    aput-byte v8, v6, v18

    const/16 v8, 0x6f

    aput-byte v8, v6, v12

    const/16 v8, 0x26

    aput-byte v8, v6, v22

    const/16 v8, 0x1d

    aput-byte v8, v6, v23

    const/16 v8, -0x4b

    aput-byte v8, v6, v7

    const/16 v8, -0x5e

    aput-byte v8, v6, v2

    const/16 v8, 0xf

    const/16 v27, -0x53

    aput-byte v27, v6, v8

    const/16 v8, 0x10

    const/16 v27, -0x3b

    aput-byte v27, v6, v8

    const/16 v8, 0x11

    const/16 v27, 0x7c

    aput-byte v27, v6, v8

    const/16 v8, 0x7e

    aput-byte v8, v6, v24

    const/16 v8, 0x2d

    aput-byte v8, v6, v25

    const/16 v8, 0x14

    const/16 v19, 0x6

    aput-byte v19, v6, v8

    const/16 v8, -0x59

    aput-byte v8, v6, v3

    const/16 v8, 0x16

    const/16 v27, -0x5a

    aput-byte v27, v6, v8

    const/16 v8, 0x17

    const/16 v27, -0x5f

    aput-byte v27, v6, v8

    const/16 v8, 0x18

    const/16 v27, -0x33

    aput-byte v27, v6, v8

    aput-byte v14, v6, v9

    const/16 v8, 0x1a

    const/16 v27, 0x18

    aput-byte v27, v6, v8

    const/16 v8, 0x5d

    aput-byte v8, v6, v20

    const/16 v8, 0x1c

    const/16 v19, 0x6

    aput-byte v19, v6, v8

    const/16 v8, -0x5b

    const/16 v21, 0x1d

    aput-byte v8, v6, v21

    const/16 v8, 0x1e

    const/16 v27, -0x5f

    aput-byte v27, v6, v8

    const/16 v8, 0x1f

    const/16 v27, -0x4f

    aput-byte v27, v6, v8

    const/16 v8, 0x20

    const/16 v27, -0x33

    aput-byte v27, v6, v8

    const/16 v8, 0x21

    const/16 v27, 0x66

    aput-byte v27, v6, v8

    const/16 v8, 0x22

    const/16 v27, 0x62

    aput-byte v27, v6, v8

    const/16 v8, 0x23

    const/16 v27, 0x24

    aput-byte v27, v6, v8

    new-array v8, v10, [B

    const/16 v27, -0x6e

    aput-byte v27, v8, v5

    const/16 v27, 0x35

    aput-byte v27, v8, v16

    const/16 v27, 0x2a

    aput-byte v27, v8, v15

    const/16 v27, 0x65

    aput-byte v27, v8, v11

    const/16 v27, 0x59

    aput-byte v27, v8, v14

    const/16 v27, -0x1a

    aput-byte v27, v8, v13

    const/16 v27, -0x1d

    const/16 v19, 0x6

    aput-byte v27, v8, v19

    const/16 v27, -0xe

    const/16 v17, 0x7

    aput-byte v27, v8, v17

    invoke-static {v6, v8}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    aput-object v6, v4, v22

    const/16 v6, 0x23

    new-array v6, v6, [B

    const/16 v8, 0x3e

    aput-byte v8, v6, v5

    aput-byte v9, v6, v16

    const/16 v8, 0x31

    aput-byte v8, v6, v15

    const/16 v8, 0x69

    aput-byte v8, v6, v11

    const/4 v8, -0x7

    aput-byte v8, v6, v14

    const/16 v8, -0x33

    aput-byte v8, v6, v13

    const/16 v8, 0x3d

    const/16 v19, 0x6

    aput-byte v8, v6, v19

    const/16 v8, 0x2d

    const/16 v17, 0x7

    aput-byte v8, v6, v17

    const/16 v8, 0x2f

    aput-byte v8, v6, v10

    const/16 v8, 0x9

    aput-byte v12, v6, v8

    const/16 v8, 0x30

    aput-byte v8, v6, v12

    const/16 v8, 0x65

    aput-byte v8, v6, v22

    const/4 v8, -0x3

    aput-byte v8, v6, v23

    const/16 v8, -0x2f

    aput-byte v8, v6, v7

    const/16 v8, 0x2e

    aput-byte v8, v6, v2

    const/16 v8, 0xf

    const/16 v27, 0x2c

    aput-byte v27, v6, v8

    const/16 v8, 0x10

    const/16 v27, 0x3e

    aput-byte v27, v6, v8

    const/16 v8, 0x11

    const/16 v21, 0x1d

    aput-byte v21, v6, v8

    const/16 v8, 0x3d

    aput-byte v8, v6, v24

    aput-byte v13, v6, v25

    const/16 v8, 0x14

    const/16 v27, -0x8

    aput-byte v27, v6, v8

    const/16 v8, -0x35

    aput-byte v8, v6, v3

    const/16 v8, 0x16

    const/16 v27, 0x2a

    aput-byte v27, v6, v8

    const/16 v8, 0x17

    const/16 v27, 0x3a

    aput-byte v27, v6, v8

    const/16 v8, 0x18

    const/16 v27, 0x2f

    aput-byte v27, v6, v8

    const/16 v8, 0x11

    aput-byte v8, v6, v9

    const/16 v8, 0x1a

    const/16 v27, 0x27

    aput-byte v27, v6, v8

    const/16 v8, 0x69

    aput-byte v8, v6, v20

    const/4 v8, -0x1

    const/16 v26, 0x1c

    aput-byte v8, v6, v26

    const/16 v8, -0x34

    const/16 v21, 0x1d

    aput-byte v8, v6, v21

    const/16 v8, 0x1e

    const/16 v27, 0x3a

    aput-byte v27, v6, v8

    const/16 v8, 0x1f

    const/16 v27, 0x3a

    aput-byte v27, v6, v8

    const/16 v8, 0x20

    const/16 v27, 0x39

    aput-byte v27, v6, v8

    const/16 v8, 0x21

    const/16 v21, 0x1d

    aput-byte v21, v6, v8

    const/16 v8, 0x22

    const/16 v27, 0x23

    aput-byte v27, v6, v8

    new-array v8, v10, [B

    const/16 v27, 0x6a

    aput-byte v27, v8, v5

    const/16 v27, 0x55

    aput-byte v27, v8, v16

    const/16 v27, 0x62

    aput-byte v27, v8, v15

    const/16 v27, 0x36

    aput-byte v27, v8, v11

    const/16 v27, -0x44

    aput-byte v27, v8, v14

    const/16 v27, -0x72

    aput-byte v27, v8, v13

    const/16 v27, 0x79

    const/16 v19, 0x6

    aput-byte v27, v8, v19

    const/16 v27, 0x65

    const/16 v17, 0x7

    aput-byte v27, v8, v17

    invoke-static {v6, v8}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v6

    aput-object v6, v4, v23

    const/16 v6, 0x22

    new-array v6, v6, [B

    const/16 v8, -0x58

    aput-byte v8, v6, v5

    const/16 v8, -0x5d

    aput-byte v8, v6, v16

    const/16 v8, -0x62

    aput-byte v8, v6, v15

    aput-byte v16, v6, v11

    const/16 v8, -0x1a

    aput-byte v8, v6, v14

    const/16 v8, 0x2a

    aput-byte v8, v6, v13

    const/16 v8, -0x5f

    const/16 v19, 0x6

    aput-byte v8, v6, v19

    const/16 v8, -0x23

    const/16 v17, 0x7

    aput-byte v8, v6, v17

    const/16 v8, -0x47

    aput-byte v8, v6, v10

    const/16 v8, -0x50

    const/16 v18, 0x9

    aput-byte v8, v6, v18

    const/16 v8, -0x61

    aput-byte v8, v6, v12

    aput-byte v7, v6, v22

    const/16 v8, -0x1e

    aput-byte v8, v6, v23

    const/16 v8, 0x36

    aput-byte v8, v6, v7

    const/16 v8, -0x4e

    aput-byte v8, v6, v2

    const/16 v2, 0xf

    const/16 v8, -0x24

    aput-byte v8, v6, v2

    const/16 v2, 0x10

    const/16 v8, -0x58

    aput-byte v8, v6, v2

    const/16 v2, 0x11

    const/16 v8, -0x59

    aput-byte v8, v6, v2

    const/16 v2, -0x6e

    aput-byte v2, v6, v24

    const/16 v2, 0x1f

    aput-byte v2, v6, v25

    const/16 v2, 0x14

    const/16 v8, -0x1a

    aput-byte v8, v6, v2

    const/16 v2, 0x3a

    aput-byte v2, v6, v3

    const/16 v2, 0x16

    const/16 v3, -0x46

    aput-byte v3, v6, v2

    const/16 v2, 0x17

    const/16 v3, -0x5c

    aput-byte v3, v6, v2

    const/16 v2, 0x18

    const/16 v3, -0x32

    aput-byte v3, v6, v2

    const/16 v2, -0x29

    aput-byte v2, v6, v9

    const/16 v2, 0x1a

    const/16 v3, -0x6e

    aput-byte v3, v6, v2

    const/16 v2, 0x1d

    aput-byte v2, v6, v20

    const/16 v3, -0x1f

    const/16 v8, 0x1c

    aput-byte v3, v6, v8

    const/16 v3, 0x2a

    aput-byte v3, v6, v2

    const/16 v2, 0x1e

    const/16 v3, -0x46

    aput-byte v3, v6, v2

    const/16 v2, 0x1f

    const/16 v3, -0x3a

    aput-byte v3, v6, v2

    const/16 v2, 0x20

    const/16 v3, -0x4c

    aput-byte v3, v6, v2

    const/16 v2, 0x21

    const/16 v3, -0x52

    aput-byte v3, v6, v2

    new-array v2, v10, [B

    const/4 v3, -0x4

    aput-byte v3, v2, v5

    const/16 v3, -0x11

    aput-byte v3, v2, v16

    const/16 v3, -0x33

    aput-byte v3, v2, v15

    const/16 v3, 0x5e

    aput-byte v3, v2, v11

    const/16 v3, -0x5d

    aput-byte v3, v2, v14

    const/16 v3, 0x69

    aput-byte v3, v2, v13

    const/16 v3, -0x1b

    const/4 v5, 0x6

    aput-byte v3, v2, v5

    const/16 v3, -0x6b

    const/4 v5, 0x7

    aput-byte v3, v2, v5

    invoke-static {v6, v2}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v4, v7

    invoke-static {v4}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    invoke-virtual {v1}, Ljavax/net/ssl/SSLSocket;->getSupportedCipherSuites()[Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v3

    new-instance v4, Ljava/util/HashSet;

    invoke-direct {v4, v2}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    invoke-virtual {v4, v3}, Ljava/util/AbstractCollection;->retainAll(Ljava/util/Collection;)Z

    new-instance v2, Ljava/util/HashSet;

    invoke-virtual {v1}, Ljavax/net/ssl/SSLSocket;->getEnabledCipherSuites()[Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-direct {v2, v1}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    invoke-virtual {v4, v2}, Ljava/util/AbstractCollection;->addAll(Ljava/util/Collection;)Z

    invoke-virtual {v4}, Ljava/util/HashSet;->size()I

    move-result v1

    new-array v1, v1, [Ljava/lang/String;

    invoke-virtual {v4, v1}, Ljava/util/AbstractCollection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v1

    check-cast v1, [Ljava/lang/String;

    sput-object v1, Lcom/github/catvod/spider/merge/q/h;->c:[Ljava/lang/String;
    :try_end_c6d
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_c6d} :catch_c75

    :cond_c6d
    new-instance v1, Lcom/github/catvod/spider/merge/q/g;

    invoke-direct {v1}, Lcom/github/catvod/spider/merge/q/g;-><init>()V

    sput-object v1, Lcom/github/catvod/spider/merge/q/h;->d:Ljavax/net/ssl/X509TrustManager;

    return-void

    :catch_c75
    move-exception v0

    move-object v1, v0

    new-instance v2, Ljava/lang/RuntimeException;

    invoke-direct {v2, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    goto :goto_c7e

    :goto_c7d
    throw v2

    :goto_c7e
    goto :goto_c7d
.end method

.method public constructor <init>(Ljavax/net/ssl/X509TrustManager;)V
    .registers 10

    invoke-direct {p0}, Ljavax/net/ssl/SSLSocketFactory;-><init>()V

    const/4 v0, 0x3

    :try_start_4
    new-array v1, v0, [B

    const/4 v2, 0x7

    const/4 v3, 0x0

    aput-byte v2, v1, v3

    const/16 v4, 0x5e

    const/4 v5, 0x1

    aput-byte v4, v1, v5

    const/16 v4, -0x13

    const/4 v6, 0x2

    aput-byte v4, v1, v6

    const/16 v4, 0x8

    new-array v4, v4, [B

    const/16 v7, 0x53

    aput-byte v7, v4, v3

    const/16 v7, 0x12

    aput-byte v7, v4, v5

    const/16 v7, -0x42

    aput-byte v7, v4, v6

    const/16 v6, -0x44

    aput-byte v6, v4, v0

    const/4 v0, 0x4

    const/16 v6, 0x69

    aput-byte v6, v4, v0

    const/4 v0, 0x5

    const/16 v6, -0x5b

    aput-byte v6, v4, v0

    const/4 v0, 0x6

    const/16 v6, 0x1f

    aput-byte v6, v4, v0

    const/16 v0, 0x6e

    aput-byte v0, v4, v2

    invoke-static {v1, v4}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljavax/net/ssl/SSLContext;->getInstance(Ljava/lang/String;)Ljavax/net/ssl/SSLContext;

    move-result-object v0

    const/4 v1, 0x0

    if-eqz p1, :cond_4b

    new-array v2, v5, [Ljavax/net/ssl/X509TrustManager;

    aput-object p1, v2, v3

    goto :goto_4c

    :cond_4b
    move-object v2, v1

    :goto_4c
    invoke-virtual {v0, v1, v2, v1}, Ljavax/net/ssl/SSLContext;->init([Ljavax/net/ssl/KeyManager;[Ljavax/net/ssl/TrustManager;Ljava/security/SecureRandom;)V

    invoke-virtual {v0}, Ljavax/net/ssl/SSLContext;->getSocketFactory()Ljavax/net/ssl/SSLSocketFactory;

    move-result-object p1

    iput-object p1, p0, Lcom/github/catvod/spider/merge/q/h;->a:Ljavax/net/ssl/SSLSocketFactory;
    :try_end_55
    .catch Ljava/security/GeneralSecurityException; {:try_start_4 .. :try_end_55} :catch_56

    return-void

    :catch_56
    new-instance p1, Ljava/lang/AssertionError;

    invoke-direct {p1}, Ljava/lang/AssertionError;-><init>()V

    throw p1
.end method

.method private a(Ljavax/net/ssl/SSLSocket;)V
    .registers 4

    sget-object v0, Lcom/github/catvod/spider/merge/q/h;->b:[Ljava/lang/String;

    if-eqz v0, :cond_7

    invoke-virtual {p1, v0}, Ljavax/net/ssl/SSLSocket;->setEnabledProtocols([Ljava/lang/String;)V

    :cond_7
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x15

    if-ge v0, v1, :cond_14

    sget-object v0, Lcom/github/catvod/spider/merge/q/h;->c:[Ljava/lang/String;

    if-eqz v0, :cond_14

    invoke-virtual {p1, v0}, Ljavax/net/ssl/SSLSocket;->setEnabledCipherSuites([Ljava/lang/String;)V

    :cond_14
    return-void
.end method


# virtual methods
.method public final createSocket(Ljava/lang/String;I)Ljava/net/Socket;
    .registers 4

    iget-object v0, p0, Lcom/github/catvod/spider/merge/q/h;->a:Ljavax/net/ssl/SSLSocketFactory;

    invoke-virtual {v0, p1, p2}, Ljavax/net/SocketFactory;->createSocket(Ljava/lang/String;I)Ljava/net/Socket;

    move-result-object p1

    instance-of p2, p1, Ljavax/net/ssl/SSLSocket;

    if-eqz p2, :cond_10

    move-object p2, p1

    check-cast p2, Ljavax/net/ssl/SSLSocket;

    invoke-direct {p0, p2}, Lcom/github/catvod/spider/merge/q/h;->a(Ljavax/net/ssl/SSLSocket;)V

    :cond_10
    return-object p1
.end method

.method public final createSocket(Ljava/lang/String;ILjava/net/InetAddress;I)Ljava/net/Socket;
    .registers 6

    iget-object v0, p0, Lcom/github/catvod/spider/merge/q/h;->a:Ljavax/net/ssl/SSLSocketFactory;

    invoke-virtual {v0, p1, p2, p3, p4}, Ljavax/net/SocketFactory;->createSocket(Ljava/lang/String;ILjava/net/InetAddress;I)Ljava/net/Socket;

    move-result-object p1

    instance-of p2, p1, Ljavax/net/ssl/SSLSocket;

    if-eqz p2, :cond_10

    move-object p2, p1

    check-cast p2, Ljavax/net/ssl/SSLSocket;

    invoke-direct {p0, p2}, Lcom/github/catvod/spider/merge/q/h;->a(Ljavax/net/ssl/SSLSocket;)V

    :cond_10
    return-object p1
.end method

.method public final createSocket(Ljava/net/InetAddress;I)Ljava/net/Socket;
    .registers 4

    iget-object v0, p0, Lcom/github/catvod/spider/merge/q/h;->a:Ljavax/net/ssl/SSLSocketFactory;

    invoke-virtual {v0, p1, p2}, Ljavax/net/SocketFactory;->createSocket(Ljava/net/InetAddress;I)Ljava/net/Socket;

    move-result-object p1

    instance-of p2, p1, Ljavax/net/ssl/SSLSocket;

    if-eqz p2, :cond_10

    move-object p2, p1

    check-cast p2, Ljavax/net/ssl/SSLSocket;

    invoke-direct {p0, p2}, Lcom/github/catvod/spider/merge/q/h;->a(Ljavax/net/ssl/SSLSocket;)V

    :cond_10
    return-object p1
.end method

.method public final createSocket(Ljava/net/InetAddress;ILjava/net/InetAddress;I)Ljava/net/Socket;
    .registers 6

    iget-object v0, p0, Lcom/github/catvod/spider/merge/q/h;->a:Ljavax/net/ssl/SSLSocketFactory;

    invoke-virtual {v0, p1, p2, p3, p4}, Ljavax/net/SocketFactory;->createSocket(Ljava/net/InetAddress;ILjava/net/InetAddress;I)Ljava/net/Socket;

    move-result-object p1

    instance-of p2, p1, Ljavax/net/ssl/SSLSocket;

    if-eqz p2, :cond_10

    move-object p2, p1

    check-cast p2, Ljavax/net/ssl/SSLSocket;

    invoke-direct {p0, p2}, Lcom/github/catvod/spider/merge/q/h;->a(Ljavax/net/ssl/SSLSocket;)V

    :cond_10
    return-object p1
.end method

.method public final createSocket(Ljava/net/Socket;Ljava/lang/String;IZ)Ljava/net/Socket;
    .registers 6

    iget-object v0, p0, Lcom/github/catvod/spider/merge/q/h;->a:Ljavax/net/ssl/SSLSocketFactory;

    invoke-virtual {v0, p1, p2, p3, p4}, Ljavax/net/ssl/SSLSocketFactory;->createSocket(Ljava/net/Socket;Ljava/lang/String;IZ)Ljava/net/Socket;

    move-result-object p1

    instance-of p2, p1, Ljavax/net/ssl/SSLSocket;

    if-eqz p2, :cond_10

    move-object p2, p1

    check-cast p2, Ljavax/net/ssl/SSLSocket;

    invoke-direct {p0, p2}, Lcom/github/catvod/spider/merge/q/h;->a(Ljavax/net/ssl/SSLSocket;)V

    :cond_10
    return-object p1
.end method

.method public final getDefaultCipherSuites()[Ljava/lang/String;
    .registers 2

    sget-object v0, Lcom/github/catvod/spider/merge/q/h;->c:[Ljava/lang/String;

    return-object v0
.end method

.method public final getSupportedCipherSuites()[Ljava/lang/String;
    .registers 2

    sget-object v0, Lcom/github/catvod/spider/merge/q/h;->c:[Ljava/lang/String;

    return-object v0
.end method

.class public final synthetic Lcom/github/catvod/spider/merge/b/v;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static a([B[BLjava/lang/StringBuilder;Ljava/lang/String;)V
    .registers 4

    .line 1
    invoke-static {p0, p1}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p0

    .line 2
    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 3
    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    return-void
.end method

.method public static b([B[BLorg/json/JSONObject;Lorg/json/JSONObject;Ljava/lang/String;)V
    .registers 5

    .line 1
    invoke-static {p0, p1}, Lcom/github/catvod/spider/merge/a/a;->a([B[B)Ljava/lang/String;

    move-result-object p0

    .line 2
    invoke-virtual {p2, p0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    .line 3
    invoke-virtual {p3, p4, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    return-void
.end method

.method public static synthetic c(Ljava/lang/Object;)Z
    .registers 1

    if-nez p0, :cond_4

    const/4 p0, 0x1

    goto :goto_5

    :cond_4
    const/4 p0, 0x0

    :goto_5
    return p0
.end method
